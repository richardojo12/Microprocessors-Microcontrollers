/**
  * @brief Serial Peripheral Interface from stm32H745xx.h 
  */


#ifdef __ASSEMBLY__

@;------ utility macros

	.macro MOV_imm32 reg, constant
		movw \reg, #:lower16:\constant
		movt \reg, #:upper16:\constant
	.endm


@;------ 'struct' elements 

	.macro CTNR_m ctnrname typename idx
		.ifdef TEMPGLOBAL		
			.global \ctnrname\typename\idx
		.endif
		\ctnrname\typename\idx:
	.endm


	.macro EL_m ctnrname typename elname idx size	
		.ifdef TEMPGLOBAL										
			.global \ctnrname\typename\elname\idx				
		.endif
		\ctnrname\typename\elname\idx:
		.skip \size						     @;allocation in bytes for this element
		.ifndef \typename\elname 
			 @;calculate offset of this element in the larger structure, and give offset a name		
			.equ \typename\elname,( \ctnrname\typename\elname\idx - \ctnrname\typename\idx ) @;define the offset of this element in all containers like this
		.endif
	.endm

	
	CTNR_m SPI, _I2S, , 
		EL_m SPI, _i2s_, CR1, ,         
		EL_m SPI, _i2s_, CR2, ,         
		EL_m SPI, _i2s_, CFG1, ,        
		EL_m SPI, _i2s_, CFG2, ,        
		EL_m SPI, _i2s_, IER, ,         
		EL_m SPI, _i2s_, SR, ,          
		EL_m SPI, _i2s_, IFCR, ,        
		EL_m SPI, _i2s_, RESERVED0, ,   
		EL_m SPI, _i2s_, TXDR, ,        
		EL_m SPI, _i2s_, RESERVED1_0, ,
		EL_m SPI, _i2s_, RESERVED1_1, ,
		EL_m SPI, _i2s_, RESERVED1_2, ,
		EL_m SPI, _i2s_, RXDR, ,        
		EL_m SPI, _i2s_, RESERVED2_0, ,
		EL_m SPI, _i2s_, RESERVED2_1, ,
		EL_m SPI, _i2s_, RESERVED2_1, ,
		EL_m SPI, _i2s_, CRCPOLY, ,     
		EL_m SPI, _i2s_, TXCRC, ,       
		EL_m SPI, _i2s_, RXCRC, ,       
		EL_m SPI, _i2s_, UDRDR, ,       
		EL_m SPI, _i2s_, i2sCFGR, , 

#else

typedef struct
{
  __IO uint32_t CR1;           /*!< SPI/I2S Control register 1,                      Address offset: 0x00 */
  __IO uint32_t CR2;           /*!< SPI Control register 2,                          Address offset: 0x04 */
  __IO uint32_t CFG1;          /*!< SPI Configuration register 1,                    Address offset: 0x08 */
  __IO uint32_t CFG2;          /*!< SPI Configuration register 2,                    Address offset: 0x0C */
  __IO uint32_t IER;           /*!< SPI/I2S Interrupt Enable register,               Address offset: 0x10 */
  __IO uint32_t SR;            /*!< SPI/I2S Status register,                         Address offset: 0x14 */
  __IO uint32_t IFCR;          /*!< SPI/I2S Interrupt/Status flags clear register,   Address offset: 0x18 */
  uint32_t      RESERVED0;     /*!< Reserved, 0x1C                                                        */
  __IO uint32_t TXDR;          /*!< SPI/I2S Transmit data register,                  Address offset: 0x20 */
  uint32_t      RESERVED1[3];  /*!< Reserved, 0x24-0x2C                                                   */
  __IO uint32_t RXDR;          /*!< SPI/I2S Receive data register,                   Address offset: 0x30 */
  uint32_t      RESERVED2[3];  /*!< Reserved, 0x34-0x3C                                                   */
  __IO uint32_t CRCPOLY;       /*!< SPI CRC Polynomial register,                     Address offset: 0x40 */
  __IO uint32_t TXCRC;         /*!< SPI Transmitter CRC register,                    Address offset: 0x44 */
  __IO uint32_t RXCRC;         /*!< SPI Receiver CRC register,                       Address offset: 0x48 */
  __IO uint32_t UDRDR;         /*!< SPI Underrun data register,                      Address offset: 0x4C */
  __IO uint32_t I2SCFGR;       /*!< I2S Configuration register,                      Address offset: 0x50 */

} SPI_TypeDef;

#endif