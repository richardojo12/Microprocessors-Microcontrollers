//CM7main11.c wmh 2021-04-20 : apparently working (some bugs found and eliminated in messaging)
//CM7main10.c wmh 2021-04-18 : updated to use MoT_msglistRefresh() with MoT_msgPost() (see MoTservices.S)
//CM7main09.c wmh 2021-04-05 : updated to use MoTservices
//CM7main08.c wmh 2021-04-04 : continue development of device-array organization
//CM7main06.c wmh 2021-03-29 : MoT tasking using an array of addresses of devices' data structs
//	we are going to adapt the linked list taskCTL_t structure shown below for dispatching from an array of taskCTL addresses
//CM7main05.c wmh 2021-03-26 : USART1 GPS comm monitor -- working
//CM7main04.c wmh 2021-03-26 : USART1 initialization - single character loopback 
//CM7main03.c wmh 2020-11-16 : USART3 comm for 'testy' project example
//CM7main02.c wmh 2020-08-07 : begin USART3 comm development for  'testy' project example 
// we are updating the definition of the device functions being dispatched to return a void pointer which initially we will use
// as a message pointer, e.g. every time we dispatcvh a function it will return a string pointer (or a NULL pointer)
//CM7main01.c for scratch build wmh 2020-08-07 : do-nothing main

#include <stdint.h>					//for uint32_t and friends
#include <stddef.h>					//for NULL
#include "MoTstructures.h"
/*********************************** MoT structure definitions -- not latest  *****************************	

	#ifdef __ASSEMBLY__	  //dims colorization when #ifdef is exposed 

		// MoT device structure definitions (revised 2021-04-19)

		// MoT device control structure
		// Following are the required standard set of offsets relative to the origin of the data region allocated to a MoT device
		// This data in this location could be in the .data section so as to be automagically initialized to real values at startup. 
		// This standardized design of a MoT device's data structure may be used for either array-dispatch or linked-list dispatch of MoT tasks
		#define XEQCMD 0			// holds address of the device's command handler
		#define XEQTASK 4			// holds address of the device's task handler
		#define NEXTTASK 8			// holds address of the device's successor device in linked-list task design
		#define XEQC 12				// holds execution address of device task functions written in C (void-void functions to be dispatched by the XEQCMD)
		#define SLEEPSAVE 16		// preserves XEQCMD address when the device's XEQCMD is replaced by the 'sleep()' task's execution address
		#define SLEEPRESUME 20		// will hold return address of the task which called the sleep() task 
		#define MSECWAKETIMELO 24	// will hold lsword of sleep()'s wakeup time (abs msecs)
		#define MSECWAKETIMEHI 28	// will hold msword of sleep()'s task wakeup time (abs msecs)
		#define MSGLINK_T 32		// <<<< origin of the the default message link structure 'msgLINK__t' embedded in the device control structure
		#define NEXTMSG 0			// (NB! offset relative to MSGLINK_T) holds offset of the device's successor message in a linked-list message design
		#define MSGP 4				// (NB! offset relative to MSGLINK_T) holds byte pointer to bytes of a device message 
		#define MSGCOUNT 8			// (NB! offset relative to MSGLINK_T) holds count of number of bytes in a device message

		//data that follows here can be anything required by the MoT device
		#define MOTDATA 44			// use this to reserve space at the top of each MoT task data structure for the device control parameters

		// Following are standard offsets relative to the origin of a MoT message list control structure msgLIST_t
		#define BYTEP 0				
		#define BYTECOUNT 4
		#define LISTHEADP 8
		#define LISTTAILP 12

	#else	//not assembly, C

	typedef struct msgLINK {
		struct msgLINK *nextmsg;	//,0	holds address of the device's successor device in a linked-list message design
		uint8_t *msgp;				//,4	pointer to bytes of a device message 
		uint32_t msgcount;			//,8	count of number of bytes in message
	} msgLINK_t; 

	//Master control structure for devices. Each device will have the following data structure at its data origin. 
	typedef struct deviceCTL {		//task control structure common to all tasks
		void (*xeqcmd)(void *);		//,0	execution address of a device command
		void (*xeqtask)(void);		//,4	coninuation address of a device task
		struct deviceCTL *nexttask;	//,8	holds address of the device's successor device in linked-list task design 
		void (*xeqC)(void);			//,12	holds address of a c task's execution address
		void (*sleepsave)(void);	//,16	holds xeqtask value of a sleeping task
		void (*sleepresume)(void);	//,20	holds return address of the call to the sleep function
		uint32_t msecwaketimelo;	//,24	holds lsword of task wakeup time (abs msecs)
		uint32_t msecwaketimehi;	//,28	holds msword of task wakeup time (abs msecs)
		msgLINK_t devmsg;			//,32,36,40	holds device default nextmsg, msgp and msgcount 
	} deviceCTL_t;

	//message list control structure
	typedef struct msgLIST {
		uint8_t *bytep;				//,0	pointer to remaining bytes of a device message 
		uint32_t bytecount;			//,4	count of number of bytes remaining in message
		msgLINK_t *listheadp;		//,8	pointer to 1st device in the list of devices having messages (where we get characters for sending)
		msgLINK_t *listtailp;		//,12	pointer to final device in the list of devices having messages (where we append new messages)
	} msgLIST_t;

	#endif

*****************************************************************************************************/

//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOBbit0();				//in GreenLED.S
void init_greenLED();				// ""
void toggle_greenLED();				// ""
void setGPIOBbit0();				// ""
void resetGPIOBbit0();				// ""

//USART3 initialization and test operations in CM7_USART3_01.S
void USART3_HWinit();
void USART3_IRQinit(); 
int nbUSART3_getchar(); 			//success: return data>=0; failure: return -1
int nbUSART3_putchar(uint8_t data);	//success: return +1; failure: return -1)
void USART3_TX_enab();				//
int32_t USART3_txrdy();				// return 0/1	USART3 transmit not ready/ready

//command processing utility (at bottom of this page)
int hexcmd2bin(char *hexcmd, uint8_t *bincmd);	//processes a text buffer containing a MoT-format command 'string'  into a binary command buffer; 
												//	returns #of bytes in bincmd or -1 if format violation					

void *Reset_Handler();				//in startup/startup_stm32CM7.S
void *cmd_greenLED(void *);			//in CM7/src/MoTdevice_greenLED.S 
void *cmd_redLED(void *);			//in CM7/src/MoTdevice_redLED.S 
//void *cmd_ubloxGPS(void *);		//in CM7/src/device_ubloxGPS.S

//functions called from main (MoTservices_v4.S)
void *MoT_doCmd(uint8_t *binbuf, deviceCTL_t *devlist[]);	// dispatch a device function with command in binbuf
void MoT_runTasks(deviceCTL_t *devlist[]); 					// starts tasks on device list
void MoT_updateMsgs (msgLINK_t *);							// refreshes msgCTL struct when current message is exhausted
void MoT_msglistRefresh(msgLIST_t *);						// monitors state of message list and updates as required

//called from commands or tasks (MoTservices_v4.S)
int MoT_postMsg(msgLINK_t *, msgLIST_t *);	//puts message data in a queue for sending, return 0 if successful, non-zero if fail

//called from main() or TX interrupt (MoTservices_v4.S)
int MoT_msglistGetchar(msgLIST_t *); 		//called from MoT tether's TXD interrupt or from C main(). Returns next char to send or -1 if none exists

//device control structures (in like-named files)
extern deviceCTL_t zero_devicectl;				//1st device is system device of MoT command '0'
extern deviceCTL_t greenLED;					//example device/task
extern deviceCTL_t redLED;						//example device/task
extern deviceCTL_t blueBUTTON_devicectl;		//example device/task
extern deviceCTL_t TIM;							//TIM device/task
extern deviceCTL_t GPIO;						//GPIO device
extern deviceCTL_t SPI;							// SPI device

extern deviceCTL_t Nth_devicectl;				//last device is system device

deviceCTL_t * CM7_devicelist[] = {&zero_devicectl, &greenLED, &redLED, &blueBUTTON_devicectl, &TIM, &GPIO, &SPI, &Nth_devicectl};	//addresses of task control structs

// note: CM7_main10.c reverts to an exhaustive linked list of tasks for speed; the code below initializes the list
#define CM7_devicecount ((sizeof(CM7_devicelist))/(sizeof(&CM7_devicelist[0])))

void link_devicetasks( deviceCTL_t * devicelist[], int devicecount ) {
	int i;
	for(i=0;i<devicecount-1;i++) {
		devicelist[i]->nexttask = devicelist[i+1];	//style-trial
	}
}

#define MAXHEXBUF 100

//USART1 initialization and test operations in CM7_USART1_01.S
void USART1_HWinit();
//TODO void USART3_IRQinit();
int nbUSART1_getchar(); 			//success: return data>=0; failure: return -1
int nbUSART1_putchar(char data);	//success: return +1; failure: return -1)
//TODO void USART3_TXinterrupt_enab();

msgLIST_t USART3_msglist = { (uint8_t *)NULL, 0, (msgLINK_t *)NULL,  (msgLINK_t *)NULL };

//globals used here and by devices
char USART3_hexbuf[MAXHEXBUF];					//where 'raw' commands received ver UART3 are accumulated (global for later useage) 
uint8_t USART3_binbuf[MAXHEXBUF/2+1];			//where converted commands from UART3_hexbuf[] are stored           --"--
char *phexbuf=USART3_hexbuf;
uint8_t *pbinbuf=USART3_binbuf;


int main() 
{
	int c,ret;

	link_devicetasks(CM7_devicelist, CM7_devicecount);		//initialize the task list
	USART3_HWinit();	//115200N81							//initialize the MoT 'tether' 
//	init_greenLED();	//in device_greenLED.S				//now done as green LED command '0'
	
	while(1){ 
		//interpret and execute commands
		if( (c = nbUSART3_getchar()) >= 0 ){ 	//we have received a new character
			*phexbuf++=c;						//	so put it in the command buffer
			if( (c=='\n') || (c=='\r') ) {		//	if its a newline we may have a new command (if it passes the format check)
				if( (ret=hexcmd2bin(USART3_hexbuf,USART3_binbuf))>0 ) { 		//it passed the format check
					MoT_doCmd(USART3_binbuf, CM7_devicelist );
				}
				phexbuf=USART3_hexbuf;	//restart the input buffer
			}
		}

		MoT_runTasks(CM7_devicelist); 	//CM7_devicelist[] is the array of pointers to device structs

		MoT_msglistRefresh(&USART3_msglist); //

		if(USART3_txrdy()) { 										//if USART3 is ready to send
			if( (c = MoT_msglistGetchar(&USART3_msglist)) > 0 ) {  	//and we have something to send
				ret = nbUSART3_putchar((uint8_t)c);					//attempt to send: ret== +1 : success; ret== -1 failure:)
			}	//TODO : do something if putchar fails
		}
	}

	return 0;	//we never get here, but this eliminates a warning
}

int hex2bin(char HASCII)   // translate uppercase hex ASCII to bin, return value 0-15 or -1 if fail
{   
	if('0'<=HASCII && '9'>=HASCII) return(HASCII - '0');   
	if('A'<=HASCII && 'F'>=HASCII) return(HASCII - 'A' + 10);  
	return -1;   
}   


int hexcmd2bin(char *hexcmd, uint8_t *bincmd)	//processes a text buffer containing a MoT-format command 'string'  into a binary command buffer; 
//	returns #of bytes in bincmd or -1 if format violation
{
	int i;
	uint8_t lonybble,hinybble,byte;
	uint8_t chk=0;
	if(hexcmd[0] != ':' ) return -1;	//bad format -- no start symbol
	for(i=1;i<MAXHEXBUF;) {
		if( (hexcmd[i]=='\n')| (hexcmd[i]=='\r')) break;//we're at the end of a command
		//here if parsing should continue
		if( ((hinybble=hex2bin(hexcmd[i]))>=0) && ((lonybble=hex2bin(hexcmd[i+1]))>=0) ) byte=16*hinybble+lonybble; //successful hex byte to bin conversion  
		else return -2;					//bad hex byte
		//here when the two characters of a hex byte are successfully converted into a value in 'byte'
		*bincmd++ = byte;				//add byte to the binary cmd string
		chk += byte;					// and to the checksum (overflows are expected and desired)
		i += 2;							//  then advance to convert the next byte
	}
	//here iff the text string lies between ':' and '\n' or '\r' and consists exclusively of hex bytes !!TODO what about too long? 
	if ( chk != 0 ) return -3;			//bad checksum	
	return i/2-1;						//number of bytes in bindcmd, not including checksum
}
		
