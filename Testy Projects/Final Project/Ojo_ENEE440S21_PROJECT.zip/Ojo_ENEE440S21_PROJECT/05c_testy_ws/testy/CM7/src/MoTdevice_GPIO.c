//Motdevice_GPIO.c
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include "MoTstructures.h"

//TODO #include "MoTservices.h" to get
void MoT_linkTask( void(*)(), void(*)() );
void MoT_skipTask( );
void MoT_doCtask();
int MoT_postMsg(msgLINK_t *, msgLIST_t *); //puts message in queue for sending, return 0 if successful, non-zero if fail


// local functions
void start_init_GPIO_Input_task(void *);
void start_init_GPIO_Output_task(void *);
void init_GPIO_Input_task();
void init_GPIO_Output_task();

void start_GPIO_output_set_task(void *);
void start_GPIO_output_reset_task(void *);
void GPIO_output_set_task();
void GPIO_output_reset_task();

void start_GPIO_input_read_task(void *);
void GPIO_input_read_task();

//Repetitive timed
void start_GPIO_Input_repetitive_task(void *);
void start_GPIO_Output_repetitive_task(void *);
void GPIO_Input_repetitive_task();
void GPIO_Output_repetitive_task_set();
void GPIO_Output_repetitive_task_reset();

//Scheduled
void start_GPIO_Input_scheduled_task(void *);
void start_GPIO_Output_scheduled_task(void *);
void GPIO_Input_scheduled_task();
void GPIO_Output_scheduled_task();

//LL
void init_GPIO_Input();
void init_GPIO_Output();

void GPIO_output_set();
void GPIO_output_reset();

uint8_t GPIO_input_read();

//Disable
void start_GPIO_Off_task(void *);
void GPIO_Off_task();
void GPIO_Off();

//MoT Sleep
void startSleep(uint32_t Nmsecs);

void GPIO_cmdHandler(void *);

//MoT device structure
deviceCTL_t GPIO_devicectl = (deviceCTL_t) {GPIO_cmdHandler, MoT_skipTask, NULL,NULL, NULL, NULL, 0, 0};

// local variables (these could alternatively be defined in _LL using MoTvarAlloc
int32_t GPIO_cyclecount, GPIO_reload, GPIO_count, GPIO_delay;

uint8_t inputVal;
char messageInput[100];
char intAsString[32];

//single-function messages (see _LL for alternative way of defining messages with MoTmsgAlloc)

msgLINK_t init_input_msg = { NULL, "GPIO PB1 initialized as input\n\r", strlen("GPIO PB1 initialized as input\n\r")};
msgLINK_t init_output_msg = { NULL, "GPIO PC2 initialized as output\n\r", strlen("GPIO PC2 initialized as output\n\r")};
//Output Messages
msgLINK_t set_output_msg = { NULL, "GPIO PC2 set HIGH\n\r", strlen("GPIO PC2 set HIGH\n\r")};
msgLINK_t reset_output_msg = { NULL, "GPIO PC2 set LOW\n\r", strlen("GPIO PC2 set LOW\n\r")};

msgLINK_t disable_msg = { NULL, "GPIO Input and Output disabled\n\r", strlen("GPIO Input and Output disabled\n\r")};

msgLINK_t customMsg;



//external structures
extern msgLIST_t USART3_msglist;

// ----- GPIO command dispatch function
void GPIO_cmdHandler(void *Cmdtail)	//dispatched in main() by MoT_doCmd(USART3_binbuf, CM7_devicelist ). On entry rDEVP points to GPIO data structure
{
	switch(*((uint8_t *)Cmdtail)) {
		case 0:	start_init_GPIO_Input_task(Cmdtail+1); break; 			// in MoTdevice_GPIO_LL.S initialize PB1 as GPIO input
		case 1:	start_init_GPIO_Output_task(Cmdtail+1); break; 			// Initialize PC2 as GPIO output
		case 2:	start_GPIO_output_set_task(Cmdtail+1);break;			// Set GPIO output high
		case 3:	start_GPIO_output_reset_task(Cmdtail+1); break; 		// Set GPIO output low
		case 4: start_GPIO_input_read_task(Cmdtail+1); break; 			// Read value from PB1 IDR
		case 5: start_GPIO_Input_repetitive_task(Cmdtail+1); break; 	// Read value from PB1 IDR continuously
		case 6: start_GPIO_Output_repetitive_task(Cmdtail+1); break; 	// Output 1 and 0 on PC2 continuously
		case 7: start_GPIO_Input_scheduled_task(Cmdtail+1); break;		//Read Input PB1 after x milliseconds
		case 8: start_GPIO_Output_scheduled_task(Cmdtail+1); break;		// Output 1 on output PC2 after x milliseconds
		case 9:	start_GPIO_Off_task(Cmdtail+1); break;		//Disable both GPIO input and GPIO output
		default: ;										// TODO
	}
	//how does this return?
}

//Helper Function to concat string2 to string1 and returns msgLink_t object
/*msgLINK_t generateCustomMsg(char *string1, char *string2){
	strcat(string1, string2);
	strcat(string1, "\n\r");
	msgLINK_t inputValMsg = { NULL, string1, strlen(string1)};

	return inputValMsg;
}*/


// ----- GPIO commands and tasks
//Input
void start_init_GPIO_Input_task(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, init_GPIO_Input_task);
}

void init_GPIO_Input_task()
{
	init_GPIO_Input();
	MoT_postMsg(&init_input_msg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

void start_GPIO_input_read_task(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, GPIO_input_read_task);
}
void GPIO_input_read_task(){
	inputVal = GPIO_input_read();
	strcpy(messageInput, "GPIO PB1 Value: ");
	itoa(inputVal, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);

	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}


//Output
void start_init_GPIO_Output_task(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, init_GPIO_Output_task);
}

void init_GPIO_Output_task()
{
	init_GPIO_Output();
	MoT_postMsg(&init_output_msg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

//Set output PC2
void start_GPIO_output_set_task(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, GPIO_output_set_task);
}

void GPIO_output_set_task(){
	GPIO_output_set();
	MoT_postMsg(&set_output_msg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

//Reset output PC2
void start_GPIO_output_reset_task(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, GPIO_output_reset_task);
}

void GPIO_output_reset_task(){
	GPIO_output_reset();
	MoT_postMsg(&reset_output_msg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

//Repetitive

void start_GPIO_Input_repetitive_task(void *Cmdtail1)
{
	GPIO_reload = *(int32_t *)Cmdtail1;
	GPIO_count = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, GPIO_Input_repetitive_task);
}

void GPIO_Input_repetitive_task() //Repeatedly read from PB1 and report
{
	inputVal = GPIO_input_read();
	strcpy(messageInput, "GPIO PB1 Value: ");
	itoa(inputVal, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);

	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);

	if(GPIO_reload != 0) { 	//counting is enabled
		if(GPIO_count == 0) {
			GPIO_count = GPIO_reload;
			MoT_linkTask( MoT_doCtask, GPIO_Input_repetitive_task);
		} else {
			GPIO_count--;
		}
	}
}

void start_GPIO_Output_repetitive_task(void *Cmdtail1)
{
	GPIO_reload = *(int32_t *)Cmdtail1;
	GPIO_count = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, GPIO_Output_repetitive_task_set);
}

void GPIO_Output_repetitive_task_set() //Repeatedly output to PC2
{
	GPIO_output_set();
	if(GPIO_reload != 0) { 	//counting is enabled
		if(GPIO_count == 0) {// PC2 set high
			GPIO_count = GPIO_reload;
			MoT_linkTask( MoT_doCtask, GPIO_Output_repetitive_task_reset);
			MoT_postMsg(&reset_output_msg, &USART3_msglist);
		} else {
			GPIO_count--;
		}
	}
}

void GPIO_Output_repetitive_task_reset() //Repeatedly output to PC2
{
	GPIO_output_reset();
	if(GPIO_reload != 0) { 	//counting is enabled
		if(GPIO_count == 0) {// PC2 set low
			GPIO_count = GPIO_reload;
			MoT_linkTask( MoT_doCtask, GPIO_Output_repetitive_task_set);
			MoT_postMsg(&set_output_msg, &USART3_msglist);
		} else {
			GPIO_count--;
		}
	}
}

//Scheduled

void start_GPIO_Input_scheduled_task(void *Cmdtail1)
{
	GPIO_reload = *(int32_t *)Cmdtail1;
	GPIO_count = *(int32_t *)Cmdtail1;
	GPIO_delay = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, GPIO_Input_scheduled_task);
}

void GPIO_Input_scheduled_task() // Sleep then read from PB1 and report
{
	strcpy(messageInput, "GPIO PB1 will read value after ");
	itoa(GPIO_delay, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);
	strcat(messageInput, " milliseconds");

	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};

	MoT_postMsg(&customMsg, &USART3_msglist);

	MoT_linkTask( MoT_doCtask, GPIO_input_read_task); // Run read value task after waiting// task also reports

	startSleep(GPIO_delay); // Sleep Input task for GPIO_delay milliseconds

}

void start_GPIO_Output_scheduled_task(void *Cmdtail1)
{
	GPIO_reload = *(int32_t *)Cmdtail1;
	GPIO_count = *(int32_t *)Cmdtail1;
	GPIO_delay = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, GPIO_Output_scheduled_task);
}

void GPIO_Output_scheduled_task() // Sleep then read from PB1 and report
{
	strcpy(messageInput, "GPIO PC2 will go HIGH after ");
	itoa(GPIO_delay, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);
	strcat(messageInput, " milliseconds");

	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};

	MoT_postMsg(&customMsg, &USART3_msglist);

	startSleep(GPIO_delay); // Sleep Input task for GPIO_delay milliseconds

	MoT_linkTask( MoT_doCtask, GPIO_output_set_task); // set output value  after waiting// task also reports
}

//Disable

void start_GPIO_Off_task(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, GPIO_Off_task);
}

void GPIO_Off_task()
{
	GPIO_Off();
	MoT_postMsg(&disable_msg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}


