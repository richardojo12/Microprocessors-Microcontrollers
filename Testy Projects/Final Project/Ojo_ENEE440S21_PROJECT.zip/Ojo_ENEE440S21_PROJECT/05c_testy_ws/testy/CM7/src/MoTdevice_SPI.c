//Motdevice_SPI.c
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include "MoTstructures.h"

//TODO #include "MoTservices.h" to get
void MoT_linkTask( void(*)(), void(*)() );
void MoT_skipTask( );
void MoT_doCtask();
int MoT_postMsg(msgLINK_t *, msgLIST_t *); //puts message in queue for sending, return 0 if successful, non-zero if fail

//TODO #include "MoTdevice_SPI_LL.h"
void init_SPI();
void MasterTx(int32_t data);
int32_t SPI1_Rx();
void SlaveTx(int32_t data);
int32_t SPI3_Rx();

// local functions
void start_init_SPItask(void *);
void init_SPItask();

void start_MasterTxtask(void *);
void MasterTxtask();
void start_MasterRxtask(void *);
void MasterRxtask();

void start_SlaveTxtask(void *);
void SlaveTxtask();
void start_SlaveRxtask(void *);
void SlaveRxtask();

void start_MasterTxtask_polled(void *);
void MasterTxtask_polled();
void start_MasterRxtask_polled(void *);
void MasterRxtask_polled();

void start_SlaveTxtask_polled(void *);
void SlaveTxtask_polled();
void start_SlaveRxtask_polled(void *);
void SlaveRxtask_polled();

//Disable
void start_disable_SPItask(void *);
void disable_SPItask();
void disable_SPI();

//MoT Sleep
void startSleep(uint32_t Nmsecs);

void SPI_cmdHandler(void *);

//MoT device structure
deviceCTL_t SPI_devicectl = (deviceCTL_t) {SPI_cmdHandler, MoT_skipTask, NULL,NULL, NULL, NULL, 0, 0};

// local variables (these could alternatively be defined in _LL using MoTvarAlloc
int32_t SPI_cyclecount, SPI_reload, SPI_count, SPI_data;

int32_t inputVal;
char * messageInput;
char intAsString[32];

//single-function messages (see _LL for alternative way of defining messages with MoTmsgAlloc)
msgLINK_t init_msg = { NULL, "SPI Full Duplex is initialized with SPI1-Master, SPI3-Slave\n\r", strlen("SPI Full Duplex is initialized with SPI1-Master, SPI3-Slave\n\r")};

msgLINK_t disable_msg_SPI = { NULL, "SPI Device Disabled \n\r", strlen("SPI Device Disabled \n\r")};


//external structures
extern msgLIST_t USART3_msglist;

msgLINK_t customMsg;


// ----- SPI command dispatch function
void SPI_cmdHandler(void *Cmdtail)	//dispatched in main() by MoT_doCmd(USART3_binbuf, CM7_devicelist ). On entry rDEVP points to SPI data structure
{
	switch(*((uint8_t *)Cmdtail)) {
		case 0:	start_init_SPItask(Cmdtail+1); break; 			// in MoTdevice_SPI_LL.S - initializes SPI1 as master, SPI3 as slave, Full Duplex 32bit transfers
		case 1:	start_MasterTxtask(Cmdtail+1); break; 			// Send word from Master MOSI to Slave MOSI
		case 2:	start_MasterRxtask(Cmdtail+1);break;			// Receive word on MISO
		case 3:	start_SlaveTxtask(Cmdtail+1); break;			// Send word from Slave MISO to Master MISO
		case 4:	start_SlaveRxtask(Cmdtail+1); break;			// Receive word on MOSI

		case 5:	start_MasterTxtask_polled(Cmdtail+1); break; 		// Continuous Send word from Master MOSI to Slave MOSI
		case 6:	start_MasterRxtask_polled(Cmdtail+1);break;			// Continuous Receive word on MISO
		case 7:	start_SlaveTxtask_polled(Cmdtail+1); break;			// Continuous Send word from Slave MISO to Master MISO
		case 8:	start_SlaveRxtask_polled(Cmdtail+1); break;			// Continuous Receive word on MOSI
		case 9: start_disable_SPItask(Cmdtail+1); break;			// Disable SPI Master and Slave
		default: ;
	}
	//how does this return?
}

// ----- SPI commands and tasks

void start_init_SPItask(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, init_SPItask);
}

void init_SPItask()
{
	init_SPI();
	MoT_postMsg(&init_msg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}


void start_MasterTxtask(void *Cmdtail1)
{
	SPI_reload = *(int32_t *)Cmdtail1;
	SPI_count = *(int32_t *)Cmdtail1;
	SPI_data = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, MasterTxtask);
}

void MasterTxtask()
{
	MasterTx(SPI_data);

	messageInput = "Data transmitted on MOSI: ";
	itoa(SPI_data, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);

	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

void start_MasterRxtask(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, MasterRxtask);
}

void MasterRxtask()
{
	inputVal = SPI1_Rx();

	messageInput = "Data Received on MISO: ";
	itoa(inputVal, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);

	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

void start_SlaveTxtask(void *Cmdtail1)
{
	SPI_reload = *(int32_t *)Cmdtail1;
	SPI_count = *(int32_t *)Cmdtail1;
	SPI_data = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, SlaveTxtask);
}

void SlaveTxtask()
{
	SlaveTx(SPI_data);

	messageInput = "Data transmitted on MISO: ";
	itoa(SPI_data, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);

	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

void start_SlaveRxtask(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, SlaveRxtask);
}
void SlaveRxtask()
{
	inputVal = SPI3_Rx();

	messageInput = "Data Received on MOSI: ";
	itoa(inputVal, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);

	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

//Polled/*****************************************************************************************************/

void start_MasterTxtask_polled(void *Cmdtail1)
{
	SPI_reload = *(int32_t *)Cmdtail1;
	SPI_count = *(int32_t *)Cmdtail1;
	SPI_data = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, MasterTxtask_polled);
}

void MasterTxtask_polled()
{
	MoT_linkTask( MoT_doCtask, MasterTxtask_polled);

	MasterTx(SPI_data);
	messageInput = "Data transmitted on MOSI: ";
	itoa(SPI_data, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);
	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);

	startSleep(10000); // Sleep Input task for GPIO_delay milliseconds


}

void start_MasterRxtask_polled(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, MasterRxtask_polled);
}

void MasterRxtask_polled()
{
	MoT_linkTask( MoT_doCtask, MasterRxtask_polled);

	inputVal = SPI1_Rx();
	messageInput = "Data Received on MISO: ";
	itoa(inputVal, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);
	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);



	startSleep(10000); // Sleep Input task for GPIO_delay milliseconds

}

void start_SlaveTxtask_polled(void *Cmdtail1)
{
	SPI_reload = *(int32_t *)Cmdtail1;
	SPI_count = *(int32_t *)Cmdtail1;
	SPI_data = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, SlaveTxtask_polled);
}

void SlaveTxtask_polled()
{
	SlaveTx(SPI_data);
	messageInput = "Data transmitted on MISO: ";
	itoa(SPI_data, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);
	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);

	startSleep(10000); // Sleep Input task for GPIO_delay milliseconds

	MoT_linkTask( MoT_doCtask, SlaveTxtask_polled);
}

void start_SlaveRxtask_polled(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, SlaveRxtask_polled);
}
void SlaveRxtask_polled()
{
	inputVal = SPI3_Rx();
	messageInput = "Data Received on MOSI: ";
	itoa(inputVal, intAsString, 10);   // here 10 means decimal
	strcat(messageInput, intAsString);
	customMsg = (msgLINK_t) { NULL, strcat(messageInput, "\n\r"), strlen(strcat(messageInput, "\n\r"))};
	MoT_postMsg(&customMsg, &USART3_msglist);

	startSleep(10000); // Sleep Input task for GPIO_delay milliseconds

	MoT_linkTask( MoT_doCtask, SlaveRxtask_polled);
}

//Disable

void start_disable_SPItask(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, disable_SPItask);
}

void disable_SPItask()
{
	disable_SPI();
	MoT_postMsg(&disable_msg_SPI, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

