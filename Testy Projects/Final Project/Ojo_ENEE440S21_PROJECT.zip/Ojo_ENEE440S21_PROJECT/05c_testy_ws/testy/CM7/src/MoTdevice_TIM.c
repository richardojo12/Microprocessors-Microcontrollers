//Motdevice_TIM.c
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "MoTstructures.h"

//TODO #include "MoTservices.h" to get
void MoT_linkTask( void(*)(), void(*)() );
void MoT_skipTask( );
void MoT_doCtask();
int MoT_postMsg(msgLINK_t *, msgLIST_t *); //puts message in queue for sending, return 0 if successful, non-zero if fail

//TODO #include "MoTdevice_redLED_LL.h"
void TIM3_PWM(void *);
void TIM3_PWM_Increase();
void TIM3_PWM_Decrease();

void TIM3_PFM(void *);
void TIM3_PFM_Increase();
void TIM3_PFM_Decrease();

void TIM3_greenLED_PWM_PFM();


// local functions
void start_TIM3_PWM_Increasetask(void *);
void TIM3_PWM_Increasetask();
void start_TIM3_PWM_Decreasetask(void *);
void TIM3_PWM_Decreasetask();

void start_TIM3_PFM_Increasetask(void *);
void TIM3_PFM_Increasetask();
void start_TIM3_PFM_Decreasetask(void *);
void TIM3_PFM_Decreasetask();

void start_TIM3_greenLED_PWM_PFM(void *);
void TIM3_greenLED_PWM_PFM_task();

//Disable
void start_TIM3_Disabletask(void *);
void TIM3_Disabletask();
void TIM3_Disable();

// local variables (these could alternatively be defined in _LL using MoTvarAlloc
//extern int32_t redLED_count,redLED_reload,redLED_cyclecount;
int32_t TIM3_cyclecount, TIM3_reload, TIM3_count;

//single-function messages (see _LL for alternative way of defining messages with MoTmsgAlloc)
msgLINK_t Increase_msg_pwm = { NULL, "TIM3 PWM Duty cycle increased 10% \n\r", strlen("TIM3 PWM Duty cycle increased 10% \n\r")};
msgLINK_t Decrease_msg_pwm = { NULL, "TIM3 PWM Duty cycle decreased 10% \n\r", strlen("TIM3 PWM Duty cycle decreased 10% \n\r")};

msgLINK_t Increase_msg_pfm = { NULL, "TIM3 PFM increased 10% \n\r", strlen("TIM3 PFM increased 10% \n\r")};
msgLINK_t Decrease_msg_pfm = { NULL, "TIM3 PFM decreased 10% \n\r", strlen("TIM3 PFM decreased 10% \n\r")};

msgLINK_t greenLED_msg = { NULL, "greenLED controlled by TIM3 PWM/PFM \n\r", strlen("greenLED controlled by TIM3 PWM/PFM \n\r")};

msgLINK_t disable_msg_TIM = { NULL, "TIM Disabled \n\r", strlen("TIM Disabled \n\r")};

//external structures
extern msgLIST_t USART3_msglist;

// ----- TIM command dispatch function
void TIM_cmdHandler(void *Cmdtail)	//dispatched in main() by MoT_doCmd(USART3_binbuf, CM7_devicelist ). On entry rDEVP points to redLED data structure
{
	switch(*((uint8_t *)Cmdtail)) {
		case 0:	TIM3_PWM(Cmdtail+1); break; 			// in MoTdevice_TIM3_LL.S - initializes TIM3 PWM
		case 1:	start_TIM3_PWM_Increasetask(Cmdtail+1); break; 		// see functin definiion below -
		case 2:	start_TIM3_PWM_Decreasetask(Cmdtail+1);break;			//  ""
		case 3:	TIM3_PFM(Cmdtail+1); break; 							//
		case 4:	start_TIM3_PFM_Increasetask(Cmdtail+1); break; 			//
		case 5:	start_TIM3_PFM_Decreasetask(Cmdtail+1);break;			//  ""
		case 6: start_TIM3_greenLED_PWM_PFM(Cmdtail+1); break; 			//
		case 7:	start_TIM3_Disabletask(Cmdtail+1); break;
		default: ;
	}
	//how does this return?
}

// ----- TIM commands and tasks
void start_TIM3_PWM_Increasetask(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, TIM3_PWM_Increasetask);
}

void TIM3_PWM_Increasetask()
{
	TIM3_PWM_Increase();
	MoT_postMsg(&Increase_msg_pwm, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
}

void start_TIM3_PWM_Decreasetask(void *Cmdtail1)
{
	MoT_linkTask( MoT_doCtask, TIM3_PWM_Decreasetask);
}

void TIM3_PWM_Decreasetask()
{
	TIM3_PWM_Decrease();
	MoT_postMsg(&Decrease_msg_pwm, &USART3_msglist);
	MoT_linkTask(MoT_skipTask, NULL);
	}

// PFM

	void start_TIM3_PFM_Increasetask(void *Cmdtail1)
	{
		MoT_linkTask( MoT_doCtask, TIM3_PFM_Increasetask);
	}

	void TIM3_PFM_Increasetask()
	{
		TIM3_PFM_Increase();
		MoT_postMsg(&Increase_msg_pfm, &USART3_msglist);
		MoT_linkTask(MoT_skipTask, NULL);
	}

	void start_TIM3_PFM_Decreasetask(void *Cmdtail1)
	{
		MoT_linkTask( MoT_doCtask, TIM3_PFM_Decreasetask);
	}

	void TIM3_PFM_Decreasetask()
	{
		TIM3_PFM_Decrease();
		MoT_postMsg(&Decrease_msg_pfm, &USART3_msglist);
		MoT_linkTask(MoT_skipTask, NULL);
	}

// Green LED


	void start_TIM3_greenLED_PWM_PFM(void *Cmdtail1)
	{
		MoT_linkTask( MoT_doCtask, TIM3_greenLED_PWM_PFM_task);
	}

	void TIM3_greenLED_PWM_PFM_task()
	{
		TIM3_greenLED_PWM_PFM();
		MoT_postMsg(&greenLED_msg, &USART3_msglist);
		MoT_linkTask(MoT_skipTask, NULL);
	}


//Disable

	void start_TIM3_Disabletask(void *Cmdtail1)
	{
		MoT_linkTask( MoT_doCtask, TIM3_Disabletask);
	}

	void TIM3_Disabletask()
	{
		TIM3_Disable();
		MoT_postMsg(&disable_msg_TIM, &USART3_msglist);
		MoT_linkTask(MoT_skipTask, NULL);
	}


