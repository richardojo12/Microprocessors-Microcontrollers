//Motdevice_redLED.c wmh 2021-04-26 : C version of MoTdevice_greenLED.S for comparison
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "MoTstructures.h"

//TODO #include "MoTservices.h" to get 
void MoT_linkTask( void(*)(), void(*)() );
void MoT_doCtask();
int MoT_postMsg(msgLINK_t *, msgLIST_t *); //puts message in queue for sending, return 0 if successful, non-zero if fail

//TODO #include "MoTdevice_redLED_LL.h" 
void init_redLED(void *);
void redLED_ON();
void redLED_OFF();

// local functions  
void start_ONtask(void *);
void redLED_ONtask();
void start_OFFtask(void *);
void redLED_OFFtask();

// local variables (these could alternatively be defined in _LL using MoTvarAlloc 
//extern int32_t redLED_count,redLED_reload,redLED_cyclecount; 
int32_t redLED_cyclecount, redLED_reload, redLED_count;

//single-function messages (see _LL for alternative way of defining messages with MoTmsgAlloc)
msgLINK_t ON_msg = { NULL, "redLED is 'ON'\n\r", strlen("redLED is 'ON'\n\r")};
msgLINK_t OFF_msg = { NULL, "redLED is 'OFF'\n\r", strlen("redLED is 'OFF'\n\r")};

//external structures
extern msgLIST_t USART3_msglist;

// ----- redLED command dispatch function
void redLED_cmdHandler(void *Cmdtail)	//dispatched in main() by MoT_doCmd(USART3_binbuf, CM7_devicelist ). On entry rDEVP points to redLED data structure
{
	switch(*((uint8_t *)Cmdtail)) {
		case 0:	init_redLED(Cmdtail+1); break; 			// in MoTdevice_redLED_LL.S - initializes GPIOB.14 as output
		case 1:	start_ONtask(Cmdtail+1); break; 		// see functin definiion below - 
		case 2:	start_OFFtask(Cmdtail+1);break;			//  ""
//		case 3:	report_GPIOBbit14(Cmdtail+1); break; 	// TODO
		default: ;										// TODO
	}
	//how does this return?
}

// ----- redLED commands and tasks
void start_ONtask(void *Cmdtail1) 
{
	redLED_reload = *(int32_t *)Cmdtail1;
	redLED_count = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, redLED_ONtask);
}

void redLED_ONtask()
{
	redLED_ON();
	if(redLED_reload != 0) { 	//counting is enabled
		if(redLED_count == 0) {	//redLED 'ON' is finished
			redLED_count = redLED_reload;
			MoT_linkTask( MoT_doCtask, redLED_OFFtask);
			MoT_postMsg(&OFF_msg, &USART3_msglist);
		} else {
			redLED_count--;
		}
	}
}	

void start_OFFtask(void *Cmdtail1) 
{
	redLED_reload = *(int32_t *)Cmdtail1;
	redLED_count = *(int32_t *)Cmdtail1;
	MoT_linkTask( MoT_doCtask, redLED_OFFtask);
}

void redLED_OFFtask()
{
	redLED_OFF();
	if(redLED_reload != 0) {	//counting is enabled
		if(redLED_count == 0) {	//redLED 'OFF' is finished
			redLED_count = redLED_reload;
			MoT_linkTask( MoT_doCtask, redLED_ONtask);
			MoT_postMsg(&ON_msg, &USART3_msglist);
		} else {
			redLED_count--;
		}
	}
}	
