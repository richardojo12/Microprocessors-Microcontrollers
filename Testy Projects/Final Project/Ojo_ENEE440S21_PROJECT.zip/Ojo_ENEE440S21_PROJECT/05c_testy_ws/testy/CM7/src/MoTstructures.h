//MoTstructures.h wmh 2021-04-21 : yet another tweek -- we are going to do the standard device data structure allocation here
//MoTstructures.h wmh 2021-04-12 : umpteenth revison of MoT data structures
// TODO (maybe) : assembly macro to define an initialized device data structure

#ifdef __ASSEMBLY__	  //dims colorization when #ifdef is exposed 

	rLISTP 		.req r4			@;points to dev_list[] entry; always valid on device function dispatch
	rDEVP		.req r5			@;points to data of current active task 

	// MoT device structure definitions (revised 2021-04-19)

	// MoT device control structure
	// Following are the required standard set of offsets relative to the origin of the data region allocated to a MoT device
	// This data in this location could be in the .data section so as to be automagically initialized to real values at startup. 
	// This standardized design of a MoT device's data structure may be used for either array-dispatch or linked-list dispatch of MoT tasks
	#define XEQCMD 0			// holds address of the device's command handler
	#define XEQTASK 4			// holds address of the device's task handler
	#define NEXTTASK 8			// holds address of the device's successor device in linked-list task design
	#define XEQC 12				// holds execution address of device task functions written in C (void-void functions to be dispatched by the XEQCMD)
	#define SLEEPSAVE 16		// preserves XEQTASK address when the device's XEQTASK is replaced by the 'sleep()' task's execution address
	#define TASKRESUME 20		// will hold return address of the task which called the sleep() task
	#define MSECWAKETIMELO 24	// will hold lsword of sleep()'s wakeup time (abs msecs)
	#define MSECWAKETIMEHI 28	// will hold msword of sleep()'s task wakeup time (abs msecs)
//	#define MSGLINK_T 32		// <<<< origin of the the default message link structure 'msgLINK__t' embedded in the device control structure
//	#define NEXTMSG 0			// (NB! offset relative to MSGLINK_T) holds offset of the device's successor message in a linked-list message design
//	#define MSGP 4				// (NB! offset relative to MSGLINK_T) holds byte pointer to bytes of a device message 
//	#define MSGCOUNT 8			// (NB! offset relative to MSGLINK_T) holds count of number of bytes in a device message

	//data that follows here can be anything required by the MoT device
	#define MOTDATA 32			// use this to reserve space at the top of each MoT task data structure for the device control parameters

	//macro below is to be defined at the top of the device; offsets above then reference internal elements of the structure 
	.macro MoTdevice devicename, cmdhandler, defaulttask	//create the standard MoT structure for this device
		.pushsection .data
		.align 2
		.global \devicename
		\devicename:
		.equ THISDEVICE,\devicename
		.word \cmdhandler 
		.word \defaulttask
		.skip (MOTDATA-8)
		.popsection
		.equ DEVICENAME,\devicename
	.endm

//	#define MSGLINK_T 32		// <<<< origin of the the default message link structure 'msgLINK__t' embedded in the device control structure
	#define NEXTMSG 0			// (NB! offset relative to MSGLINK_T) holds offset of the device's successor message in a linked-list message design
	#define MSGP 4				// (NB! offset relative to MSGLINK_T) holds byte pointer to bytes of a device message 
	#define MSGCOUNT 8			// (NB! offset relative to MSGLINK_T) holds count of number of bytes in a device message

	.macro MoTmsgAlloc msgname, msgoffset	//create a MoT general message structure for this device
		.pushsection .data
		.align 2
	//	.global \msgname
		\msgname:
		.word 0				//to hold link to next message initialized to NULL 
		.word 0				//to hold pointer of message text initiaized to NULL
		.word 0				//to hold bytecount of message text initiaized to 0 
		.equ \msgoffset, ( \msgname - THISDEVICE)
		.popsection
	.endm

	// new approach uses local device name as defined at top e.g. #define THISDEVICE greenLED
	.macro MoTmsgCreate  msgname, stringlabel=DEFAULT_MSGTXT, stringlen=DEFAULT_MSGLEN	//allocates a MoT message structure for msgname and  optionally initializes it
		.pushsection .data
		.align 2
	//	.global \msgname
		\msgname:
		.word 0				//link to next message initialized to NULL 
		.word \stringlabel	//address of message text
		.word \stringlen		//bytecount of message text initiaized to 0 
		.equ OFFSET\msgname, ( \msgname - THISDEVICE )
		.popsection
	.endm

	//Any data definitions required by the MoT device devined above should follow the above macro invocation
	.macro MoTvarAlloc  varname, varoffset
		.global \varname
		.pushsection .data
		.align 2
		\varname: .skip 4
		.equ \varoffset, (  \varname - THISDEVICE ) 
		.popsection
	.endm


	// Following are standard offsets relative to the origin of a MoT message list control structure msgLIST_t
	#define BYTEP 0				
	#define BYTECOUNT 4
	#define LISTHEADP 8
	#define LISTTAILP 12




#else	//not assembly, C !!TODO some mechanism for initializing MoT C-device data structure

typedef struct msgLINK {
	struct msgLINK *nextmsg;	//,0	holds address of the device's successor device in a linked-list message design
	char *msgp;					//,4	pointer to bytes of a device message 
	uint32_t msgcount;			//,8	count of number of bytes in message
} msgLINK_t; 

//Master control structure for devices. Each device will have the following data structure at its data origin. 
typedef struct deviceCTL {		//task control structure common to all tasks
	void (*xeqcmd)(void *);		//,0	execution address of a device command
	void (*xeqtask)(void);		//,4	coninuation address of a device task
	struct deviceCTL *nexttask;	//,8	holds address of the device's successor device in linked-list task design 
	void (*xeqC)(void);			//,12	holds address of a c task's execution address
	void (*sleepsave)(void);	//,16	holds xeqtask value of a sleeping task
	void (*sleepresume)(void);	//,20	holds return address of the call to the sleep function
	uint32_t msecwaketimelo;	//,24	holds lsword of task wakeup time (abs msecs)
	uint32_t msecwaketimehi;	//,28	holds msword of task wakeup time (abs msecs)
//	msgLINK_t devmsg;			//,32,36,40	holds device default nextmsg, msgp and msgcount
} deviceCTL_t;

//message list control structure
typedef struct msgLIST {
	uint8_t *bytep;				//,0	pointer to remaining bytes of a device message 
	uint32_t bytecount;			//,4	count of number of bytes remaining in message
	msgLINK_t *listheadp;		//,8	pointer to 1st device in the list of devices having messages (where we get characters for sending)
	msgLINK_t *listtailp;		//,12	pointer to final device in the list of devices having messages (where we append new messages)
} msgLIST_t;



#endif
