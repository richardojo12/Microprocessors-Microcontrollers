//CM7main02.c for scratch build wmh 2020-09-07 : do-nothing main

	#include <stdint.h>

//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOxBITn();				//in GreenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""

//definitions in myDataOps.S
uint32_t *DwordAddress(void);				//returns pointer to variable 'Dword' defined in myDataOps.S
uint32_t getDwordContents(void);			//returns value stored in variable 'Dword' defined in myDataOps.S
void addToDwordContents(int32_t addend);	//adds value 'addend' to value stored in variable 'Dword' defined in myDataOps.S

uint32_t *loadConstant02(int32_t consVal);	//load value 'consVal' into register r1
uint32_t *loadConstant03(void);	//load 7252 into register r0
uint32_t *loadConstant04(void);	//load value #0x000B into register r0, setting flags
uint32_t *loadConstant05(void);	//load value #0xfffffffe(!0x0001) into register r0
uint32_t *loadConstant06(void);	//load value #0xffffffef(!0x0010) into register r0, setting flags


int main() 
{
	uint32_t worddata,*pworddata;			//C values we can watch in main()
	
	//Problem 1
	//load value into register r1, r1 <- r0
	pworddata  = loadConstant02(0x00000362);
	// r0 <- 7252
	pworddata  = loadConstant03();
	// r0 <- #0x000B, setting flags
	pworddata  = loadConstant04();
	// r0 <- !0x0001
	pworddata  = loadConstant05();
	// r0 <- !0x0010
	pworddata  = loadConstant06();

	pworddata=DwordAddress();				//demo call to myDataOps.S
	worddata=getDwordContents();			// ""
	addToDwordContents(0xFFFFFFFF);			// ""

	initGPIOxBITn();	//""

	while(1){ //blink Green LED
		if(SysTick_msecs<500) setGPIOxBITn();
		else resetGPIOxBITn();
	}

	return 0;	//eliminate warning
}
