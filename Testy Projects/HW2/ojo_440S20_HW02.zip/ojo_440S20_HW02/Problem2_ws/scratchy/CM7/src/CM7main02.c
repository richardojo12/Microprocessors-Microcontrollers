//CM7main02.c for scratch build wmh 2020-09-07 : do-nothing main

	#include <stdint.h>

//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOxBITn();				//in GreenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""

//definitions in myDataOps.S
uint32_t *DwordAddress(void);				//returns pointer to variable 'Dword' defined in myDataOps.S
uint32_t getDwordContents(void);			//returns value stored in variable 'Dword' defined in myDataOps.S
void addToDwordContents(int32_t addend);	//adds value 'addend' to value stored in variable 'Dword' defined in myDataOps.S

uint32_t *loadVARIABLE_01(void);	// Load value at location stored in r1 into r0
uint32_t *loadVARIABLE_02(void);	// Load lower byte value at location stored in r0 into r1, unsigned
uint32_t *loadVARIABLE_03(void);	// Load lower byte value at location stored in r0 into r1, signed
uint32_t *loadVARIABLE_04(void);	// Load immediate value at location stored in r0 into r2 and value at location stored in r0 offest by 4 bits into r3
uint32_t *loadVARIABLE_05(void);	// Loads R2 from a word 4 bytes above the address in r1, and increments R1 by 4, pre indexed
uint32_t *loadVARIABLE_06(void);	// Loads R2 from a word at the address in r1, and increments R1 by 4, post indexed
uint32_t *loadVARIABLE_07(void);	// Loads R2 from a word at the address in r1,
 	 	 	 	 	 	 	 	 	// and Loads R3 from a word at the address 4 bytes above the address in r1 and increment r1 by 4, post indexed
uint32_t *loadVARIABLE_08(int32_t address); // Load word from address defined  into r1
uint32_t *loadVARIABLE_09(void);	// Load unsigned halfword word into r1 from address in r0
uint32_t *loadVARIABLE_10(void);	// Load signed halfword word into r1 from address in r0
uint32_t *loadVARIABLE_11(void);	// Load word into r2 from address in r0 if condition (r0 >= 0)
uint32_t *loadVARIABLE_12(int32_t value);	// Load word at address defined by value into r2 if condition ((value) < 0)
uint32_t *loadVARIABLE_13(int32_t value);	// Load word at address defined by value into r2 if condition ((value) >= 0)
void loadVARIABLE_14(void);			// Load word into r2 at address r0 + r1
uint32_t *loadVARIABLE_15(int32_t address);	// Load word into r2 at address r1 + address


int main() 
{
	uint32_t worddata,*pworddata;			//C values we can watch in main()

	//Problem 2
	//load value at location stored in r0 into r [7:0] register r1, r1 <- ((r0))
	pworddata  = loadVARIABLE_01();

	//load value at location stored in r0 into register r1, r1 <- ((r0)) [7:0], unsigned
	pworddata  = loadVARIABLE_02();

	//load value at location stored in r0 into register r1, r1 <- ((r0)) [7:0], signed
	pworddata  = loadVARIABLE_03();

	//Load immediate value at location stored in r0 into r2 and value at location stored in r0 offest by 4 bits into r3
	//r2 <- ((r0)), r3 <- ((r0) + 4)
	pworddata  = loadVARIABLE_04();

	//Loads R2 from a word 32 bytes above the address in r1, and increments R1 by 4, pre indexed
	//r2 <- ((r1) + 4), r1 <- ((r1)) + 4
	pworddata  = loadVARIABLE_05();

	//Loads R2 from a word at the address in r1, and increments R1 by 4, post indexed
	//r2 <- ((r1)), r1 <- ((r1)) + 4
	pworddata  = loadVARIABLE_06();

	// Loads R2 from a word at the address in r1,
	// and Loads R3 from a word at the address 4 bytes above the address in r1
	// increment r1 by 4
	//r2 <- ((r1)), r3 <- ((r1) + 4bytes), r1 <- ((r1)) + 4
	pworddata  = loadVARIABLE_07();

	//Load word from address defined  into r1
	// r1 <- ((0x24))
	pworddata  = loadVARIABLE_08(0x24000000);

	//Load unsigned halfword word (ls 16 bits)into r1 from address in r0
	// r1 <- ((r0))[15:0]
	pworddata  = loadVARIABLE_09();

	//Load signed halfword word (ls 16 bits)into r1 from address in r0
	// r1 <- ((r0))[15:0]
	pworddata  = loadVARIABLE_10();

	//Load word into r2 from address in r0 if condition (r0 >= 0)
	// if (r0 >= 0) r2 <- ((r0))
	pworddata  = loadVARIABLE_11();

	//Load word at address defined by value into r2 if condition ((value) < 0)
	//r1 <- ((value)) if (value < 0 )
	pworddata  = loadVARIABLE_12(0x12);

	//Load word at address defined by value into r2 if condition ((value) >= 0)
	//r1 <- ((value)) if ((value) >= 0 )
	pworddata  = loadVARIABLE_13(0x24000000);

	//Load word into r2 at address r0 + r1
	// r2 <- (((r0)) + ((r1)))
	loadVARIABLE_14();

	//Load word into r2 at address r1 + address
	// r2 <- (((r1)) + address)
	pworddata = loadVARIABLE_15(0x24000000);


	pworddata=DwordAddress();				//demo call to myDataOps.S

	worddata=getDwordContents();			// ""

	addToDwordContents(0xFFFFFFFF);			// ""

	initGPIOxBITn();	//""

	while(1){ //blink Green LED
		if(SysTick_msecs<500) setGPIOxBITn();
		else resetGPIOxBITn();
	}

	return 0;	//eliminate warning
}
