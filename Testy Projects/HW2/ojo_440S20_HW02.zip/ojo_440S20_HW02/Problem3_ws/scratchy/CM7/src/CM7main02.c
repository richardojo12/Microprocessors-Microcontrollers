//CM7main02.c for scratch build wmh 2020-09-07 : do-nothing main

	#include <stdint.h>

//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOxBITn();				//in GreenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""

//definitions in myDataOps.S
uint32_t *DwordAddress(void);				//returns pointer to variable 'Dword' defined in myDataOps.S
uint32_t getDwordContents(void);			//returns value stored in variable 'Dword' defined in myDataOps.S
void addToDwordContents(int32_t addend);	//adds value 'addend' to value stored in variable 'Dword' defined in myDataOps.S

uint32_t *storeVARIABLE_01(void);	// store value in r1 to address in r0
uint32_t *storeVARIABLE_02(void);	// store lower byte of r1 into location stored in r0
uint32_t *storeVARIABLE_03(void);	// store lower byte of r1 into location stored in 4 bytes above r0
uint32_t *storeVARIABLE_04(void);	// store immediate value at r2 into location stored in r0 and store r3 to a word 4 bytes above the address in r0
uint32_t *storeVARIABLE_05(void);	// store R2 into a word 4 bytes above the address in r1, and increments R1 by 4, pre indexed
uint32_t *storeVARIABLE_06(void);	// store R2 into a word at the address in r1, and increments R1 by 4, post indexed
uint32_t *storeVARIABLE_07(void);	// store R2 into a word at the address in r1, and store R3 into a word at the address 4 bytes above the address in r1
									// increment r1 by 4, post indexed
uint32_t *storeVARIABLE_08(int32_t address); // store word from address defined  into location in r1
uint32_t *storeVARIABLE_09(void);	// store unsigned halfword word r1 into address in r0
uint32_t *storeVARIABLE_10(void);	// store unsigned halfword word r1 into address in r0, increment r0 by 4
uint32_t *storeVARIABLE_11(void);	// store word in r2 into address in r0 if condition
uint32_t *storeVARIABLE_12(int32_t value);	// store value into address in r2 if condition (value < 0)
uint32_t *storeVARIABLE_13(int32_t value);	// store value into address in r2 if condition (value >= 0)
void storeVARIABLE_14(void);			// store word in r2 into address r0 + r1
uint32_t *storeVARIABLE_15(int32_t address);	// store word in r2 into address r1 + address


int main() 
{
	uint32_t worddata,*pworddata;			//C values we can watch in main()

	//Problem 3
	//store value in r1 to address in r0  ((r0)) <- r1
	pworddata  = storeVARIABLE_01();

	//store lower byte of r1 into location stored in r0, unsigned ((r0)) <- r1 [15:0]
	pworddata  = storeVARIABLE_02();

	//store lower byte of r1 into location stored in 4 bytes above r0 ((r0) + 4 bytes) <- r1 [15:0]
	pworddata  = storeVARIABLE_03();

	//store immediate value at r2 into location stored in r0
	//and store r3 to a word 4 bytes above the address in r0
	//((r0)) <- r2, ((r0)) <- ((r3) + 4bytes)
	pworddata  = storeVARIABLE_04();

	//store R2 into a word 4 bytes above the address in r1, and increments R1 by 4, pre indexed
	//((r1) + 4)<- r2, r1 <- ((r1)) + 4
	pworddata  = storeVARIABLE_05();

	//store R2 into a word at the address in r1, and increments R1 by 4, post indexed
	//((r1)) <- r2, r1 <- ((r1)) + 4
	pworddata  = storeVARIABLE_06();

	// store R2 into a word at the address in r1, and store R3 into a word at the address 4 bytes above the address in r1
	// increment r1 by 4, post indexed
	//((r1)) <- r2, ((r1) + 4bytes) <- r3, r1 <- ((r1)) + 4
	pworddata  = storeVARIABLE_07();

	//store word from address defined  into location in r1
	// ((r1)) <- address
	pworddata  = storeVARIABLE_08(0x24000000);

	//store unsigned halfword word r1 into address in r0
	// ((r0)) <- r1 [15:0]
	pworddata  = storeVARIABLE_09();

	//store unsigned halfword word r1 into address in r0, increment r0 by 4
	// r0 <- r1[15:0], r0 <- ((r0) + 4)
	pworddata  = storeVARIABLE_10();

	//store word in r2 into address in r0 if condition
	// if (r0 >= 0) r2 <- ((r0))
	pworddata  = storeVARIABLE_11();

	//store value into address in r2 if condition (value < 0)
	//((r1)) <- value if (value < 0)
	pworddata  = storeVARIABLE_12(0x12);

	//store value into address in r2 if condition (value >= 0)
	//((r1)) <- value if (value >= 0)
	pworddata  = storeVARIABLE_13(0x24000000);

	//store word in r2 into address r0 + r1
	// ((r0 + r1)) <- r2
	storeVARIABLE_14();

	//store word in r2 into address r1 + address
	//((r1 + address)) <- r2
	pworddata = storeVARIABLE_15(0x24000000);


	pworddata=DwordAddress();				//demo call to myDataOps.S

	worddata=getDwordContents();			// ""

	addToDwordContents(0xFFFFFFFF);			// ""

	initGPIOxBITn();	//""

	while(1){ //blink Green LED
		if(SysTick_msecs<500) setGPIOxBITn();
		else resetGPIOxBITn();
	}

	return 0;	//eliminate warning
}
