//CM7main01.c for scratch build wmh 2020-08-07 : do-nothing main

	#include <stdint.h>

//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOxBITn();				//in GreenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""

//functions defined in HW03_conversions.S
int32_t ifelse_dec2val (char *);	//returns the value of up to 9-digits decimal strings;  returns r0=-1 if fail. 
int32_t ifelse_hex2val (char *);	//returns r0= value of up to 8-digits hexdecimal strings, Z flag=0 if success; else Z flag=1 
int32_t IT_dec2val (char *);		//returns r0= value of up to 9-digits hexadecimal strings;  returns r0=-1 if fail. 
int32_t IT_hex2val (char *);		//returns r0= value of up to 8-digits hexadecimal strings, Z flag=0 if success; else Z flag=1 
int32_t TBB_dec2val (char *);		//returns r0= value of up to 9-digits hexadecimal strings;  returns r0=-1 if fail. 
int32_t TBB_hex2val (char *);		//returns r0= value of up to 8-digits hexadecimal strings, Z flag=0 if success; else Z flag=1 


int main() 
{
	initGPIOxBITn();	//""

	// HW03 Problem 4 -- head to head comparison of hex number conversion methods
	// When your functions for HM03 problems 1-3 work correctly, run the following so we can judge which is faster

	int ifelse_counter,ifelse_finalcount=0;
	int IT_counter,IT_finalcount=0;
	int TBB_counter,TBB_finalcount=0;
	int ret;

	while(1) {	//benchmark various hex to decimal conversion methods

		setGPIOxBITn();						//let them know we're alive
	
		ifelse_counter=0;

		while(SysTick_msecs<500){ 			//do the conversion method for 1/2 second
			ret= ifelse_hex2val("1234ABCD");
			ret= ifelse_hex2val("1234XBCD");
			ret= ifelse_hex2val("F");
			ret= ifelse_hex2val("");
			ret= ifelse_hex2val("FFFFFFFF");
			ifelse_counter +=1;
		}
		ifelse_finalcount=ifelse_counter;	//update the cycle count (higher is better)
		resetGPIOxBITn();					//still alive
		while(SysTick_msecs>=500);			// .. killing time
			
		//--- testing IT
		setGPIOxBITn();						//still alive
		IT_counter=0;
		while(SysTick_msecs<500){ 			//do the conversion method for 1/2 second
			ret= IT_hex2val("1234ABCD");
			ret= IT_hex2val("1234XBCD");
			ret= IT_hex2val("F");
			ret= IT_hex2val("");
			ret= IT_hex2val("FFFFFFFF");
			IT_counter +=1;
		}
		IT_finalcount=IT_counter;			//update the cycle count (higher is better)
		resetGPIOxBITn();					//still alive
		while(SysTick_msecs>=500);			// .. killing time

			
		//--- testing TBB
		setGPIOxBITn();						//still alive
		TBB_counter=0;
		while(SysTick_msecs<500){ 			//do the conversion method for 1/2 second
			ret= TBB_hex2val("1234ABCD");
			ret= TBB_hex2val("1234XBCD");
			ret= TBB_hex2val("F");
			ret= TBB_hex2val("");
			ret= TBB_hex2val("FFFFFFFF");
			TBB_counter +=1;
		}
		TBB_finalcount=TBB_counter;			//update the cycle count (higher is better)
		resetGPIOxBITn();					//still alive
		while(SysTick_msecs>=500);			// .. killing time
	}		
}
