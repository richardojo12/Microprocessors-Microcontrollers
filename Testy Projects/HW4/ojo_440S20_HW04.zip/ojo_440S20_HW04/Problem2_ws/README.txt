rpnCalc function is contained in myDataOps01.S

myLookups.S was also modified to extend usability to operators 

64b x 64b multiplication will return -1 if there is an overflow

Division and Mod is with 32b operands

&, |, ^ operate on 2 operands

!, L, R operate on the most recent operand

E.x. ("1 3 L +") -> ("1 6 +") -> returns 7 
	i.e. 3 was left shifted by 1 then added with 1