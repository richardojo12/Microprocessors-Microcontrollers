//CM7main03.c for scratch build wmh 2021-02-17 : test of 64-bit AAPCS
//CM7main02.c for scratch build wmh 2020-09-07 : do-nothing main

	#include <stdint.h>

//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOxBITn();				//in GreenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""

//definitions in old myDataOps.S
uint32_t *DwordAddress(void);				//returns pointer to variable 'Dword' defined in myDataOps.S
uint32_t getDwordContents(void);			//returns value stored in variable 'Dword' defined in myDataOps.S
void addToDwordContents(int32_t addend);	//adds value 'addend' to value stored in variable 'Dword' defined in myDataOps.S


//definitions in new myDataOps01.S
extern uint64_t xdata64u;					//'double word' defined in myDataOps01.S 
uint64_t add64u(uint64_t, uint64_t);		// function in myDataOps01.S used to inspect 64-bit argument passing and return

//definition in myLookups.S
int32_t xlatASCII(int8_t); 					// demo function in myLookups.  Returns translated value of input character or -1 if no valid translation

uint64_t RPNcalc(char *);						//RPN calc using string passed in, function defined in myDataOps.S

int main() 
{
	//stuff for 64-bit investigation
	uint64_t ldata64u;	 					//local 'double word' definitions
	uint64_t *pdata64u;
	pdata64u = &ldata64u;
	ldata64u = 0x12345678FFFFFFFF;
	ldata64u = add64u(ldata64u,1); 

	//stuff for table lookup demo
	int32_t c;
	c =  xlatASCII('2');
	c =  xlatASCII('B');
	c =  xlatASCII('b');
	c =  xlatASCII('x');
	c =  xlatASCII(128);

	uint64_t d = 0;
/*	d =  RPNcalc("1 12345678AB *");
	d =  RPNcalc("1234556789 12345678 +");
	d =  RPNcalc("123456789 123456788 -");
	d =  RPNcalc("4 2 /");
	d =  RPNcalc("12345678AAABAAAA 12345678AAAAAAAA -");
	d =  RPNcalc("1F 5 %");
	d =  RPNcalc("1 12345678AB + 1 +");*/

	d =  RPNcalc("1 12345678AB &");
	d =  RPNcalc("1234556789 12345678 |");
	d =  RPNcalc("123456789 123456788 ^");
	d =  RPNcalc("123456!");
	d =  RPNcalc("12345678AAABAAAA L");
	d =  RPNcalc("1F R");


	uint32_t worddata,*pworddata;			//C values we can watch in main()
	pworddata=DwordAddress();				//demo call to myDataOps.S

	worddata=getDwordContents();			// ""
	addToDwordContents(0xFFFFFFFF);			// ""

	initGPIOxBITn();	//""

	while(1){ //blink Green LED
		if(SysTick_msecs<500) setGPIOxBITn();
		else resetGPIOxBITn();
	}

	return 0;	//eliminate warning
}
