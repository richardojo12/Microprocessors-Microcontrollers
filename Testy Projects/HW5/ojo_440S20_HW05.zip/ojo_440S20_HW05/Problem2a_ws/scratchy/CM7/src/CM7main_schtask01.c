//CM7main_schtask01.c wmh 202-03-05 : demo of linked-list for scheduling
// An array of 'schtask_t' scheduled event elements is defined.
//
// Function "schtasks_init()"  links the list of scheduled events and initializes them
// to turn the Nucleo-H745 board's green LED on and off at 1000msec intervals.
//
// Function "try_pendingtask()" check the schtask_t element pointed to by pendingtaskp (the list head)
// and dispatches the head element's task when its scheduled time is the same or greater than SysTick_absmsecs.

	#include <stddef.h>		//for NULL
	#include <stdint.h>		//for uint32_t etc 

	#define NUMTASKS 10

//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOxBITn();				//in GreenLED.S
void setGPIOxBITn(void *);			// new void * argument
void resetGPIOxBITn(void *);		// ""


typedef struct schtask {
	struct schtask *next; 		// schtask pointng to itself marks the end of the list
	uint64_t absmsecs; 			// when to perform the below task (SysTick_Handler time)
	void (*task)(void *); 		// address of task to perform
	void *taskargp; 			// (optional) address of argument of the task
} schtask_t;

schtask_t *pendingtaskp = (schtask_t *)NULL;	//will hold address of head element in schedule queue
schtask_t schtasks[NUMTASKS];					//uninitialized array of tasks

schtask_t * schtasks_init(schtask_t schtasks[], uint32_t numtasks) //initializes task list for testing
{ 
	int i;
	for(i=0;i<(numtasks-1);i++) {	//link and initialize list of schtasks to alternate 'set' and 'reset' green LED at 1000 msec intervals
		if(i%2) schtasks[i] = (schtask_t) { &schtasks[i+1],(uint64_t)(i*1000),setGPIOxBITn,NULL }; 	//odd-numbered tasks set GPIOx bit
		else 	schtasks[i] = (schtask_t) { &schtasks[i+1],(uint64_t)(i*1000),resetGPIOxBITn,NULL};	//even-numbered tasks reset GPIOx bit
	}
	schtasks[numtasks-1] = 	(schtask_t){ &schtasks[numtasks-1],(numtasks-1)*1000,resetGPIOxBITn,NULL};	// mark last task as 'final' (see note)
	return schtasks;																			// to set first task as 'pending'
}
//note: 'point to itself' convention for terminating list makes the list 'append' function faster/simpler when list is dynamic

schtask_t * try_pendingtask ( schtask_t *pendingtaskp ) //executes pending task (if any) at scheduled time, updates task list
{
	if( pendingtaskp != NULL ) { 							//verify task exists
		if( pendingtaskp->absmsecs <= SysTick_absmsecs ) {  // have we reached a scheduled event?
			pendingtaskp->task(NULL);						//	 - yes : perform event task
			if( pendingtaskp->next == pendingtaskp ) {		//	   is this the final task on the task list? (see note above)
				pendingtaskp = NULL;						//			- yes : mark list as 'finished'
			} else {										//			- no : update to next task on list
				pendingtaskp = pendingtaskp->next;			//				.. 
			}
		}
	}
	return pendingtaskp;
}


int main() 
{
	SysTick_absmsecs = 0;									//initiaize SysTick values (in SysTick64MHz.s)
	SysTick_msecs = 0;										// ""
	SysTick_secs = 0;										// ""
	initGPIOxBITn();										//initialize greenLED output bit
	pendingtaskp = schtasks_init(schtasks, NUMTASKS); 		//initialize task list for testing

	/* Struct Schtask Offsets
	 * Next -> 0x8
	 * Absmsecs -> 0x10
	 * Task -> 0x14
	 * */
	//int x = offsetof(struct schtask, taskargp);
	/*uint64_t x = 0;

		x = offsetof(struct schtask, absmsecs);
		x = offsetof(struct schtask, task);*/

	while(1);

	//while(1){ //blink Green LED
	//	pendingtaskp = try_pendingtask( pendingtaskp );
	//}

	return 0;	//to eliminate compiler warning
}
