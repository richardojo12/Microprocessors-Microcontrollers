Systick was updated in SysTick64MHz.S
PendSV_Handler was added to SysTick64MHz.S
I made a function in C that's called by the Systick_Handler, which
sometimes adds a PendSV event to the deferred list.