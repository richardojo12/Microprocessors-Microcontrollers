//CM7main_pendtask01.c wmh 2021-03-08 : demo of a dynamic linked-list for queueing pendSV tasks
//  A pending task structure 'pendSV_t' is defined.  A set of 'pendSV_t' is initialized with a set of task functions. 
//  The function 'add_pendSV() is defined and used to place the pendSV_t structures on the pending task list.
//  The PendSV interrupt is enabled and the pended tasks are executed from the list. 
//CM7main_schtask02.c wmh 2021-03-08 : renames 'pendingtaskp' as 'schtaskp' to reduce confusion
//CM7main_schtask01.c wmh 2021-03-05 : demo of linked-list which schedules tasks for the SysTick interrupt

	#include <stddef.h>		//for NULL
	#include <stdint.h>		//for uint32_t etc 

/*Delete later*/
	#include <stdio.h>

	#define NUMTASKS 10 

//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOxBITn();				//in GreenLED.S
void setGPIOxBITn(void *);			// new void * argument
void resetGPIOxBITn(void *);		// ""

////////////////////////////// Systick tasks (original demo in CM7main_schtask02.c) /////////////////////////////////// 
typedef struct schtask {
	struct schtask *next; 			// schtask pointing to itself marks the end of the list
	uint64_t absmsecs; 				// when to perform the below task (SysTick_Handler time)
	void (*task)(void *); 			// address of task to perform
	void *taskargp; 				// (optional) address of argument of the task, accessible through taskp
} schtask_t;

schtask_t *schtaskp = (schtask_t *)NULL;		//will hold address of head element in schedule queue
schtask_t schtasks[NUMTASKS];					//uninitialized array of tasks

//note: 'point to itself' convention for terminating list makes the list 'append' function faster/simpler when list is dynamic

schtask_t * try_schtask ( schtask_t *schtaskp ) //executes task (if any) at scheduled time, updates task list
{
	if( schtaskp != NULL ) { 								//verify task exists
		if( schtaskp->absmsecs <= SysTick_absmsecs ) {  	// have we reached a scheduled event?
			schtaskp->task(NULL);							//	 - yes : perform event task
			if( schtaskp->next == schtaskp ) {				//	   is this the final task on the task list? (see note above)
				schtaskp = NULL;							//			- yes : mark list as 'finished'
			} else {										//			- no : update to next task on list
				schtaskp = schtaskp->next;					//				.. 
			}
		}
	}
	return schtaskp;
}

schtask_t * schtasks_init(schtask_t schtasks[], uint32_t numtasks) //initializes task list for testing
{
	int i;
	for(i=0;i<(numtasks-1);i++) {	//link and initialize list of schtasks to alternate 'set' and 'reset' green LED at 1000 msec intervals
		if(i%2) schtasks[i] = (schtask_t) { &schtasks[i+1],(uint64_t)(i*1000),setGPIOxBITn,NULL }; 	//odd-numbered tasks set GPIOx bit
		else 	schtasks[i] = (schtask_t) { &schtasks[i+1],(uint64_t)(i*1000),resetGPIOxBITn,NULL};	//even-numbered tasks reset GPIOx bit
	}
	schtasks[numtasks-1] = 	(schtask_t){ &schtasks[numtasks-1],(numtasks-1)*1000,resetGPIOxBITn,NULL};	// mark last task as 'final' (see note)
	return schtasks;																			// to set first task as 'pending'
}

//////////////////////////// PendSV tasks (new demo here (in CM7main_pendtask01.c) /////////////////////////////
typedef struct pendSV_task {
	struct pendSV_task *next; 	// pendtask pointng to itself marks the end of the list
	void (*task)(); 			// address of task to be performed
	void *taskargp; 			// (optional) address of argument of the task, acessible through the task pointer
} pendSV_t;

pendSV_t * pendSV_headp = NULL;	// (global) points to current head of pendSV task list
pendSV_t * pendSV_tailp = NULL;	// (global) points to current tail of pendSV task list

void add_pendSV (pendSV_t *new_pendSV) { 	//when called in SysTick_Handler, critical region concerns are eliminated
	if( pendSV_tailp == NULL ) {			//is pendSV list empty?
		pendSV_headp = new_pendSV ;			//	 yes - make new pendSV first 
		pendSV_tailp = new_pendSV ;			//		and last on list
		new_pendSV->next = new_pendSV ;		//			and mark it 'last'
	} 
	else { 									//list is not empty
		pendSV_tailp->next = new_pendSV; 	// link new pendSV from old end of list
		pendSV_tailp = new_pendSV ;			//	make new pendSV end of list
		new_pendSV->next = new_pendSV ;		//	  and mark it 'last'
	}
}

/*
void PendSV_Handler() { 	// PendSV interrupt. Pulls tasks from pendSV task list and dispatches pulled tasks until list is empty. 
	while( pendSV_headp != NULL ) { 				// the list is not empty
		pendSV_headp->task();						// so dispatch function of current head of list task
		//continue here after doing the pendSV task
		if( pendSV_headp == pendSV_headp->next ) { 	// is the current head of the list the last list element?
			pendSV_headp = NULL;					//	yes -- mark the list empty
			pendSV_tailp = NULL;					//    ..
		}
		else { //advance to the next task
			pendSV_headp = pendSV_headp->next;
		}
	}
	//here when the pendSV list is exhausted
} */

//software delay
void delay(int t) { for ( ; t>0; )t--; }			//silly 'for()' specification to quiet warning

//pendSV functions
void fastblinks( int count) {int i; for(i=0; i<2*count;i++) { if(i%2) { setGPIOxBITn(NULL); delay(500000); } else { resetGPIOxBITn(NULL); delay(500000);} } }
void slowblinks( int count) {int i; for(i=0; i<2*count;i++) { if(i%2) { setGPIOxBITn(NULL); delay(1500000); } else { resetGPIOxBITn(NULL); delay(1500000);} } }

//pendSV functions
void fast5()  { fastblinks(5); }
void fast10() { fastblinks(10); }
void fast20() { fastblinks(20); }
void slow3()  { slowblinks(3); }
void slow6()  { slowblinks(6); }
void slow12() { slowblinks(12); }

//pendsv tasks
pendSV_t  pendSV_fast5 =	{ (pendSV_t *) NULL, fast5, NULL };
pendSV_t  pendSV_fast10 =	{ (pendSV_t *) NULL, fast10, NULL };
pendSV_t  pendSV_fast20 =	{ (pendSV_t *) NULL, fast20, NULL };
pendSV_t  pendSV_slow3 =	{ (pendSV_t *) NULL, slow3, NULL };
pendSV_t  pendSV_slow6 =	{ (pendSV_t *) NULL, slow6, NULL };
pendSV_t  pendSV_slow12 =	{ (pendSV_t *) NULL, slow12, NULL };

//pendsv control (note: incomplete -- does _not_ set PendSV interrupt priority)
void enable_PendSV() {		
	uint32_t *pICSR = (uint32_t *)0xE000ED04 ;				//can be observed in debugger in SCB/ICSR
	*pICSR = (1<<28);
}

int j = 0;

void generateAndAddPendSV(){
	if (j%2){
		 void fastblinksc()  { fastblinks(j); };
	 	 pendSV_t  pendSV_fasti =	{ (pendSV_t *) NULL, fastblinksc, NULL };
	 	 add_pendSV(&pendSV_fasti);
	}else if (j %3){
		void slowblinksc()  { slowblinks(j); };
		pendSV_t  pendSV_slowi =	{ (pendSV_t *) NULL, slowblinksc, NULL };
		add_pendSV(&pendSV_slowi);
	}

	j++;
}

int main() 
{
	SysTick_absmsecs = 0;									//initialize SysTick values (in SysTick64MHz.s)
	SysTick_msecs = 0;										// ""
	SysTick_secs = 0;										// ""
	initGPIOxBITn();										//initialize greenLED output bit


	schtaskp = schtasks_init(schtasks, NUMTASKS); 		//initialize task list for testing


	//build test-list of pendSV tasks

/*	add_pendSV( &pendSV_fast5 );
	add_pendSV( &pendSV_slow3 );
	add_pendSV( &pendSV_fast10 );
	add_pendSV( &pendSV_slow6 );
	add_pendSV( &pendSV_fast20 );
	add_pendSV( &pendSV_slow12 );*/

	//PendSV_Handler();										//function test before running under interrupt as below (disabled)

	//enable_PendSV();										//should run pendSV tasks in the order added


	while(1);												//trap when done

	return 0;	//to eliminate compiler warning
}

