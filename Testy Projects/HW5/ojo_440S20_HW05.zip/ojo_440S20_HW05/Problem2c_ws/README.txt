Systick was updated in SysTick64MHz.S
PendSV_Handler was added to SysTick64MHz.S
SVC_Handler, SVC2, SVC3 was added to SysTick64MHz.S
SVC_Handler's priority is set to Highest (0x00) in Systick_Handler
schtasks_init creates systick events that trigger SVC2 or SVC3