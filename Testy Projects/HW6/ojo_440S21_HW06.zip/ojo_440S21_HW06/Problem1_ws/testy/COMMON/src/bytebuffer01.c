//bytebuffer01.c wmh 2020-08-12 : design for control structure of communication buffers between CM4 and CM7
// These are block buffers rather than fifos.  They operate in a 'write phase' with data written to them by a 'producer process'
// until the producer process turns them over to a 'consumer process' which operates them in a 'read phase'
// The read phase and write phase are distinguised from each other by the sign of 'currcount'. currcount <= 0: write phase; >0: read phase

//	#include <stdint.h>	//for int32_t, etc
//	#include <stddef.h>	//for size_t()
	#include "bytebuffer.h"

	/* in bytebuffer.h
	//'bytebuf_t' buffer control structure
	//These are placed in separate sections in SRAM3 to control buffers used to transfer data between processes in CM4 and CM7
	typedef struct 
	{
		uint8_t *bufptr;	//origin of buffer 
		uint8_t *dataptr;	//location of next free write location in write mode (currcount<=0); location of next available byte in read mode (currcount>0)
		int32_t currcount;	//current number of entries
		int32_t maxcount;	//maximum number of entries permitted = size of buffer allocation
	} bytebuf_t;
	*/
	
	uint8_t * bytebuf_init(bytebuf_t *bufctl, uint8_t *bufptr, size_t size) //initialize dataptr, currentcount, and maxcount of a bytebuf_t. 
	{
		bufctl->currcount = 0;	//done first. Will halt any consumer process from using the buffer.  NOTE 1
		bufctl->maxcount = size;
		bufctl->bufptr = bufptr;
		bufctl->dataptr = bufptr;
		return bufptr;	//NOTE 2
	}
	//	NOTE 1: Possible issue when consumer process has just read count but hasn't read data yet. Suggests that either we need need to make read process atomic, or prevent access to by bytebuf_init until currcount=0
	//	NOTE 2: return value is used in case buffer address is provided in function argument by something like malloc which might fail 


	int32_t bytebuf_wr(bytebuf_t *bufctl, uint8_t data ) //write data to buffer. Return number written (0/1)
	{
		if( (bufctl->maxcount + bufctl->currcount) > 0 ) { 	//do we have room in the buffer? NOTE 3
			bufctl->currcount -= 1;						//	yes; add the new value to it
			*bufctl->dataptr++ = data;					//	..
			return 1;									// return 1= number written if succeed
		}
		return 0; 										// return 0= number written if fail
	}
	//	NOTE 3: recall the currcount is maintained at negative values during write phase
	
	int32_t bytebuf_rd(bytebuf_t *bufctl, uint8_t *pdata ) //read data from buffer. Return number remaining to read
	{
		if( bufctl->currcount > 0 ) { 			//do we have data remaining in the buffer? NOTE 4		
			*pdata = *(bufctl->dataptr - bufctl->currcount);	//	supply the data
			bufctl->currcount -= 1;							//	  and decrease its count 
			return 1;										// return 1= number read if succeed (assumes read can't fail)
		}
		//here when currcount has been reduced to 0	  NOTE 5 
		return 0;											// return 0= number read if no more data
	}

	//	NOTE 4: recall the currcount is maintained at positive values during read phase
	//	NOTE 5: dataptr value is not restored. To reuse this buffer we must reinitialize it, or alternatively make it a ring buffer

	int32_t bytebuf_wrstop(bytebuf_t *bufctl) 	// stop the write phase for turnover to consumer process
	{
		bufctl->currcount = -bufctl->currcount;	// switch sign of count to flag transitioni
		return 0;								//flag success (TODO : future use of HSEM to create atomic operations might want to use this to flag failure)
	}

	int32_t bytebuf_rdstop(bytebuf_t *bufctl) 	// stop the read phase for turnover to producer process
	{
		bufctl->currcount = -bufctl->currcount;	// switch sign of count to flag transition  NOTE 6
		return 0;								//flag success (TODO : future use of HSEM to create atomic operations might want to use this to flag failure)
	}
	// NOTE 6: doing it this way puts the onus on the producer process to reinitialize the buffer. 
	// This implies the producer process maintains a state variable for the buffer to keep track of things and know when to reinitialize the buffer
	
	int32_t bytebuf_count( bytebuf_t *bufctl ) //report magnitude of current count. Values <=0 indicate write-phase, >0 indicate read-phase
	{
		return bufctl->currcount;				// sign indicates current phase ( read or write ). 
	}

	uint8_t * bytebuf_reset( bytebuf_t *bufctl ) //reinitialize control parameters
	{
		bufctl->currcount = 0;		//done first. Will halt any consumer process from using the buffer.  NOTE 1
//		bufctl->maxcount = size;	shouldn't be necessary
		bufctl->dataptr = bufctl->bufptr;
		return bufctl->bufptr;	//NOTE 2
	}
