HW7 Problem 1

TIM3_PWM function was written in device_greenLED.S
Whenever SystickHandler is called, the SysTick_msecs should increase by 1.
The value of TIM3_CNT should also increase by ~1000 as 1000usec = 1ms.
From my test, when SystickHandler is triggered, TIM3_CNT has increased by about
994, but I assume that is close enough to 1000.(To check add a breakpoint in
SystickHandler at bl DBGMCU_UNFREEZE_TIM3 (line 100))
I gave the prescaler a value of 63 because 64MHz / (63+1) = 1MHz. 
A 1MHz frequency has a period of 1/1Mhz = 1 usec.

I added "bl DBGMCU_FREEZE_TIM3", and "bl DBGMCU_UNFREEZE_TIM3" to the 
SystickHandler so that TIM3 stops in debug mode. 

In main----
/*50% duty cycle*/
TIM3_PWM(60000, 30000);
30000 usec = 30ms width
60000 usec = 60ms interval
