
	#include <stdint.h>				//for uint32_t and friends
	#include <stddef.h>				//for NULL
	
//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""
//extern uint32_t blueButton_count;	//HW06 Problem 1 variable defined in device_greenLED.S

void initGPIOxBITn();				//in device_greenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""

//Homework 7 Function declaration
void  TIM3_PWM( uint16_t  interval, uint16_t width); //interval, width are tie in usecs.

#define MAXHEXBUF 100				//length-limit  MoT commands

int main() 
{
	/*Initialize GPIO and Timer*/
	initGPIOxBITn();

	/*Configure Timer3 and enable it if not already*/
	/*50% duty cycle*/
	TIM3_PWM(60000, 30000);
	
	while(1){
	}


	return 0;	//eliminates a warning
}

