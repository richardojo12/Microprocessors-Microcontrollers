HW7 Problem 1
TIM3_PWM function was written in device_greenLED.S
Whenever SystickHandler is called, the SysTick_msecs should increase by 1.
The value of TIM3_CNT should also increase by ~1000 as 1000usec = 1ms.
From my test, when SystickHandler is triggered, TIM3_CNT has increased by about
994, but I assume that is close enough to 1000.
To achieve a microsecond resolution, I gave the prescaler a value of 63
because 64MHz / (63+1) = 1MHz. A 1MHz frequency has a period of 1/1Mhz = 1 usec.

I added "bl DBGMCU_FREEZE_TIM3", and "bl DBGMCU_UNFREEZE_TIM3" to the 
SystickHandler so that TIM3 stops in debug mode. 

HW7 Problem 2
void initGPIOxBITn(uint8_t direction);	
Initializes GPIO and TIM3. It also takes a direction parameter (0 to pulse from
bright to dim) (1 to pulse from dim to bright)

SystickHandler calls the function, greenLED_pulser_aux, which modifies CCR3.

disablePulser disables TIM3.

Uncomment in main to change periods.