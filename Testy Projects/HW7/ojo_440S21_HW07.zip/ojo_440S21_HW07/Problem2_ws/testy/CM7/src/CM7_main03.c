
	#include <stdint.h>				//for uint32_t and friends
	#include <stddef.h>				//for NULL
	
//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""
//extern uint32_t blueButton_count;	//HW06 Problem 1 variable defined in device_greenLED.S

void initGPIOxBITn(uint8_t direction);				//in device_greenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""

//Homework 7 Problem 1 Function declaration
void  TIM3_PWM( uint16_t  interval, uint16_t width); //interval, width are tie in usecs.
//Homework 7 Problem 2 Function declaration
void greenLED_pulser(uint32_t period); //period is msecs
//Homework 7 - function disabled current pulser/ tim3
void disablePulser();
int main() 
{
	/*Initialize GPIO and Timer*/
	/*Configure Timer3 and enable it if not already*/

	/* 0 for bright to dim pulse*/
	initGPIOxBITn(0);

	greenLED_pulser(1000);// 1s = 1000ms

	disablePulser();

	/* 1 for dim to bright pulse*/
	initGPIOxBITn(1);

	greenLED_pulser(1000);// 1s = 1000ms
	//disablePulser();

	//greenLED_pulser(10000);//10s = 10000ms
	//disablePulser();

	//greenLED_pulser(100000);//100s = 100000ms
	//disablePulser();

	while(1){
	}


	return 0;	//eliminates a warning
}

