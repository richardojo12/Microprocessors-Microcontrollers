//STM32H745_ADC.h version2 wmh 2020-11-27 : adds bit definitions from stm32H745xx.h to see if that makes things easier
// '(0U)' problem: gcc preprocessor has a problem with '(0U)' values appearing in #defines -- must be replaced everywhere with '(0)' 
//STM32H745_ADC.h wmh 2020-11-26 : register offset definitions excerpted from stm32H745xx.h for use in ADC assembler functions
// Include this file in assembly language files which refer to the stm32H745's ADC registers.
// some editing may be required to do this in general -- see SKIP and SKIPNUM edits of the original (below) 
// note: all ADC register names have prepended 'adc' identifier to prevent name collision 
//where multiple peripherals are being accessed. 
// bonus: __IO macro design can be used #multiple times in a single .h file to convert
//multiple peripherals' structs (see 'adc' and 'adc_cmn' below).
//This allows you to make a single 'jungle' .h file which includes registers definitions 
//for all peripherals used in a project.  
//
// (!!wmhTODO: add uint16_t, uint8_t or any other variations as are found to be necessary of other peripherals) 

	.syntax unified				@; ARM Unified Assembler Language (UAL). 
	.thumb						@; Use thumb instructions only

	#define uint32_t 4
	#undef type
	#define type ADC_			//prepended to offset name
	#include "__IO_struct_translator.h"
	.set offset,0				//starting value of offset

// --- below are snips of structs from stm32h745xx.h to be processed into register offsets for use in assembly code
//typedef struct	
//{
  __IO uint32_t ISR;              /*!< ADC Interrupt and Status Register,                 Address offset: 0x00 */
  __IO uint32_t IER;              /*!< ADC Interrupt Enable Register,                     Address offset: 0x04 */
  __IO uint32_t CR;               /*!< ADC control register,                              Address offset: 0x08 */
  __IO uint32_t CFGR;             /*!< ADC Configuration register,                        Address offset: 0x0C */
  __IO uint32_t CFGR2;            /*!< ADC Configuration register 2,                      Address offset: 0x10 */
  __IO uint32_t SMPR1;            /*!< ADC sample time register 1,                        Address offset: 0x14 */
  __IO uint32_t SMPR2;            /*!< ADC sample time register 2,                        Address offset: 0x18 */
  __IO uint32_t PCSEL;            /*!< ADC pre-channel selection,                         Address offset: 0x1C */
  __IO uint32_t LTR1;             /*!< ADC watchdog Lower threshold register 1,           Address offset: 0x20 */
  __IO uint32_t HTR1;             /*!< ADC watchdog higher threshold register 1,          Address offset: 0x24 */
  // original of the line below: "uint32_t      RESERVED1;        /*!< Reserved, 0x028" 
  SKIP	uint32_t      RESERVED1;        /*!< Reserved, 0x028                                                         */
  SKIP	uint32_t      RESERVED2;        /*!< Reserved, 0x02C                                                         */
  __IO uint32_t SQR1;             /*!< ADC regular sequence register 1,                   Address offset: 0x30 */
  __IO uint32_t SQR2;             /*!< ADC regular sequence register 2,                   Address offset: 0x34 */
  __IO uint32_t SQR3;             /*!< ADC regular sequence register 3,                   Address offset: 0x38 */
  __IO uint32_t SQR4;             /*!< ADC regular sequence register 4,                   Address offset: 0x3C */
  __IO uint32_t DR;               /*!< ADC regular data register,                         Address offset: 0x40 */
  SKIP	uint32_t      RESERVED3;        /*!< Reserved, 0x044                                                         */
  SKIP	uint32_t      RESERVED4;        /*!< Reserved, 0x048                                                         */
  __IO uint32_t JSQR;             /*!< ADC injected sequence register,                    Address offset: 0x4C */
  // original of the line below: "uint32_t      RESERVED5[4];     /*!< Reserved, 0x050 - 0x05C" 
  SKIPNUM uint32_t      RESERVED5 4;     /*!< Reserved, 0x050 - 0x05C                                                 */
  __IO uint32_t OFR1;             /*!< ADC offset register 1,                             Address offset: 0x60 */
  __IO uint32_t OFR2;             /*!< ADC offset register 2,                             Address offset: 0x64 */
  __IO uint32_t OFR3;             /*!< ADC offset register 3,                             Address offset: 0x68 */
  __IO uint32_t OFR4;             /*!< ADC offset register 4,                             Address offset: 0x6C */
  SKIPNUM uint32_t      RESERVED6 4;     /*!< Reserved, 0x070 - 0x07C                                                 */
  __IO uint32_t JDR1;             /*!< ADC injected data register 1,                      Address offset: 0x80 */
  __IO uint32_t JDR2;             /*!< ADC injected data register 2,                      Address offset: 0x84 */
  __IO uint32_t JDR3;             /*!< ADC injected data register 3,                      Address offset: 0x88 */
  __IO uint32_t JDR4;             /*!< ADC injected data register 4,                      Address offset: 0x8C */
  SKIPNUM uint32_t      RESERVED7 4;     /*!< Reserved, 0x090 - 0x09C                                                 */
  __IO uint32_t AWD2CR;           /*!< ADC  Analog Watchdog 2 Configuration Register,     Address offset: 0xA0 */
  __IO uint32_t AWD3CR;           /*!< ADC  Analog Watchdog 3 Configuration Register,     Address offset: 0xA4 */
  SKIP	 uint32_t      RESERVED8;        /*!< Reserved, 0x0A8                                                         */
  SKIP	 uint32_t      RESERVED9;        /*!< Reserved, 0x0AC                                                         */
  __IO uint32_t LTR2;             /*!< ADC watchdog Lower threshold register 2,           Address offset: 0xB0 */
  __IO uint32_t HTR2;             /*!< ADC watchdog Higher threshold register 2,          Address offset: 0xB4 */
  __IO uint32_t LTR3;             /*!< ADC watchdog Lower threshold register 3,           Address offset: 0xB8 */
  __IO uint32_t HTR3;             /*!< ADC watchdog Higher threshold register 3,          Address offset: 0xBC */
  __IO uint32_t DIFSEL;           /*!< ADC  Differential Mode Selection Register,         Address offset: 0xC0 */
  __IO uint32_t CALFACT;          /*!< ADC  Calibration Factors,                          Address offset: 0xC4 */
  __IO uint32_t CALFACT2;         /*!< ADC  Linearity Calibration Factors,                Address offset: 0xC8 */
//} ADC_TypeDef;
//	#include "struct_undefs.h"	now included in struct_defs.h
	#undef type
	#define type ADC_COMMON_
	#include "__IO_struct_translator.h"
	.set offset,0
//typedef struct 
//{
 __IO uint32_t CSR; /*!< ADC Common status register, Address offset: ADC1/3 base address + 0x300 */
  SKIP	uint32_t RESERVED; /*!< Reserved, ADC1/3 base address + 0x304 */
 __IO uint32_t CCR; /*!< ADC common control register, Address offset: ADC1/3 base address + 0x308 */
 __IO uint32_t CDR; /*!< ADC common regular data register for dual Address offset: ADC1/3 base address + 0x30C */
 __IO uint32_t CDR2; /*!< ADC common regular data register for 32-bit dual mode Address offset: ADC1/3 base address + 0x310 */
//} ADC_Common_TypeDef;

//--- below is the entire section of ADC and ADC_COMMON bit definitions from stm32H745xx.h 
/******************************************************************************/
/*                                                                            */
/*                        Analog to Digital Converter                         */
/*                                                                            */
/******************************************************************************/
/*******************************  ADC VERSION  ********************************/
#define ADC_VER_V5_X
/********************  Bit definition for ADC_ISR register  ********************/
#define ADC_ISR_ADRDY_Pos                 (0)
#define ADC_ISR_ADRDY_Msk                 (0x1UL << ADC_ISR_ADRDY_Pos)         /*!< 0x00000001 */
#define ADC_ISR_ADRDY                     ADC_ISR_ADRDY_Msk                    /*!< ADC Ready (ADRDY) flag  */
#define ADC_ISR_EOSMP_Pos                 (1U)
#define ADC_ISR_EOSMP_Msk                 (0x1UL << ADC_ISR_EOSMP_Pos)         /*!< 0x00000002 */
#define ADC_ISR_EOSMP                     ADC_ISR_EOSMP_Msk                    /*!< ADC End of Sampling flag */
#define ADC_ISR_EOC_Pos                   (2U)
#define ADC_ISR_EOC_Msk                   (0x1UL << ADC_ISR_EOC_Pos)           /*!< 0x00000004 */
#define ADC_ISR_EOC                       ADC_ISR_EOC_Msk                      /*!< ADC End of Regular Conversion flag */
#define ADC_ISR_EOS_Pos                   (3U)
#define ADC_ISR_EOS_Msk                   (0x1UL << ADC_ISR_EOS_Pos)           /*!< 0x00000008 */
#define ADC_ISR_EOS                       ADC_ISR_EOS_Msk                      /*!< ADC End of Regular sequence of Conversions flag */
#define ADC_ISR_OVR_Pos                   (4U)
#define ADC_ISR_OVR_Msk                   (0x1UL << ADC_ISR_OVR_Pos)           /*!< 0x00000010 */
#define ADC_ISR_OVR                       ADC_ISR_OVR_Msk                      /*!< ADC overrun flag */
#define ADC_ISR_JEOC_Pos                  (5U)
#define ADC_ISR_JEOC_Msk                  (0x1UL << ADC_ISR_JEOC_Pos)          /*!< 0x00000020 */
#define ADC_ISR_JEOC                      ADC_ISR_JEOC_Msk                     /*!< ADC End of Injected Conversion flag */
#define ADC_ISR_JEOS_Pos                  (6U)
#define ADC_ISR_JEOS_Msk                  (0x1UL << ADC_ISR_JEOS_Pos)          /*!< 0x00000040 */
#define ADC_ISR_JEOS                      ADC_ISR_JEOS_Msk                     /*!< ADC End of Injected sequence of Conversions flag */
#define ADC_ISR_AWD1_Pos                  (7U)
#define ADC_ISR_AWD1_Msk                  (0x1UL << ADC_ISR_AWD1_Pos)          /*!< 0x00000080 */
#define ADC_ISR_AWD1                      ADC_ISR_AWD1_Msk                     /*!< ADC Analog watchdog 1 flag */
#define ADC_ISR_AWD2_Pos                  (8U)
#define ADC_ISR_AWD2_Msk                  (0x1UL << ADC_ISR_AWD2_Pos)          /*!< 0x00000100 */
#define ADC_ISR_AWD2                      ADC_ISR_AWD2_Msk                     /*!< ADC Analog watchdog 2 flag */
#define ADC_ISR_AWD3_Pos                  (9U)
#define ADC_ISR_AWD3_Msk                  (0x1UL << ADC_ISR_AWD3_Pos)          /*!< 0x00000200 */
#define ADC_ISR_AWD3                      ADC_ISR_AWD3_Msk                     /*!< ADC Analog watchdog 3 flag */
#define ADC_ISR_JQOVF_Pos                 (10U)
#define ADC_ISR_JQOVF_Msk                 (0x1UL << ADC_ISR_JQOVF_Pos)         /*!< 0x00000400 */
#define ADC_ISR_JQOVF                     ADC_ISR_JQOVF_Msk                    /*!< ADC Injected Context Queue Overflow flag */

/********************  Bit definition for ADC_IER register  ********************/
#define ADC_IER_ADRDYIE_Pos               (0)
#define ADC_IER_ADRDYIE_Msk               (0x1UL << ADC_IER_ADRDYIE_Pos)       /*!< 0x00000001 */
#define ADC_IER_ADRDYIE                   ADC_IER_ADRDYIE_Msk                  /*!< ADC Ready (ADRDY) interrupt source */
#define ADC_IER_EOSMPIE_Pos               (1U)
#define ADC_IER_EOSMPIE_Msk               (0x1UL << ADC_IER_EOSMPIE_Pos)       /*!< 0x00000002 */
#define ADC_IER_EOSMPIE                   ADC_IER_EOSMPIE_Msk                  /*!< ADC End of Sampling interrupt source */
#define ADC_IER_EOCIE_Pos                 (2U)
#define ADC_IER_EOCIE_Msk                 (0x1UL << ADC_IER_EOCIE_Pos)         /*!< 0x00000004 */
#define ADC_IER_EOCIE                     ADC_IER_EOCIE_Msk                    /*!< ADC End of Regular Conversion interrupt source */
#define ADC_IER_EOSIE_Pos                 (3U)
#define ADC_IER_EOSIE_Msk                 (0x1UL << ADC_IER_EOSIE_Pos)         /*!< 0x00000008 */
#define ADC_IER_EOSIE                     ADC_IER_EOSIE_Msk                    /*!< ADC End of Regular sequence of Conversions interrupt source */
#define ADC_IER_OVRIE_Pos                 (4U)
#define ADC_IER_OVRIE_Msk                 (0x1UL << ADC_IER_OVRIE_Pos)         /*!< 0x00000010 */
#define ADC_IER_OVRIE                     ADC_IER_OVRIE_Msk                    /*!< ADC overrun interrupt source */
#define ADC_IER_JEOCIE_Pos                (5U)
#define ADC_IER_JEOCIE_Msk                (0x1UL << ADC_IER_JEOCIE_Pos)        /*!< 0x00000020 */
#define ADC_IER_JEOCIE                    ADC_IER_JEOCIE_Msk                   /*!< ADC End of Injected Conversion interrupt source */
#define ADC_IER_JEOSIE_Pos                (6U)
#define ADC_IER_JEOSIE_Msk                (0x1UL << ADC_IER_JEOSIE_Pos)        /*!< 0x00000040 */
#define ADC_IER_JEOSIE                    ADC_IER_JEOSIE_Msk                   /*!< ADC End of Injected sequence of Conversions interrupt source */
#define ADC_IER_AWD1IE_Pos                (7U)
#define ADC_IER_AWD1IE_Msk                (0x1UL << ADC_IER_AWD1IE_Pos)        /*!< 0x00000080 */
#define ADC_IER_AWD1IE                    ADC_IER_AWD1IE_Msk                   /*!< ADC Analog watchdog 1 interrupt source */
#define ADC_IER_AWD2IE_Pos                (8U)
#define ADC_IER_AWD2IE_Msk                (0x1UL << ADC_IER_AWD2IE_Pos)        /*!< 0x00000100 */
#define ADC_IER_AWD2IE                    ADC_IER_AWD2IE_Msk                   /*!< ADC Analog watchdog 2 interrupt source */
#define ADC_IER_AWD3IE_Pos                (9U)
#define ADC_IER_AWD3IE_Msk                (0x1UL << ADC_IER_AWD3IE_Pos)        /*!< 0x00000200 */
#define ADC_IER_AWD3IE                    ADC_IER_AWD3IE_Msk                   /*!< ADC Analog watchdog 3 interrupt source */
#define ADC_IER_JQOVFIE_Pos               (10U)
#define ADC_IER_JQOVFIE_Msk               (0x1UL << ADC_IER_JQOVFIE_Pos)       /*!< 0x00000400 */
#define ADC_IER_JQOVFIE                   ADC_IER_JQOVFIE_Msk                  /*!< ADC Injected Context Queue Overflow interrupt source */

/********************  Bit definition for ADC_CR register  ********************/
#define ADC_CR_ADEN_Pos                   (0)		//!!wmh PUZZLE -- this particular value could not be read as (0) -- we kept gettin g"Error: found 'U', expected: ')'"
#define ADC_CR_ADEN_Msk                   (0x1UL << ADC_CR_ADEN_Pos)           /*!< 0x00000001 */
#define ADC_CR_ADEN                       ADC_CR_ADEN_Msk                      /*!< ADC Enable control */
#define ADC_CR_ADDIS_Pos                  (1U)
#define ADC_CR_ADDIS_Msk                  (0x1UL << ADC_CR_ADDIS_Pos)          /*!< 0x00000002 */
#define ADC_CR_ADDIS                      ADC_CR_ADDIS_Msk                     /*!< ADC Disable command */
#define ADC_CR_ADSTART_Pos                (2U)
#define ADC_CR_ADSTART_Msk                (0x1UL << ADC_CR_ADSTART_Pos)        /*!< 0x00000004 */
#define ADC_CR_ADSTART                    ADC_CR_ADSTART_Msk                   /*!< ADC Start of Regular conversion */
#define ADC_CR_JADSTART_Pos               (3U)
#define ADC_CR_JADSTART_Msk               (0x1UL << ADC_CR_JADSTART_Pos)       /*!< 0x00000008 */
#define ADC_CR_JADSTART                   ADC_CR_JADSTART_Msk                  /*!< ADC Start of injected conversion */
#define ADC_CR_ADSTP_Pos                  (4U)
#define ADC_CR_ADSTP_Msk                  (0x1UL << ADC_CR_ADSTP_Pos)          /*!< 0x00000010 */
#define ADC_CR_ADSTP                      ADC_CR_ADSTP_Msk                     /*!< ADC Stop of Regular conversion */
#define ADC_CR_JADSTP_Pos                 (5U)
#define ADC_CR_JADSTP_Msk                 (0x1UL << ADC_CR_JADSTP_Pos)         /*!< 0x00000020 */
#define ADC_CR_JADSTP                     ADC_CR_JADSTP_Msk                    /*!< ADC Stop of injected conversion */
#define ADC_CR_BOOST_Pos                  (8U)
#define ADC_CR_BOOST_Msk                  (0x3UL << ADC_CR_BOOST_Pos)          /*!< 0x00000300 */
#define ADC_CR_BOOST                      ADC_CR_BOOST_Msk                     /*!< ADC Boost Mode configuration */
#define ADC_CR_BOOST_0                    (0x1UL << ADC_CR_BOOST_Pos)           /*!< 0x00000100 */
#define ADC_CR_BOOST_1                    (0x2UL << ADC_CR_BOOST_Pos)           /*!< 0x00000200 */
#define ADC_CR_ADCALLIN_Pos               (16U)
#define ADC_CR_ADCALLIN_Msk               (0x1UL << ADC_CR_ADCALLIN_Pos)       /*!< 0x00010000 */
#define ADC_CR_ADCALLIN                   ADC_CR_ADCALLIN_Msk                  /*!< ADC Linearity calibration */
#define ADC_CR_LINCALRDYW1_Pos            (22U)
#define ADC_CR_LINCALRDYW1_Msk            (0x1UL << ADC_CR_LINCALRDYW1_Pos)    /*!< 0x00400000 */
#define ADC_CR_LINCALRDYW1                ADC_CR_LINCALRDYW1_Msk               /*!< ADC Linearity calibration ready Word 1 */
#define ADC_CR_LINCALRDYW2_Pos            (23U)
#define ADC_CR_LINCALRDYW2_Msk            (0x1UL << ADC_CR_LINCALRDYW2_Pos)    /*!< 0x00800000 */
#define ADC_CR_LINCALRDYW2                ADC_CR_LINCALRDYW2_Msk               /*!< ADC Linearity calibration ready Word 2 */
#define ADC_CR_LINCALRDYW3_Pos            (24U)
#define ADC_CR_LINCALRDYW3_Msk            (0x1UL << ADC_CR_LINCALRDYW3_Pos)    /*!< 0x01000000 */
#define ADC_CR_LINCALRDYW3                ADC_CR_LINCALRDYW3_Msk               /*!< ADC Linearity calibration ready Word 3 */
#define ADC_CR_LINCALRDYW4_Pos            (25U)
#define ADC_CR_LINCALRDYW4_Msk            (0x1UL << ADC_CR_LINCALRDYW4_Pos)    /*!< 0x02000000 */
#define ADC_CR_LINCALRDYW4                ADC_CR_LINCALRDYW4_Msk               /*!< ADC Linearity calibration ready Word 4 */
#define ADC_CR_LINCALRDYW5_Pos            (26U)
#define ADC_CR_LINCALRDYW5_Msk            (0x1UL << ADC_CR_LINCALRDYW5_Pos)    /*!< 0x04000000 */
#define ADC_CR_LINCALRDYW5                ADC_CR_LINCALRDYW5_Msk               /*!< ADC Linearity calibration ready Word 5 */
#define ADC_CR_LINCALRDYW6_Pos            (27U)
#define ADC_CR_LINCALRDYW6_Msk            (0x1UL << ADC_CR_LINCALRDYW6_Pos)    /*!< 0x08000000 */
#define ADC_CR_LINCALRDYW6                ADC_CR_LINCALRDYW6_Msk               /*!< ADC Linearity calibration ready Word 6 */
#define ADC_CR_ADVREGEN_Pos               (28U)
#define ADC_CR_ADVREGEN_Msk               (0x1UL << ADC_CR_ADVREGEN_Pos)       /*!< 0x10000000 */
#define ADC_CR_ADVREGEN                   ADC_CR_ADVREGEN_Msk                  /*!< ADC Voltage regulator Enable */
#define ADC_CR_DEEPPWD_Pos                (29U)
#define ADC_CR_DEEPPWD_Msk                (0x1UL << ADC_CR_DEEPPWD_Pos)        /*!< 0x20000000 */
#define ADC_CR_DEEPPWD                    ADC_CR_DEEPPWD_Msk                   /*!< ADC Deep power down Enable */
#define ADC_CR_ADCALDIF_Pos               (30U)
#define ADC_CR_ADCALDIF_Msk               (0x1UL << ADC_CR_ADCALDIF_Pos)       /*!< 0x40000000 */
#define ADC_CR_ADCALDIF                   ADC_CR_ADCALDIF_Msk                  /*!< ADC Differential Mode for calibration */
#define ADC_CR_ADCAL_Pos                  (31U)
#define ADC_CR_ADCAL_Msk                  (0x1UL << ADC_CR_ADCAL_Pos)          /*!< 0x80000000 */
#define ADC_CR_ADCAL                      ADC_CR_ADCAL_Msk                     /*!< ADC Calibration */

/********************  Bit definition for ADC_CFGR register  ********************/
#define ADC_CFGR_DMNGT_Pos                (0)
#define ADC_CFGR_DMNGT_Msk                (0x3UL << ADC_CFGR_DMNGT_Pos)        /*!< 0x00000003 */
#define ADC_CFGR_DMNGT                    ADC_CFGR_DMNGT_Msk                   /*!< ADC Data Management configuration */
#define ADC_CFGR_DMNGT_0                  (0x1UL << ADC_CFGR_DMNGT_Pos)         /*!< 0x00000001 */
#define ADC_CFGR_DMNGT_1                  (0x2UL << ADC_CFGR_DMNGT_Pos)         /*!< 0x00000002 */

#define ADC_CFGR_RES_Pos                  (2U)
#define ADC_CFGR_RES_Msk                  (0x7UL << ADC_CFGR_RES_Pos)          /*!< 0x0000001C */
#define ADC_CFGR_RES                      ADC_CFGR_RES_Msk                     /*!< ADC Data resolution */
#define ADC_CFGR_RES_0                    (0x1UL << ADC_CFGR_RES_Pos)           /*!< 0x00000004 */
#define ADC_CFGR_RES_1                    (0x2UL << ADC_CFGR_RES_Pos)           /*!< 0x00000008 */
#define ADC_CFGR_RES_2                    (0x4UL << ADC_CFGR_RES_Pos)           /*!< 0x00000010 */

#define ADC_CFGR_EXTSEL_Pos               (5U)
#define ADC_CFGR_EXTSEL_Msk               (0x1FUL << ADC_CFGR_EXTSEL_Pos)      /*!< 0x000003E0 */
#define ADC_CFGR_EXTSEL                   ADC_CFGR_EXTSEL_Msk                  /*!< ADC External trigger selection for regular group */
#define ADC_CFGR_EXTSEL_0                 (0x01UL << ADC_CFGR_EXTSEL_Pos)       /*!< 0x00000020 */
#define ADC_CFGR_EXTSEL_1                 (0x02UL << ADC_CFGR_EXTSEL_Pos)       /*!< 0x00000040 */
#define ADC_CFGR_EXTSEL_2                 (0x04UL << ADC_CFGR_EXTSEL_Pos)       /*!< 0x00000080 */
#define ADC_CFGR_EXTSEL_3                 (0x08UL << ADC_CFGR_EXTSEL_Pos)       /*!< 0x00000100 */
#define ADC_CFGR_EXTSEL_4                 (0x10UL << ADC_CFGR_EXTSEL_Pos)       /*!< 0x00000200 */

#define ADC_CFGR_EXTEN_Pos                (10U)
#define ADC_CFGR_EXTEN_Msk                (0x3UL << ADC_CFGR_EXTEN_Pos)        /*!< 0x00000C00 */
#define ADC_CFGR_EXTEN                    ADC_CFGR_EXTEN_Msk                   /*!< ADC External trigger enable and polarity selection for regular channels */
#define ADC_CFGR_EXTEN_0                  (0x1UL << ADC_CFGR_EXTEN_Pos)         /*!< 0x00000400 */
#define ADC_CFGR_EXTEN_1                  (0x2UL << ADC_CFGR_EXTEN_Pos)         /*!< 0x00000800 */

#define ADC_CFGR_OVRMOD_Pos               (12U)
#define ADC_CFGR_OVRMOD_Msk               (0x1UL << ADC_CFGR_OVRMOD_Pos)       /*!< 0x00001000 */
#define ADC_CFGR_OVRMOD                   ADC_CFGR_OVRMOD_Msk                  /*!< ADC overrun mode */
#define ADC_CFGR_CONT_Pos                 (13U)
#define ADC_CFGR_CONT_Msk                 (0x1UL << ADC_CFGR_CONT_Pos)         /*!< 0x00002000 */
#define ADC_CFGR_CONT                     ADC_CFGR_CONT_Msk                    /*!< ADC Single/continuous conversion mode for regular conversion */
#define ADC_CFGR_AUTDLY_Pos               (14U)
#define ADC_CFGR_AUTDLY_Msk               (0x1UL << ADC_CFGR_AUTDLY_Pos)       /*!< 0x00004000 */
#define ADC_CFGR_AUTDLY                   ADC_CFGR_AUTDLY_Msk                  /*!< ADC Delayed conversion mode */

#define ADC_CFGR_DISCEN_Pos               (16U)
#define ADC_CFGR_DISCEN_Msk               (0x1UL << ADC_CFGR_DISCEN_Pos)       /*!< 0x00010000 */
#define ADC_CFGR_DISCEN                   ADC_CFGR_DISCEN_Msk                  /*!< ADC Discontinuous mode for regular channels */

#define ADC_CFGR_DISCNUM_Pos              (17U)
#define ADC_CFGR_DISCNUM_Msk              (0x7UL << ADC_CFGR_DISCNUM_Pos)      /*!< 0x000E0000 */
#define ADC_CFGR_DISCNUM                  ADC_CFGR_DISCNUM_Msk                 /*!< ADC Discontinuous mode channel count */
#define ADC_CFGR_DISCNUM_0                (0x1UL << ADC_CFGR_DISCNUM_Pos)       /*!< 0x00020000 */
#define ADC_CFGR_DISCNUM_1                (0x2UL << ADC_CFGR_DISCNUM_Pos)       /*!< 0x00040000 */
#define ADC_CFGR_DISCNUM_2                (0x4UL << ADC_CFGR_DISCNUM_Pos)       /*!< 0x00080000 */

#define ADC_CFGR_JDISCEN_Pos              (20U)
#define ADC_CFGR_JDISCEN_Msk              (0x1UL << ADC_CFGR_JDISCEN_Pos)      /*!< 0x00100000 */
#define ADC_CFGR_JDISCEN                  ADC_CFGR_JDISCEN_Msk                 /*!< ADC Discontinuous mode on injected channels */
#define ADC_CFGR_JQM_Pos                  (21U)
#define ADC_CFGR_JQM_Msk                  (0x1UL << ADC_CFGR_JQM_Pos)          /*!< 0x00200000 */
#define ADC_CFGR_JQM                      ADC_CFGR_JQM_Msk                     /*!< ADC JSQR Queue mode */
#define ADC_CFGR_AWD1SGL_Pos              (22U)
#define ADC_CFGR_AWD1SGL_Msk              (0x1UL << ADC_CFGR_AWD1SGL_Pos)      /*!< 0x00400000 */
#define ADC_CFGR_AWD1SGL                  ADC_CFGR_AWD1SGL_Msk                 /*!< Enable the watchdog 1 on a single channel or on all channels */
#define ADC_CFGR_AWD1EN_Pos               (23U)
#define ADC_CFGR_AWD1EN_Msk               (0x1UL << ADC_CFGR_AWD1EN_Pos)       /*!< 0x00800000 */
#define ADC_CFGR_AWD1EN                   ADC_CFGR_AWD1EN_Msk                  /*!< ADC Analog watchdog 1 enable on regular Channels */
#define ADC_CFGR_JAWD1EN_Pos              (24U)
#define ADC_CFGR_JAWD1EN_Msk              (0x1UL << ADC_CFGR_JAWD1EN_Pos)      /*!< 0x01000000 */
#define ADC_CFGR_JAWD1EN                  ADC_CFGR_JAWD1EN_Msk                 /*!< ADC Analog watchdog 1 enable on injected Channels */
#define ADC_CFGR_JAUTO_Pos                (25U)
#define ADC_CFGR_JAUTO_Msk                (0x1UL << ADC_CFGR_JAUTO_Pos)        /*!< 0x02000000 */
#define ADC_CFGR_JAUTO                    ADC_CFGR_JAUTO_Msk                   /*!< ADC Automatic injected group conversion */

#define ADC_CFGR_AWD1CH_Pos               (26U)
#define ADC_CFGR_AWD1CH_Msk               (0x1FUL << ADC_CFGR_AWD1CH_Pos)      /*!< 0x7C000000 */
#define ADC_CFGR_AWD1CH                   ADC_CFGR_AWD1CH_Msk                  /*!< ADC Analog watchdog 1 Channel selection */
#define ADC_CFGR_AWD1CH_0                 (0x01UL << ADC_CFGR_AWD1CH_Pos)       /*!< 0x04000000 */
#define ADC_CFGR_AWD1CH_1                 (0x02UL << ADC_CFGR_AWD1CH_Pos)       /*!< 0x08000000 */
#define ADC_CFGR_AWD1CH_2                 (0x04UL << ADC_CFGR_AWD1CH_Pos)       /*!< 0x10000000 */
#define ADC_CFGR_AWD1CH_3                 (0x08UL << ADC_CFGR_AWD1CH_Pos)       /*!< 0x20000000 */
#define ADC_CFGR_AWD1CH_4                 (0x10UL << ADC_CFGR_AWD1CH_Pos)       /*!< 0x40000000 */

#define ADC_CFGR_JQDIS_Pos                (31U)
#define ADC_CFGR_JQDIS_Msk                (0x1UL << ADC_CFGR_JQDIS_Pos)        /*!< 0x80000000 */
#define ADC_CFGR_JQDIS                    ADC_CFGR_JQDIS_Msk                   /*!< ADC Injected queue disable */

/********************  Bit definition for ADC_CFGR2 register  ********************/
#define ADC_CFGR2_ROVSE_Pos               (0)
#define ADC_CFGR2_ROVSE_Msk               (0x1UL << ADC_CFGR2_ROVSE_Pos)       /*!< 0x00000001 */
#define ADC_CFGR2_ROVSE                   ADC_CFGR2_ROVSE_Msk                  /*!< ADC Regular group oversampler enable */
#define ADC_CFGR2_JOVSE_Pos               (1U)
#define ADC_CFGR2_JOVSE_Msk               (0x1UL << ADC_CFGR2_JOVSE_Pos)       /*!< 0x00000002 */
#define ADC_CFGR2_JOVSE                   ADC_CFGR2_JOVSE_Msk                  /*!< ADC Injected group oversampler enable */

#define ADC_CFGR2_OVSS_Pos                (5U)
#define ADC_CFGR2_OVSS_Msk                (0xFUL << ADC_CFGR2_OVSS_Pos)        /*!< 0x000001E0 */
#define ADC_CFGR2_OVSS                    ADC_CFGR2_OVSS_Msk                   /*!< ADC Regular Oversampling shift */
#define ADC_CFGR2_OVSS_0                  (0x1UL << ADC_CFGR2_OVSS_Pos)         /*!< 0x00000020 */
#define ADC_CFGR2_OVSS_1                  (0x2UL << ADC_CFGR2_OVSS_Pos)         /*!< 0x00000040 */
#define ADC_CFGR2_OVSS_2                  (0x4UL << ADC_CFGR2_OVSS_Pos)         /*!< 0x00000080 */
#define ADC_CFGR2_OVSS_3                  (0x8UL << ADC_CFGR2_OVSS_Pos)         /*!< 0x00000100 */

#define ADC_CFGR2_TROVS_Pos               (9U)
#define ADC_CFGR2_TROVS_Msk               (0x1UL << ADC_CFGR2_TROVS_Pos)       /*!< 0x00000200 */
#define ADC_CFGR2_TROVS                   ADC_CFGR2_TROVS_Msk                  /*!< ADC Triggered regular Oversampling */
#define ADC_CFGR2_ROVSM_Pos               (10U)
#define ADC_CFGR2_ROVSM_Msk               (0x1UL << ADC_CFGR2_ROVSM_Pos)       /*!< 0x00000400 */
#define ADC_CFGR2_ROVSM                   ADC_CFGR2_ROVSM_Msk                  /*!< ADC Regular oversampling mode */

#define ADC_CFGR2_RSHIFT1_Pos             (11U)
#define ADC_CFGR2_RSHIFT1_Msk             (0x1UL << ADC_CFGR2_RSHIFT1_Pos)     /*!< 0x00000800 */
#define ADC_CFGR2_RSHIFT1                 ADC_CFGR2_RSHIFT1_Msk                /*!< ADC Right-shift data after Offset 1 correction */
#define ADC_CFGR2_RSHIFT2_Pos             (12U)
#define ADC_CFGR2_RSHIFT2_Msk             (0x1UL << ADC_CFGR2_RSHIFT2_Pos)     /*!< 0x00001000 */
#define ADC_CFGR2_RSHIFT2                 ADC_CFGR2_RSHIFT2_Msk                /*!< ADC Right-shift data after Offset 2 correction */
#define ADC_CFGR2_RSHIFT3_Pos             (13U)
#define ADC_CFGR2_RSHIFT3_Msk             (0x1UL << ADC_CFGR2_RSHIFT3_Pos)     /*!< 0x00002000 */
#define ADC_CFGR2_RSHIFT3                 ADC_CFGR2_RSHIFT3_Msk                /*!< ADC Right-shift data after Offset 3 correction */
#define ADC_CFGR2_RSHIFT4_Pos             (14U)
#define ADC_CFGR2_RSHIFT4_Msk             (0x1UL << ADC_CFGR2_RSHIFT4_Pos)     /*!< 0x00004000 */
#define ADC_CFGR2_RSHIFT4                 ADC_CFGR2_RSHIFT4_Msk                /*!< ADC Right-shift data after Offset 4 correction */

#define ADC_CFGR2_OVSR_Pos                (16U)
#define ADC_CFGR2_OVSR_Msk                (0x3FFUL << ADC_CFGR2_OVSR_Pos)      /*!< 0x03FF0000 */
#define ADC_CFGR2_OVSR                    ADC_CFGR2_OVSR_Msk                   /*!< ADC oversampling Ratio */
#define ADC_CFGR2_OVSR_0                  (0x001UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x00010000 */
#define ADC_CFGR2_OVSR_1                  (0x002UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x00020000 */
#define ADC_CFGR2_OVSR_2                  (0x004UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x00040000 */
#define ADC_CFGR2_OVSR_3                  (0x008UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x00080000 */
#define ADC_CFGR2_OVSR_4                  (0x010UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x00100000 */
#define ADC_CFGR2_OVSR_5                  (0x020UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x00200000 */
#define ADC_CFGR2_OVSR_6                  (0x040UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x00400000 */
#define ADC_CFGR2_OVSR_7                  (0x080UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x00800000 */
#define ADC_CFGR2_OVSR_8                  (0x100UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x01000000 */
#define ADC_CFGR2_OVSR_9                  (0x200UL << ADC_CFGR2_OVSR_Pos)       /*!< 0x02000000 */

#define ADC_CFGR2_LSHIFT_Pos              (28U)
#define ADC_CFGR2_LSHIFT_Msk              (0xFUL << ADC_CFGR2_LSHIFT_Pos)      /*!< 0xF0000000 */
#define ADC_CFGR2_LSHIFT                  ADC_CFGR2_LSHIFT_Msk                 /*!< ADC Left shift factor */
#define ADC_CFGR2_LSHIFT_0                (0x1UL << ADC_CFGR2_LSHIFT_Pos)       /*!< 0x10000000 */
#define ADC_CFGR2_LSHIFT_1                (0x2UL << ADC_CFGR2_LSHIFT_Pos)       /*!< 0x20000000 */
#define ADC_CFGR2_LSHIFT_2                (0x4UL << ADC_CFGR2_LSHIFT_Pos)       /*!< 0x40000000 */
#define ADC_CFGR2_LSHIFT_3                (0x8UL << ADC_CFGR2_LSHIFT_Pos)       /*!< 0x80000000 */

/********************  Bit definition for ADC_SMPR1 register  ********************/
#define ADC_SMPR1_SMP0_Pos                (0)
#define ADC_SMPR1_SMP0_Msk                (0x7UL << ADC_SMPR1_SMP0_Pos)        /*!< 0x00000007 */
#define ADC_SMPR1_SMP0                    ADC_SMPR1_SMP0_Msk                   /*!< ADC Channel 0 Sampling time selection  */
#define ADC_SMPR1_SMP0_0                  (0x1UL << ADC_SMPR1_SMP0_Pos)         /*!< 0x00000001 */
#define ADC_SMPR1_SMP0_1                  (0x2UL << ADC_SMPR1_SMP0_Pos)         /*!< 0x00000002 */
#define ADC_SMPR1_SMP0_2                  (0x4UL << ADC_SMPR1_SMP0_Pos)         /*!< 0x00000004 */

#define ADC_SMPR1_SMP1_Pos                (3U)
#define ADC_SMPR1_SMP1_Msk                (0x7UL << ADC_SMPR1_SMP1_Pos)        /*!< 0x00000038 */
#define ADC_SMPR1_SMP1                    ADC_SMPR1_SMP1_Msk                   /*!< ADC Channel 1 Sampling time selection  */
#define ADC_SMPR1_SMP1_0                  (0x1UL << ADC_SMPR1_SMP1_Pos)         /*!< 0x00000008 */
#define ADC_SMPR1_SMP1_1                  (0x2UL << ADC_SMPR1_SMP1_Pos)         /*!< 0x00000010 */
#define ADC_SMPR1_SMP1_2                  (0x4UL << ADC_SMPR1_SMP1_Pos)         /*!< 0x00000020 */

#define ADC_SMPR1_SMP2_Pos                (6U)
#define ADC_SMPR1_SMP2_Msk                (0x7UL << ADC_SMPR1_SMP2_Pos)        /*!< 0x000001C0 */
#define ADC_SMPR1_SMP2                    ADC_SMPR1_SMP2_Msk                   /*!< ADC Channel 2 Sampling time selection  */
#define ADC_SMPR1_SMP2_0                  (0x1UL << ADC_SMPR1_SMP2_Pos)         /*!< 0x00000040 */
#define ADC_SMPR1_SMP2_1                  (0x2UL << ADC_SMPR1_SMP2_Pos)         /*!< 0x00000080 */
#define ADC_SMPR1_SMP2_2                  (0x4UL << ADC_SMPR1_SMP2_Pos)         /*!< 0x00000100 */

#define ADC_SMPR1_SMP3_Pos                (9U)
#define ADC_SMPR1_SMP3_Msk                (0x7UL << ADC_SMPR1_SMP3_Pos)        /*!< 0x00000E00 */
#define ADC_SMPR1_SMP3                    ADC_SMPR1_SMP3_Msk                   /*!< ADC Channel 3 Sampling time selection  */
#define ADC_SMPR1_SMP3_0                  (0x1UL << ADC_SMPR1_SMP3_Pos)         /*!< 0x00000200 */
#define ADC_SMPR1_SMP3_1                  (0x2UL << ADC_SMPR1_SMP3_Pos)         /*!< 0x00000400 */
#define ADC_SMPR1_SMP3_2                  (0x4UL << ADC_SMPR1_SMP3_Pos)         /*!< 0x00000800 */

#define ADC_SMPR1_SMP4_Pos                (12U)
#define ADC_SMPR1_SMP4_Msk                (0x7UL << ADC_SMPR1_SMP4_Pos)        /*!< 0x00007000 */
#define ADC_SMPR1_SMP4                    ADC_SMPR1_SMP4_Msk                   /*!< ADC Channel 4 Sampling time selection  */
#define ADC_SMPR1_SMP4_0                  (0x1UL << ADC_SMPR1_SMP4_Pos)         /*!< 0x00001000 */
#define ADC_SMPR1_SMP4_1                  (0x2UL << ADC_SMPR1_SMP4_Pos)         /*!< 0x00002000 */
#define ADC_SMPR1_SMP4_2                  (0x4UL << ADC_SMPR1_SMP4_Pos)         /*!< 0x00004000 */

#define ADC_SMPR1_SMP5_Pos                (15U)
#define ADC_SMPR1_SMP5_Msk                (0x7UL << ADC_SMPR1_SMP5_Pos)        /*!< 0x00038000 */
#define ADC_SMPR1_SMP5                    ADC_SMPR1_SMP5_Msk                   /*!< ADC Channel 5 Sampling time selection  */
#define ADC_SMPR1_SMP5_0                  (0x1UL << ADC_SMPR1_SMP5_Pos)         /*!< 0x00008000 */
#define ADC_SMPR1_SMP5_1                  (0x2UL << ADC_SMPR1_SMP5_Pos)         /*!< 0x00010000 */
#define ADC_SMPR1_SMP5_2                  (0x4UL << ADC_SMPR1_SMP5_Pos)         /*!< 0x00020000 */

#define ADC_SMPR1_SMP6_Pos                (18U)
#define ADC_SMPR1_SMP6_Msk                (0x7UL << ADC_SMPR1_SMP6_Pos)        /*!< 0x001C0000 */
#define ADC_SMPR1_SMP6                    ADC_SMPR1_SMP6_Msk                   /*!< ADC Channel 6 Sampling time selection  */
#define ADC_SMPR1_SMP6_0                  (0x1UL << ADC_SMPR1_SMP6_Pos)         /*!< 0x00040000 */
#define ADC_SMPR1_SMP6_1                  (0x2UL << ADC_SMPR1_SMP6_Pos)         /*!< 0x00080000 */
#define ADC_SMPR1_SMP6_2                  (0x4UL << ADC_SMPR1_SMP6_Pos)         /*!< 0x00100000 */

#define ADC_SMPR1_SMP7_Pos                (21U)
#define ADC_SMPR1_SMP7_Msk                (0x7UL << ADC_SMPR1_SMP7_Pos)        /*!< 0x00E00000 */
#define ADC_SMPR1_SMP7                    ADC_SMPR1_SMP7_Msk                   /*!< ADC Channel 7 Sampling time selection  */
#define ADC_SMPR1_SMP7_0                  (0x1UL << ADC_SMPR1_SMP7_Pos)         /*!< 0x00200000 */
#define ADC_SMPR1_SMP7_1                  (0x2UL << ADC_SMPR1_SMP7_Pos)         /*!< 0x00400000 */
#define ADC_SMPR1_SMP7_2                  (0x4UL << ADC_SMPR1_SMP7_Pos)         /*!< 0x00800000 */

#define ADC_SMPR1_SMP8_Pos                (24U)
#define ADC_SMPR1_SMP8_Msk                (0x7UL << ADC_SMPR1_SMP8_Pos)        /*!< 0x07000000 */
#define ADC_SMPR1_SMP8                    ADC_SMPR1_SMP8_Msk                   /*!< ADC Channel 8 Sampling time selection  */
#define ADC_SMPR1_SMP8_0                  (0x1UL << ADC_SMPR1_SMP8_Pos)         /*!< 0x01000000 */
#define ADC_SMPR1_SMP8_1                  (0x2UL << ADC_SMPR1_SMP8_Pos)         /*!< 0x02000000 */
#define ADC_SMPR1_SMP8_2                  (0x4UL << ADC_SMPR1_SMP8_Pos)         /*!< 0x04000000 */

#define ADC_SMPR1_SMP9_Pos                (27U)
#define ADC_SMPR1_SMP9_Msk                (0x7UL << ADC_SMPR1_SMP9_Pos)        /*!< 0x38000000 */
#define ADC_SMPR1_SMP9                    ADC_SMPR1_SMP9_Msk                   /*!< ADC Channel 9 Sampling time selection  */
#define ADC_SMPR1_SMP9_0                  (0x1UL << ADC_SMPR1_SMP9_Pos)         /*!< 0x08000000 */
#define ADC_SMPR1_SMP9_1                  (0x2UL << ADC_SMPR1_SMP9_Pos)         /*!< 0x10000000 */
#define ADC_SMPR1_SMP9_2                  (0x4UL << ADC_SMPR1_SMP9_Pos)         /*!< 0x20000000 */

/********************  Bit definition for ADC_SMPR2 register  ********************/
#define ADC_SMPR2_SMP10_Pos               (0)
#define ADC_SMPR2_SMP10_Msk               (0x7UL << ADC_SMPR2_SMP10_Pos)       /*!< 0x00000007 */
#define ADC_SMPR2_SMP10                   ADC_SMPR2_SMP10_Msk                  /*!< ADC Channel 10 Sampling time selection  */
#define ADC_SMPR2_SMP10_0                 (0x1UL << ADC_SMPR2_SMP10_Pos)        /*!< 0x00000001 */
#define ADC_SMPR2_SMP10_1                 (0x2UL << ADC_SMPR2_SMP10_Pos)        /*!< 0x00000002 */
#define ADC_SMPR2_SMP10_2                 (0x4UL << ADC_SMPR2_SMP10_Pos)        /*!< 0x00000004 */

#define ADC_SMPR2_SMP11_Pos               (3U)
#define ADC_SMPR2_SMP11_Msk               (0x7UL << ADC_SMPR2_SMP11_Pos)       /*!< 0x00000038 */
#define ADC_SMPR2_SMP11                   ADC_SMPR2_SMP11_Msk                  /*!< ADC Channel 11 Sampling time selection  */
#define ADC_SMPR2_SMP11_0                 (0x1UL << ADC_SMPR2_SMP11_Pos)        /*!< 0x00000008 */
#define ADC_SMPR2_SMP11_1                 (0x2UL << ADC_SMPR2_SMP11_Pos)        /*!< 0x00000010 */
#define ADC_SMPR2_SMP11_2                 (0x4UL << ADC_SMPR2_SMP11_Pos)        /*!< 0x00000020 */

#define ADC_SMPR2_SMP12_Pos               (6U)
#define ADC_SMPR2_SMP12_Msk               (0x7UL << ADC_SMPR2_SMP12_Pos)       /*!< 0x000001C0 */
#define ADC_SMPR2_SMP12                   ADC_SMPR2_SMP12_Msk                  /*!< ADC Channel 12 Sampling time selection  */
#define ADC_SMPR2_SMP12_0                 (0x1UL << ADC_SMPR2_SMP12_Pos)        /*!< 0x00000040 */
#define ADC_SMPR2_SMP12_1                 (0x2UL << ADC_SMPR2_SMP12_Pos)        /*!< 0x00000080 */
#define ADC_SMPR2_SMP12_2                 (0x4UL << ADC_SMPR2_SMP12_Pos)        /*!< 0x00000100 */

#define ADC_SMPR2_SMP13_Pos               (9U)
#define ADC_SMPR2_SMP13_Msk               (0x7UL << ADC_SMPR2_SMP13_Pos)       /*!< 0x00000E00 */
#define ADC_SMPR2_SMP13                   ADC_SMPR2_SMP13_Msk                  /*!< ADC Channel 13 Sampling time selection  */
#define ADC_SMPR2_SMP13_0                 (0x1UL << ADC_SMPR2_SMP13_Pos)        /*!< 0x00000200 */
#define ADC_SMPR2_SMP13_1                 (0x2UL << ADC_SMPR2_SMP13_Pos)        /*!< 0x00000400 */
#define ADC_SMPR2_SMP13_2                 (0x4UL << ADC_SMPR2_SMP13_Pos)        /*!< 0x00000800 */

#define ADC_SMPR2_SMP14_Pos               (12U)
#define ADC_SMPR2_SMP14_Msk               (0x7UL << ADC_SMPR2_SMP14_Pos)       /*!< 0x00007000 */
#define ADC_SMPR2_SMP14                   ADC_SMPR2_SMP14_Msk                  /*!< ADC Channel 14 Sampling time selection  */
#define ADC_SMPR2_SMP14_0                 (0x1UL << ADC_SMPR2_SMP14_Pos)        /*!< 0x00001000 */
#define ADC_SMPR2_SMP14_1                 (0x2UL << ADC_SMPR2_SMP14_Pos)        /*!< 0x00002000 */
#define ADC_SMPR2_SMP14_2                 (0x4UL << ADC_SMPR2_SMP14_Pos)        /*!< 0x00004000 */

#define ADC_SMPR2_SMP15_Pos               (15U)
#define ADC_SMPR2_SMP15_Msk               (0x7UL << ADC_SMPR2_SMP15_Pos)       /*!< 0x00038000 */
#define ADC_SMPR2_SMP15                   ADC_SMPR2_SMP15_Msk                  /*!< ADC Channel 15 Sampling time selection  */
#define ADC_SMPR2_SMP15_0                 (0x1UL << ADC_SMPR2_SMP15_Pos)        /*!< 0x00008000 */
#define ADC_SMPR2_SMP15_1                 (0x2UL << ADC_SMPR2_SMP15_Pos)        /*!< 0x00010000 */
#define ADC_SMPR2_SMP15_2                 (0x4UL << ADC_SMPR2_SMP15_Pos)        /*!< 0x00020000 */

#define ADC_SMPR2_SMP16_Pos               (18U)
#define ADC_SMPR2_SMP16_Msk               (0x7UL << ADC_SMPR2_SMP16_Pos)       /*!< 0x001C0000 */
#define ADC_SMPR2_SMP16                   ADC_SMPR2_SMP16_Msk                  /*!< ADC Channel 16 Sampling time selection  */
#define ADC_SMPR2_SMP16_0                 (0x1UL << ADC_SMPR2_SMP16_Pos)        /*!< 0x00040000 */
#define ADC_SMPR2_SMP16_1                 (0x2UL << ADC_SMPR2_SMP16_Pos)        /*!< 0x00080000 */
#define ADC_SMPR2_SMP16_2                 (0x4UL << ADC_SMPR2_SMP16_Pos)        /*!< 0x00100000 */

#define ADC_SMPR2_SMP17_Pos               (21U)
#define ADC_SMPR2_SMP17_Msk               (0x7UL << ADC_SMPR2_SMP17_Pos)       /*!< 0x00E00000 */
#define ADC_SMPR2_SMP17                   ADC_SMPR2_SMP17_Msk                  /*!< ADC Channel 17 Sampling time selection  */
#define ADC_SMPR2_SMP17_0                 (0x1UL << ADC_SMPR2_SMP17_Pos)        /*!< 0x00200000 */
#define ADC_SMPR2_SMP17_1                 (0x2UL << ADC_SMPR2_SMP17_Pos)        /*!< 0x00400000 */
#define ADC_SMPR2_SMP17_2                 (0x4UL << ADC_SMPR2_SMP17_Pos)        /*!< 0x00800000 */

#define ADC_SMPR2_SMP18_Pos               (24U)
#define ADC_SMPR2_SMP18_Msk               (0x7UL << ADC_SMPR2_SMP18_Pos)       /*!< 0x07000000 */
#define ADC_SMPR2_SMP18                   ADC_SMPR2_SMP18_Msk                  /*!< ADC Channel 18 Sampling time selection  */
#define ADC_SMPR2_SMP18_0                 (0x1UL << ADC_SMPR2_SMP18_Pos)        /*!< 0x01000000 */
#define ADC_SMPR2_SMP18_1                 (0x2UL << ADC_SMPR2_SMP18_Pos)        /*!< 0x02000000 */
#define ADC_SMPR2_SMP18_2                 (0x4UL << ADC_SMPR2_SMP18_Pos)        /*!< 0x04000000 */

#define ADC_SMPR2_SMP19_Pos               (27U)
#define ADC_SMPR2_SMP19_Msk               (0x7UL << ADC_SMPR2_SMP19_Pos)       /*!< 0x38000000 */
#define ADC_SMPR2_SMP19                   ADC_SMPR2_SMP19_Msk                  /*!< ADC Channel 19 Sampling time selection  */
#define ADC_SMPR2_SMP19_0                 (0x1UL << ADC_SMPR2_SMP19_Pos)        /*!< 0x08000000 */
#define ADC_SMPR2_SMP19_1                 (0x2UL << ADC_SMPR2_SMP19_Pos)        /*!< 0x10000000 */
#define ADC_SMPR2_SMP19_2                 (0x4UL << ADC_SMPR2_SMP19_Pos)        /*!< 0x20000000 */

/********************  Bit definition for ADC_PCSEL register  ********************/
#define ADC_PCSEL_PCSEL_Pos               (0)
#define ADC_PCSEL_PCSEL_Msk               (0xFFFFFUL << ADC_PCSEL_PCSEL_Pos)   /*!< 0x000FFFFF */
#define ADC_PCSEL_PCSEL                   ADC_PCSEL_PCSEL_Msk                  /*!< ADC pre channel selection */
#define ADC_PCSEL_PCSEL_0                 (0x00001UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000001 */
#define ADC_PCSEL_PCSEL_1                 (0x00002UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000002 */
#define ADC_PCSEL_PCSEL_2                 (0x00004UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000004 */
#define ADC_PCSEL_PCSEL_3                 (0x00008UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000008 */
#define ADC_PCSEL_PCSEL_4                 (0x00010UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000010 */
#define ADC_PCSEL_PCSEL_5                 (0x00020UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000020 */
#define ADC_PCSEL_PCSEL_6                 (0x00040UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000040 */
#define ADC_PCSEL_PCSEL_7                 (0x00080UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000080 */
#define ADC_PCSEL_PCSEL_8                 (0x00100UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000100 */
#define ADC_PCSEL_PCSEL_9                 (0x00200UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000200 */
#define ADC_PCSEL_PCSEL_10                (0x00400UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000400 */
#define ADC_PCSEL_PCSEL_11                (0x00800UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00000800 */
#define ADC_PCSEL_PCSEL_12                (0x01000UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00001000 */
#define ADC_PCSEL_PCSEL_13                (0x02000UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00002000 */
#define ADC_PCSEL_PCSEL_14                (0x04000UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00004000 */
#define ADC_PCSEL_PCSEL_15                (0x08000UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00008000 */
#define ADC_PCSEL_PCSEL_16                (0x10000UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00010000 */
#define ADC_PCSEL_PCSEL_17                (0x20000UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00020000 */
#define ADC_PCSEL_PCSEL_18                (0x40000UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00040000 */
#define ADC_PCSEL_PCSEL_19                (0x80000UL << ADC_PCSEL_PCSEL_Pos)    /*!< 0x00080000 */

/*****************  Bit definition for ADC_LTR1, 2, 3 registers *****************/
#define ADC_LTR_LT_Pos                    (0)
#define ADC_LTR_LT_Msk                    (0x3FFFFFFUL << ADC_LTR_LT_Pos)      /*!< 0x03FFFFFF */
#define ADC_LTR_LT                        ADC_LTR_LT_Msk                       /*!< ADC Analog watchdog 1, 2 and 3 lower threshold */

/*****************  Bit definition for ADC_HTR1, 2, 3 registers  ****************/
#define ADC_HTR_HT_Pos                    (0)
#define ADC_HTR_HT_Msk                    (0x3FFFFFFUL << ADC_HTR_HT_Pos)      /*!< 0x03FFFFFF */
#define ADC_HTR_HT                        ADC_HTR_HT_Msk                       /*!< ADC Analog watchdog 1,2 and 3 higher threshold */

/********************  Bit definition for ADC_SQR1 register  ********************/
#define ADC_SQR1_L_Pos                    (0)
#define ADC_SQR1_L_Msk                    (0xFUL << ADC_SQR1_L_Pos)            /*!< 0x0000000F */
#define ADC_SQR1_L                        ADC_SQR1_L_Msk                       /*!< ADC regular channel sequence lenght */
#define ADC_SQR1_L_0                      (0x1UL << ADC_SQR1_L_Pos)             /*!< 0x00000001 */
#define ADC_SQR1_L_1                      (0x2UL << ADC_SQR1_L_Pos)             /*!< 0x00000002 */
#define ADC_SQR1_L_2                      (0x4UL << ADC_SQR1_L_Pos)             /*!< 0x00000004 */
#define ADC_SQR1_L_3                      (0x8UL << ADC_SQR1_L_Pos)             /*!< 0x00000008 */

#define ADC_SQR1_SQ1_Pos                  (6U)
#define ADC_SQR1_SQ1_Msk                  (0x1FUL << ADC_SQR1_SQ1_Pos)         /*!< 0x000007C0 */
#define ADC_SQR1_SQ1                      ADC_SQR1_SQ1_Msk                     /*!< ADC 1st conversion in regular sequence */
#define ADC_SQR1_SQ1_0                    (0x01UL << ADC_SQR1_SQ1_Pos)          /*!< 0x00000040 */
#define ADC_SQR1_SQ1_1                    (0x02UL << ADC_SQR1_SQ1_Pos)          /*!< 0x00000080 */
#define ADC_SQR1_SQ1_2                    (0x04UL << ADC_SQR1_SQ1_Pos)          /*!< 0x00000100 */
#define ADC_SQR1_SQ1_3                    (0x08UL << ADC_SQR1_SQ1_Pos)          /*!< 0x00000200 */
#define ADC_SQR1_SQ1_4                    (0x10UL << ADC_SQR1_SQ1_Pos)          /*!< 0x00000400 */

#define ADC_SQR1_SQ2_Pos                  (12U)
#define ADC_SQR1_SQ2_Msk                  (0x1FUL << ADC_SQR1_SQ2_Pos)         /*!< 0x0001F000 */
#define ADC_SQR1_SQ2                      ADC_SQR1_SQ2_Msk                     /*!< ADC 2nd conversion in regular sequence */
#define ADC_SQR1_SQ2_0                    (0x01UL << ADC_SQR1_SQ2_Pos)          /*!< 0x00001000 */
#define ADC_SQR1_SQ2_1                    (0x02UL << ADC_SQR1_SQ2_Pos)          /*!< 0x00002000 */
#define ADC_SQR1_SQ2_2                    (0x04UL << ADC_SQR1_SQ2_Pos)          /*!< 0x00004000 */
#define ADC_SQR1_SQ2_3                    (0x08UL << ADC_SQR1_SQ2_Pos)          /*!< 0x00008000 */
#define ADC_SQR1_SQ2_4                    (0x10UL << ADC_SQR1_SQ2_Pos)          /*!< 0x00010000 */

#define ADC_SQR1_SQ3_Pos                  (18U)
#define ADC_SQR1_SQ3_Msk                  (0x1FUL << ADC_SQR1_SQ3_Pos)         /*!< 0x007C0000 */
#define ADC_SQR1_SQ3                      ADC_SQR1_SQ3_Msk                     /*!< ADC 3rd conversion in regular sequence */
#define ADC_SQR1_SQ3_0                    (0x01UL << ADC_SQR1_SQ3_Pos)          /*!< 0x00040000 */
#define ADC_SQR1_SQ3_1                    (0x02UL << ADC_SQR1_SQ3_Pos)          /*!< 0x00080000 */
#define ADC_SQR1_SQ3_2                    (0x04UL << ADC_SQR1_SQ3_Pos)          /*!< 0x00100000 */
#define ADC_SQR1_SQ3_3                    (0x08UL << ADC_SQR1_SQ3_Pos)          /*!< 0x00200000 */
#define ADC_SQR1_SQ3_4                    (0x10UL << ADC_SQR1_SQ3_Pos)          /*!< 0x00400000 */

#define ADC_SQR1_SQ4_Pos                  (24U)
#define ADC_SQR1_SQ4_Msk                  (0x1FUL << ADC_SQR1_SQ4_Pos)         /*!< 0x1F000000 */
#define ADC_SQR1_SQ4                      ADC_SQR1_SQ4_Msk                     /*!< ADC 4th conversion in regular sequence */
#define ADC_SQR1_SQ4_0                    (0x01UL << ADC_SQR1_SQ4_Pos)          /*!< 0x01000000 */
#define ADC_SQR1_SQ4_1                    (0x02UL << ADC_SQR1_SQ4_Pos)          /*!< 0x02000000 */
#define ADC_SQR1_SQ4_2                    (0x04UL << ADC_SQR1_SQ4_Pos)          /*!< 0x04000000 */
#define ADC_SQR1_SQ4_3                    (0x08UL << ADC_SQR1_SQ4_Pos)          /*!< 0x08000000 */
#define ADC_SQR1_SQ4_4                    (0x10UL << ADC_SQR1_SQ4_Pos)          /*!< 0x10000000 */

/********************  Bit definition for ADC_SQR2 register  ********************/
#define ADC_SQR2_SQ5_Pos                  (0)
#define ADC_SQR2_SQ5_Msk                  (0x1FUL << ADC_SQR2_SQ5_Pos)         /*!< 0x0000001F */
#define ADC_SQR2_SQ5                      ADC_SQR2_SQ5_Msk                     /*!< ADC 5th conversion in regular sequence */
#define ADC_SQR2_SQ5_0                    (0x01UL << ADC_SQR2_SQ5_Pos)          /*!< 0x00000001 */
#define ADC_SQR2_SQ5_1                    (0x02UL << ADC_SQR2_SQ5_Pos)          /*!< 0x00000002 */
#define ADC_SQR2_SQ5_2                    (0x04UL << ADC_SQR2_SQ5_Pos)          /*!< 0x00000004 */
#define ADC_SQR2_SQ5_3                    (0x08UL << ADC_SQR2_SQ5_Pos)          /*!< 0x00000008 */
#define ADC_SQR2_SQ5_4                    (0x10UL << ADC_SQR2_SQ5_Pos)          /*!< 0x00000010 */

#define ADC_SQR2_SQ6_Pos                  (6U)
#define ADC_SQR2_SQ6_Msk                  (0x1FUL << ADC_SQR2_SQ6_Pos)         /*!< 0x000007C0 */
#define ADC_SQR2_SQ6                      ADC_SQR2_SQ6_Msk                     /*!< ADC 6th conversion in regular sequence */
#define ADC_SQR2_SQ6_0                    (0x01UL << ADC_SQR2_SQ6_Pos)          /*!< 0x00000040 */
#define ADC_SQR2_SQ6_1                    (0x02UL << ADC_SQR2_SQ6_Pos)          /*!< 0x00000080 */
#define ADC_SQR2_SQ6_2                    (0x04UL << ADC_SQR2_SQ6_Pos)          /*!< 0x00000100 */
#define ADC_SQR2_SQ6_3                    (0x08UL << ADC_SQR2_SQ6_Pos)          /*!< 0x00000200 */
#define ADC_SQR2_SQ6_4                    (0x10UL << ADC_SQR2_SQ6_Pos)          /*!< 0x00000400 */

#define ADC_SQR2_SQ7_Pos                  (12U)
#define ADC_SQR2_SQ7_Msk                  (0x1FUL << ADC_SQR2_SQ7_Pos)         /*!< 0x0001F000 */
#define ADC_SQR2_SQ7                      ADC_SQR2_SQ7_Msk                     /*!< ADC 7th conversion in regular sequence */
#define ADC_SQR2_SQ7_0                    (0x01UL << ADC_SQR2_SQ7_Pos)          /*!< 0x00001000 */
#define ADC_SQR2_SQ7_1                    (0x02UL << ADC_SQR2_SQ7_Pos)          /*!< 0x00002000 */
#define ADC_SQR2_SQ7_2                    (0x04UL << ADC_SQR2_SQ7_Pos)          /*!< 0x00004000 */
#define ADC_SQR2_SQ7_3                    (0x08UL << ADC_SQR2_SQ7_Pos)          /*!< 0x00008000 */
#define ADC_SQR2_SQ7_4                    (0x10UL << ADC_SQR2_SQ7_Pos)          /*!< 0x00010000 */

#define ADC_SQR2_SQ8_Pos                  (18U)
#define ADC_SQR2_SQ8_Msk                  (0x1FUL << ADC_SQR2_SQ8_Pos)         /*!< 0x007C0000 */
#define ADC_SQR2_SQ8                      ADC_SQR2_SQ8_Msk                     /*!< ADC 8th conversion in regular sequence */
#define ADC_SQR2_SQ8_0                    (0x01UL << ADC_SQR2_SQ8_Pos)          /*!< 0x00040000 */
#define ADC_SQR2_SQ8_1                    (0x02UL << ADC_SQR2_SQ8_Pos)          /*!< 0x00080000 */
#define ADC_SQR2_SQ8_2                    (0x04UL << ADC_SQR2_SQ8_Pos)          /*!< 0x00100000 */
#define ADC_SQR2_SQ8_3                    (0x08UL << ADC_SQR2_SQ8_Pos)          /*!< 0x00200000 */
#define ADC_SQR2_SQ8_4                    (0x10UL << ADC_SQR2_SQ8_Pos)          /*!< 0x00400000 */

#define ADC_SQR2_SQ9_Pos                  (24U)
#define ADC_SQR2_SQ9_Msk                  (0x1FUL << ADC_SQR2_SQ9_Pos)         /*!< 0x1F000000 */
#define ADC_SQR2_SQ9                      ADC_SQR2_SQ9_Msk                     /*!< ADC 9th conversion in regular sequence */
#define ADC_SQR2_SQ9_0                    (0x01UL << ADC_SQR2_SQ9_Pos)          /*!< 0x01000000 */
#define ADC_SQR2_SQ9_1                    (0x02UL << ADC_SQR2_SQ9_Pos)          /*!< 0x02000000 */
#define ADC_SQR2_SQ9_2                    (0x04UL << ADC_SQR2_SQ9_Pos)          /*!< 0x04000000 */
#define ADC_SQR2_SQ9_3                    (0x08UL << ADC_SQR2_SQ9_Pos)          /*!< 0x08000000 */
#define ADC_SQR2_SQ9_4                    (0x10UL << ADC_SQR2_SQ9_Pos)          /*!< 0x10000000 */

/********************  Bit definition for ADC_SQR3 register  ********************/
#define ADC_SQR3_SQ10_Pos                 (0)
#define ADC_SQR3_SQ10_Msk                 (0x1FUL << ADC_SQR3_SQ10_Pos)        /*!< 0x0000001F */
#define ADC_SQR3_SQ10                     ADC_SQR3_SQ10_Msk                    /*!< ADC 10th conversion in regular sequence */
#define ADC_SQR3_SQ10_0                   (0x01UL << ADC_SQR3_SQ10_Pos)         /*!< 0x00000001 */
#define ADC_SQR3_SQ10_1                   (0x02UL << ADC_SQR3_SQ10_Pos)         /*!< 0x00000002 */
#define ADC_SQR3_SQ10_2                   (0x04UL << ADC_SQR3_SQ10_Pos)         /*!< 0x00000004 */
#define ADC_SQR3_SQ10_3                   (0x08UL << ADC_SQR3_SQ10_Pos)         /*!< 0x00000008 */
#define ADC_SQR3_SQ10_4                   (0x10UL << ADC_SQR3_SQ10_Pos)         /*!< 0x00000010 */

#define ADC_SQR3_SQ11_Pos                 (6U)
#define ADC_SQR3_SQ11_Msk                 (0x1FUL << ADC_SQR3_SQ11_Pos)        /*!< 0x000007C0 */
#define ADC_SQR3_SQ11                     ADC_SQR3_SQ11_Msk                    /*!< ADC 11th conversion in regular sequence */
#define ADC_SQR3_SQ11_0                   (0x01UL << ADC_SQR3_SQ11_Pos)         /*!< 0x00000040 */
#define ADC_SQR3_SQ11_1                   (0x02UL << ADC_SQR3_SQ11_Pos)         /*!< 0x00000080 */
#define ADC_SQR3_SQ11_2                   (0x04UL << ADC_SQR3_SQ11_Pos)         /*!< 0x00000100 */
#define ADC_SQR3_SQ11_3                   (0x08UL << ADC_SQR3_SQ11_Pos)         /*!< 0x00000200 */
#define ADC_SQR3_SQ11_4                   (0x10UL << ADC_SQR3_SQ11_Pos)         /*!< 0x00000400 */

#define ADC_SQR3_SQ12_Pos                 (12U)
#define ADC_SQR3_SQ12_Msk                 (0x1FUL << ADC_SQR3_SQ12_Pos)        /*!< 0x0001F000 */
#define ADC_SQR3_SQ12                     ADC_SQR3_SQ12_Msk                    /*!< ADC 12th conversion in regular sequence */
#define ADC_SQR3_SQ12_0                   (0x01UL << ADC_SQR3_SQ12_Pos)         /*!< 0x00001000 */
#define ADC_SQR3_SQ12_1                   (0x02UL << ADC_SQR3_SQ12_Pos)         /*!< 0x00002000 */
#define ADC_SQR3_SQ12_2                   (0x04UL << ADC_SQR3_SQ12_Pos)         /*!< 0x00004000 */
#define ADC_SQR3_SQ12_3                   (0x08UL << ADC_SQR3_SQ12_Pos)         /*!< 0x00008000 */
#define ADC_SQR3_SQ12_4                   (0x10UL << ADC_SQR3_SQ12_Pos)         /*!< 0x00010000 */

#define ADC_SQR3_SQ13_Pos                 (18U)
#define ADC_SQR3_SQ13_Msk                 (0x1FUL << ADC_SQR3_SQ13_Pos)        /*!< 0x007C0000 */
#define ADC_SQR3_SQ13                     ADC_SQR3_SQ13_Msk                    /*!< ADC 13th conversion in regular sequence */
#define ADC_SQR3_SQ13_0                   (0x01UL << ADC_SQR3_SQ13_Pos)         /*!< 0x00040000 */
#define ADC_SQR3_SQ13_1                   (0x02UL << ADC_SQR3_SQ13_Pos)         /*!< 0x00080000 */
#define ADC_SQR3_SQ13_2                   (0x04UL << ADC_SQR3_SQ13_Pos)         /*!< 0x00100000 */
#define ADC_SQR3_SQ13_3                   (0x08UL << ADC_SQR3_SQ13_Pos)         /*!< 0x00200000 */
#define ADC_SQR3_SQ13_4                   (0x10UL << ADC_SQR3_SQ13_Pos)         /*!< 0x00400000 */

#define ADC_SQR3_SQ14_Pos                 (24U)
#define ADC_SQR3_SQ14_Msk                 (0x1FUL << ADC_SQR3_SQ14_Pos)        /*!< 0x1F000000 */
#define ADC_SQR3_SQ14                     ADC_SQR3_SQ14_Msk                    /*!< ADC 14th conversion in regular sequence */
#define ADC_SQR3_SQ14_0                   (0x01UL << ADC_SQR3_SQ14_Pos)         /*!< 0x01000000 */
#define ADC_SQR3_SQ14_1                   (0x02UL << ADC_SQR3_SQ14_Pos)         /*!< 0x02000000 */
#define ADC_SQR3_SQ14_2                   (0x04UL << ADC_SQR3_SQ14_Pos)         /*!< 0x04000000 */
#define ADC_SQR3_SQ14_3                   (0x08UL << ADC_SQR3_SQ14_Pos)         /*!< 0x08000000 */
#define ADC_SQR3_SQ14_4                   (0x10UL << ADC_SQR3_SQ14_Pos)         /*!< 0x10000000 */

/********************  Bit definition for ADC_SQR4 register  ********************/
#define ADC_SQR4_SQ15_Pos                 (0)
#define ADC_SQR4_SQ15_Msk                 (0x1FUL << ADC_SQR4_SQ15_Pos)        /*!< 0x0000001F */
#define ADC_SQR4_SQ15                     ADC_SQR4_SQ15_Msk                    /*!< ADC 15th conversion in regular sequence */
#define ADC_SQR4_SQ15_0                   (0x01UL << ADC_SQR4_SQ15_Pos)         /*!< 0x00000001 */
#define ADC_SQR4_SQ15_1                   (0x02UL << ADC_SQR4_SQ15_Pos)         /*!< 0x00000002 */
#define ADC_SQR4_SQ15_2                   (0x04UL << ADC_SQR4_SQ15_Pos)         /*!< 0x00000004 */
#define ADC_SQR4_SQ15_3                   (0x08UL << ADC_SQR4_SQ15_Pos)         /*!< 0x00000008 */
#define ADC_SQR4_SQ15_4                   (0x10UL << ADC_SQR4_SQ15_Pos)         /*!< 0x00000010 */

#define ADC_SQR4_SQ16_Pos                 (6U)
#define ADC_SQR4_SQ16_Msk                 (0x1FUL << ADC_SQR4_SQ16_Pos)        /*!< 0x000007C0 */
#define ADC_SQR4_SQ16                     ADC_SQR4_SQ16_Msk                    /*!< ADC 16th conversion in regular sequence */
#define ADC_SQR4_SQ16_0                   (0x01UL << ADC_SQR4_SQ16_Pos)         /*!< 0x00000040 */
#define ADC_SQR4_SQ16_1                   (0x02UL << ADC_SQR4_SQ16_Pos)         /*!< 0x00000080 */
#define ADC_SQR4_SQ16_2                   (0x04UL << ADC_SQR4_SQ16_Pos)         /*!< 0x00000100 */
#define ADC_SQR4_SQ16_3                   (0x08UL << ADC_SQR4_SQ16_Pos)         /*!< 0x00000200 */
#define ADC_SQR4_SQ16_4                   (0x10UL << ADC_SQR4_SQ16_Pos)         /*!< 0x00000400 */
/********************  Bit definition for ADC_DR register  ********************/
#define ADC_DR_RDATA_Pos                  (0)
#define ADC_DR_RDATA_Msk                  (0xFFFFFFFFUL << ADC_DR_RDATA_Pos)   /*!< 0xFFFFFFFF */
#define ADC_DR_RDATA                      ADC_DR_RDATA_Msk                     /*!< ADC regular Data converted */

/********************  Bit definition for ADC_JSQR register  ********************/
#define ADC_JSQR_JL_Pos                   (0)
#define ADC_JSQR_JL_Msk                   (0x3UL << ADC_JSQR_JL_Pos)           /*!< 0x00000003 */
#define ADC_JSQR_JL                       ADC_JSQR_JL_Msk                      /*!< ADC injected channel sequence length */
#define ADC_JSQR_JL_0                     (0x1UL << ADC_JSQR_JL_Pos)            /*!< 0x00000001 */
#define ADC_JSQR_JL_1                     (0x2UL << ADC_JSQR_JL_Pos)            /*!< 0x00000002 */

#define ADC_JSQR_JEXTSEL_Pos              (2U)
#define ADC_JSQR_JEXTSEL_Msk              (0x1FUL << ADC_JSQR_JEXTSEL_Pos)     /*!< 0x0000007C */
#define ADC_JSQR_JEXTSEL                  ADC_JSQR_JEXTSEL_Msk                 /*!< ADC external trigger selection for injected group */
#define ADC_JSQR_JEXTSEL_0                (0x01UL << ADC_JSQR_JEXTSEL_Pos)      /*!< 0x00000004 */
#define ADC_JSQR_JEXTSEL_1                (0x02UL << ADC_JSQR_JEXTSEL_Pos)      /*!< 0x00000008 */
#define ADC_JSQR_JEXTSEL_2                (0x04UL << ADC_JSQR_JEXTSEL_Pos)      /*!< 0x00000010 */
#define ADC_JSQR_JEXTSEL_3                (0x08UL << ADC_JSQR_JEXTSEL_Pos)      /*!< 0x00000020 */
#define ADC_JSQR_JEXTSEL_4                (0x10UL << ADC_JSQR_JEXTSEL_Pos)      /*!< 0x00000040 */

#define ADC_JSQR_JEXTEN_Pos               (7U)
#define ADC_JSQR_JEXTEN_Msk               (0x3UL << ADC_JSQR_JEXTEN_Pos)       /*!< 0x00000180 */
#define ADC_JSQR_JEXTEN                   ADC_JSQR_JEXTEN_Msk                  /*!< ADC external trigger enable and polarity selection for injected channels */
#define ADC_JSQR_JEXTEN_0                 (0x1UL << ADC_JSQR_JEXTEN_Pos)        /*!< 0x00000080 */
#define ADC_JSQR_JEXTEN_1                 (0x2UL << ADC_JSQR_JEXTEN_Pos)        /*!< 0x00000100 */

#define ADC_JSQR_JSQ1_Pos                 (9U)
#define ADC_JSQR_JSQ1_Msk                 (0x1FUL << ADC_JSQR_JSQ1_Pos)        /*!< 0x00003E00 */
#define ADC_JSQR_JSQ1                     ADC_JSQR_JSQ1_Msk                    /*!< ADC 1st conversion in injected sequence */
#define ADC_JSQR_JSQ1_0                   (0x01UL << ADC_JSQR_JSQ1_Pos)         /*!< 0x00000200 */
#define ADC_JSQR_JSQ1_1                   (0x02UL << ADC_JSQR_JSQ1_Pos)         /*!< 0x00000400 */
#define ADC_JSQR_JSQ1_2                   (0x04UL << ADC_JSQR_JSQ1_Pos)         /*!< 0x00000800 */
#define ADC_JSQR_JSQ1_3                   (0x08UL << ADC_JSQR_JSQ1_Pos)         /*!< 0x00001000 */
#define ADC_JSQR_JSQ1_4                   (0x10UL << ADC_JSQR_JSQ1_Pos)         /*!< 0x00002000 */

#define ADC_JSQR_JSQ2_Pos                 (15U)
#define ADC_JSQR_JSQ2_Msk                 (0x1FUL << ADC_JSQR_JSQ2_Pos)        /*!< 0x000F8000 */
#define ADC_JSQR_JSQ2                     ADC_JSQR_JSQ2_Msk                    /*!< ADC 2nd conversion in injected sequence */
#define ADC_JSQR_JSQ2_0                   (0x01UL << ADC_JSQR_JSQ2_Pos)         /*!< 0x00008000 */
#define ADC_JSQR_JSQ2_1                   (0x02UL << ADC_JSQR_JSQ2_Pos)         /*!< 0x00010000 */
#define ADC_JSQR_JSQ2_2                   (0x04UL << ADC_JSQR_JSQ2_Pos)         /*!< 0x00020000 */
#define ADC_JSQR_JSQ2_3                   (0x08UL << ADC_JSQR_JSQ2_Pos)         /*!< 0x00040000 */
#define ADC_JSQR_JSQ2_4                   (0x10UL << ADC_JSQR_JSQ2_Pos)         /*!< 0x00080000 */

#define ADC_JSQR_JSQ3_Pos                 (21U)
#define ADC_JSQR_JSQ3_Msk                 (0x1FUL << ADC_JSQR_JSQ3_Pos)        /*!< 0x03E00000 */
#define ADC_JSQR_JSQ3                     ADC_JSQR_JSQ3_Msk                    /*!< ADC 3rd conversion in injected sequence */
#define ADC_JSQR_JSQ3_0                   (0x01UL << ADC_JSQR_JSQ3_Pos)         /*!< 0x00200000 */
#define ADC_JSQR_JSQ3_1                   (0x02UL << ADC_JSQR_JSQ3_Pos)         /*!< 0x00400000 */
#define ADC_JSQR_JSQ3_2                   (0x04UL << ADC_JSQR_JSQ3_Pos)         /*!< 0x00800000 */
#define ADC_JSQR_JSQ3_3                   (0x08UL << ADC_JSQR_JSQ3_Pos)         /*!< 0x01000000 */
#define ADC_JSQR_JSQ3_4                   (0x10UL << ADC_JSQR_JSQ3_Pos)         /*!< 0x02000000 */

#define ADC_JSQR_JSQ4_Pos                 (27U)
#define ADC_JSQR_JSQ4_Msk                 (0x1FUL << ADC_JSQR_JSQ4_Pos)        /*!< 0xF8000000 */
#define ADC_JSQR_JSQ4                     ADC_JSQR_JSQ4_Msk                    /*!< ADC 4th conversion in injected sequence */
#define ADC_JSQR_JSQ4_0                   (0x01UL << ADC_JSQR_JSQ4_Pos)         /*!< 0x08000000 */
#define ADC_JSQR_JSQ4_1                   (0x02UL << ADC_JSQR_JSQ4_Pos)         /*!< 0x10000000 */
#define ADC_JSQR_JSQ4_2                   (0x04UL << ADC_JSQR_JSQ4_Pos)         /*!< 0x20000000 */
#define ADC_JSQR_JSQ4_3                   (0x08UL << ADC_JSQR_JSQ4_Pos)         /*!< 0x40000000 */
#define ADC_JSQR_JSQ4_4                   (0x10UL << ADC_JSQR_JSQ4_Pos)         /*!< 0x80000000 */

/********************  Bit definition for ADC_OFR1 register  ********************/
#define ADC_OFR1_OFFSET1_Pos              (0)
#define ADC_OFR1_OFFSET1_Msk              (0x3FFFFFFUL << ADC_OFR1_OFFSET1_Pos) /*!< 0x03FFFFFF */
#define ADC_OFR1_OFFSET1                  ADC_OFR1_OFFSET1_Msk                 /*!< ADC data offset 1 for channel programmed into bits OFFSET1_CH[4:0] */
#define ADC_OFR1_OFFSET1_0                (0x0000001UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000001 */
#define ADC_OFR1_OFFSET1_1                (0x0000002UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000002 */
#define ADC_OFR1_OFFSET1_2                (0x0000004UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000004 */
#define ADC_OFR1_OFFSET1_3                (0x0000008UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000008 */
#define ADC_OFR1_OFFSET1_4                (0x0000010UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000010 */
#define ADC_OFR1_OFFSET1_5                (0x0000020UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000020 */
#define ADC_OFR1_OFFSET1_6                (0x0000040UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000040 */
#define ADC_OFR1_OFFSET1_7                (0x0000080UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000080 */
#define ADC_OFR1_OFFSET1_8                (0x0000100UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000100 */
#define ADC_OFR1_OFFSET1_9                (0x0000200UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000200 */
#define ADC_OFR1_OFFSET1_10               (0x0000400UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000400 */
#define ADC_OFR1_OFFSET1_11               (0x0000800UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00000800 */
#define ADC_OFR1_OFFSET1_12               (0x0001000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00001000 */
#define ADC_OFR1_OFFSET1_13               (0x0002000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00002000 */
#define ADC_OFR1_OFFSET1_14               (0x0004000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00004000 */
#define ADC_OFR1_OFFSET1_15               (0x0008000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00008000 */
#define ADC_OFR1_OFFSET1_16               (0x0010000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00010000 */
#define ADC_OFR1_OFFSET1_17               (0x0020000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00020000 */
#define ADC_OFR1_OFFSET1_18               (0x0040000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00040000 */
#define ADC_OFR1_OFFSET1_19               (0x0080000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00080000 */
#define ADC_OFR1_OFFSET1_20               (0x0100000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00100000 */
#define ADC_OFR1_OFFSET1_21               (0x0200000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00200000 */
#define ADC_OFR1_OFFSET1_22               (0x0400000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00400000 */
#define ADC_OFR1_OFFSET1_23               (0x0800000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x00800000 */
#define ADC_OFR1_OFFSET1_24               (0x1000000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x01000000 */
#define ADC_OFR1_OFFSET1_25               (0x2000000UL << ADC_OFR1_OFFSET1_Pos) /*!< 0x02000000 */

#define ADC_OFR1_OFFSET1_CH_Pos           (26U)
#define ADC_OFR1_OFFSET1_CH_Msk           (0x1FUL << ADC_OFR1_OFFSET1_CH_Pos)  /*!< 0x7C000000 */
#define ADC_OFR1_OFFSET1_CH               ADC_OFR1_OFFSET1_CH_Msk              /*!< ADC Channel selection for the data offset 1 */
#define ADC_OFR1_OFFSET1_CH_0             (0x01UL << ADC_OFR1_OFFSET1_CH_Pos)   /*!< 0x04000000 */
#define ADC_OFR1_OFFSET1_CH_1             (0x02UL << ADC_OFR1_OFFSET1_CH_Pos)   /*!< 0x08000000 */
#define ADC_OFR1_OFFSET1_CH_2             (0x04UL << ADC_OFR1_OFFSET1_CH_Pos)   /*!< 0x10000000 */
#define ADC_OFR1_OFFSET1_CH_3             (0x08UL << ADC_OFR1_OFFSET1_CH_Pos)   /*!< 0x20000000 */
#define ADC_OFR1_OFFSET1_CH_4             (0x10UL << ADC_OFR1_OFFSET1_CH_Pos)   /*!< 0x40000000 */

#define ADC_OFR1_SSATE_Pos                (31U)
#define ADC_OFR1_SSATE_Msk                (0x1UL << ADC_OFR1_SSATE_Pos)        /*!< 0x80000000 */
#define ADC_OFR1_SSATE                    ADC_OFR1_SSATE_Msk                   /*!< ADC Signed saturation Enable */

/********************  Bit definition for ADC_OFR2 register  ********************/
#define ADC_OFR2_OFFSET2_Pos              (0)
#define ADC_OFR2_OFFSET2_Msk              (0x3FFFFFFUL << ADC_OFR2_OFFSET2_Pos) /*!< 0x03FFFFFF */
#define ADC_OFR2_OFFSET2                  ADC_OFR2_OFFSET2_Msk                 /*!< ADC data offset 2 for channel programmed into bits OFFSET2_CH[4:0] */
#define ADC_OFR2_OFFSET2_0                (0x0000001UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000001 */
#define ADC_OFR2_OFFSET2_1                (0x0000002UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000002 */
#define ADC_OFR2_OFFSET2_2                (0x0000004UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000004 */
#define ADC_OFR2_OFFSET2_3                (0x0000008UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000008 */
#define ADC_OFR2_OFFSET2_4                (0x0000010UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000010 */
#define ADC_OFR2_OFFSET2_5                (0x0000020UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000020 */
#define ADC_OFR2_OFFSET2_6                (0x0000040UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000040 */
#define ADC_OFR2_OFFSET2_7                (0x0000080UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000080 */
#define ADC_OFR2_OFFSET2_8                (0x0000100UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000100 */
#define ADC_OFR2_OFFSET2_9                (0x0000200UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000200 */
#define ADC_OFR2_OFFSET2_10               (0x0000400UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000400 */
#define ADC_OFR2_OFFSET2_11               (0x0000800UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00000800 */
#define ADC_OFR2_OFFSET2_12               (0x0001000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00001000 */
#define ADC_OFR2_OFFSET2_13               (0x0002000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00002000 */
#define ADC_OFR2_OFFSET2_14               (0x0004000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00004000 */
#define ADC_OFR2_OFFSET2_15               (0x0008000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00008000 */
#define ADC_OFR2_OFFSET2_16               (0x0010000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00010000 */
#define ADC_OFR2_OFFSET2_17               (0x0020000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00020000 */
#define ADC_OFR2_OFFSET2_18               (0x0040000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00040000 */
#define ADC_OFR2_OFFSET2_19               (0x0080000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00080000 */
#define ADC_OFR2_OFFSET2_20               (0x0100000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00100000 */
#define ADC_OFR2_OFFSET2_21               (0x0200000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00200000 */
#define ADC_OFR2_OFFSET2_22               (0x0400000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00400000 */
#define ADC_OFR2_OFFSET2_23               (0x0800000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x00800000 */
#define ADC_OFR2_OFFSET2_24               (0x1000000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x01000000 */
#define ADC_OFR2_OFFSET2_25               (0x2000000UL << ADC_OFR2_OFFSET2_Pos) /*!< 0x02000000 */

#define ADC_OFR2_OFFSET2_CH_Pos           (26U)
#define ADC_OFR2_OFFSET2_CH_Msk           (0x1FUL << ADC_OFR2_OFFSET2_CH_Pos)  /*!< 0x7C000000 */
#define ADC_OFR2_OFFSET2_CH               ADC_OFR2_OFFSET2_CH_Msk              /*!< ADC Channel selection for the data offset 2 */
#define ADC_OFR2_OFFSET2_CH_0             (0x01UL << ADC_OFR2_OFFSET2_CH_Pos)   /*!< 0x04000000 */
#define ADC_OFR2_OFFSET2_CH_1             (0x02UL << ADC_OFR2_OFFSET2_CH_Pos)   /*!< 0x08000000 */
#define ADC_OFR2_OFFSET2_CH_2             (0x04UL << ADC_OFR2_OFFSET2_CH_Pos)   /*!< 0x10000000 */
#define ADC_OFR2_OFFSET2_CH_3             (0x08UL << ADC_OFR2_OFFSET2_CH_Pos)   /*!< 0x20000000 */
#define ADC_OFR2_OFFSET2_CH_4             (0x10UL << ADC_OFR2_OFFSET2_CH_Pos)   /*!< 0x40000000 */

#define ADC_OFR2_SSATE_Pos                (31U)
#define ADC_OFR2_SSATE_Msk                (0x1UL << ADC_OFR2_SSATE_Pos)        /*!< 0x80000000 */
#define ADC_OFR2_SSATE                    ADC_OFR2_SSATE_Msk                   /*!< ADC Signed saturation Enable */

/********************  Bit definition for ADC_OFR3 register  ********************/
#define ADC_OFR3_OFFSET3_Pos              (0)
#define ADC_OFR3_OFFSET3_Msk              (0x3FFFFFFUL << ADC_OFR3_OFFSET3_Pos) /*!< 0x03FFFFFF */
#define ADC_OFR3_OFFSET3                  ADC_OFR3_OFFSET3_Msk                 /*!< ADC data offset 3 for channel programmed into bits OFFSET3_CH[4:0] */
#define ADC_OFR3_OFFSET3_0                (0x0000001UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000001 */
#define ADC_OFR3_OFFSET3_1                (0x0000002UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000002 */
#define ADC_OFR3_OFFSET3_2                (0x0000004UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000004 */
#define ADC_OFR3_OFFSET3_3                (0x0000008UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000008 */
#define ADC_OFR3_OFFSET3_4                (0x0000010UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000010 */
#define ADC_OFR3_OFFSET3_5                (0x0000020UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000020 */
#define ADC_OFR3_OFFSET3_6                (0x0000040UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000040 */
#define ADC_OFR3_OFFSET3_7                (0x0000080UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000080 */
#define ADC_OFR3_OFFSET3_8                (0x0000100UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000100 */
#define ADC_OFR3_OFFSET3_9                (0x0000200UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000200 */
#define ADC_OFR3_OFFSET3_10               (0x0000400UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000400 */
#define ADC_OFR3_OFFSET3_11               (0x0000800UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00000800 */
#define ADC_OFR3_OFFSET3_12               (0x0001000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00001000 */
#define ADC_OFR3_OFFSET3_13               (0x0002000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00002000 */
#define ADC_OFR3_OFFSET3_14               (0x0004000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00004000 */
#define ADC_OFR3_OFFSET3_15               (0x0008000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00008000 */
#define ADC_OFR3_OFFSET3_16               (0x0010000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00010000 */
#define ADC_OFR3_OFFSET3_17               (0x0020000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00020000 */
#define ADC_OFR3_OFFSET3_18               (0x0040000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00040000 */
#define ADC_OFR3_OFFSET3_19               (0x0080000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00080000 */
#define ADC_OFR3_OFFSET3_20               (0x0100000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00100000 */
#define ADC_OFR3_OFFSET3_21               (0x0200000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00200000 */
#define ADC_OFR3_OFFSET3_22               (0x0400000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00400000 */
#define ADC_OFR3_OFFSET3_23               (0x0800000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x00800000 */
#define ADC_OFR3_OFFSET3_24               (0x1000000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x01000000 */
#define ADC_OFR3_OFFSET3_25               (0x2000000UL << ADC_OFR3_OFFSET3_Pos) /*!< 0x02000000 */

#define ADC_OFR3_OFFSET3_CH_Pos           (26U)
#define ADC_OFR3_OFFSET3_CH_Msk           (0x1FUL << ADC_OFR3_OFFSET3_CH_Pos)  /*!< 0x7C000000 */
#define ADC_OFR3_OFFSET3_CH               ADC_OFR3_OFFSET3_CH_Msk              /*!< ADC Channel selection for the data offset 3 */
#define ADC_OFR3_OFFSET3_CH_0             (0x01UL << ADC_OFR3_OFFSET3_CH_Pos)   /*!< 0x04000000 */
#define ADC_OFR3_OFFSET3_CH_1             (0x02UL << ADC_OFR3_OFFSET3_CH_Pos)   /*!< 0x08000000 */
#define ADC_OFR3_OFFSET3_CH_2             (0x04UL << ADC_OFR3_OFFSET3_CH_Pos)   /*!< 0x10000000 */
#define ADC_OFR3_OFFSET3_CH_3             (0x08UL << ADC_OFR3_OFFSET3_CH_Pos)   /*!< 0x20000000 */
#define ADC_OFR3_OFFSET3_CH_4             (0x10UL << ADC_OFR3_OFFSET3_CH_Pos)   /*!< 0x40000000 */

#define ADC_OFR3_SSATE_Pos                (31U)
#define ADC_OFR3_SSATE_Msk                (0x1UL << ADC_OFR3_SSATE_Pos)        /*!< 0x80000000 */
#define ADC_OFR3_SSATE                    ADC_OFR3_SSATE_Msk                   /*!< ADC Signed saturation Enable */

/********************  Bit definition for ADC_OFR4 register  ********************/
#define ADC_OFR4_OFFSET4_Pos              (0)
#define ADC_OFR4_OFFSET4_Msk              (0x3FFFFFFUL << ADC_OFR4_OFFSET4_Pos) /*!< 0x03FFFFFF */
#define ADC_OFR4_OFFSET4                  ADC_OFR4_OFFSET4_Msk                 /*!< ADC data offset 4 for channel programmed into bits OFFSET4_CH[4:0] */
#define ADC_OFR4_OFFSET4_0                (0x0000001UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000001 */
#define ADC_OFR4_OFFSET4_1                (0x0000002UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000002 */
#define ADC_OFR4_OFFSET4_2                (0x0000004UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000004 */
#define ADC_OFR4_OFFSET4_3                (0x0000008UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000008 */
#define ADC_OFR4_OFFSET4_4                (0x0000010UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000010 */
#define ADC_OFR4_OFFSET4_5                (0x0000020UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000020 */
#define ADC_OFR4_OFFSET4_6                (0x0000040UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000040 */
#define ADC_OFR4_OFFSET4_7                (0x0000080UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000080 */
#define ADC_OFR4_OFFSET4_8                (0x0000100UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000100 */
#define ADC_OFR4_OFFSET4_9                (0x0000200UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000200 */
#define ADC_OFR4_OFFSET4_10               (0x0000400UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000400 */
#define ADC_OFR4_OFFSET4_11               (0x0000800UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00000800 */
#define ADC_OFR4_OFFSET4_12               (0x0001000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00001000 */
#define ADC_OFR4_OFFSET4_13               (0x0002000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00002000 */
#define ADC_OFR4_OFFSET4_14               (0x0004000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00004000 */
#define ADC_OFR4_OFFSET4_15               (0x0008000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00008000 */
#define ADC_OFR4_OFFSET4_16               (0x0010000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00010000 */
#define ADC_OFR4_OFFSET4_17               (0x0020000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00020000 */
#define ADC_OFR4_OFFSET4_18               (0x0040000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00040000 */
#define ADC_OFR4_OFFSET4_19               (0x0080000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00080000 */
#define ADC_OFR4_OFFSET4_20               (0x0100000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00100000 */
#define ADC_OFR4_OFFSET4_21               (0x0200000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00200000 */
#define ADC_OFR4_OFFSET4_22               (0x0400000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00400000 */
#define ADC_OFR4_OFFSET4_23               (0x0800000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x00800000 */
#define ADC_OFR4_OFFSET4_24               (0x1000000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x01000000 */
#define ADC_OFR4_OFFSET4_25               (0x2000000UL << ADC_OFR4_OFFSET4_Pos) /*!< 0x02000000 */

#define ADC_OFR4_OFFSET4_CH_Pos           (26U)
#define ADC_OFR4_OFFSET4_CH_Msk           (0x1FUL << ADC_OFR4_OFFSET4_CH_Pos)  /*!< 0x7C000000 */
#define ADC_OFR4_OFFSET4_CH               ADC_OFR4_OFFSET4_CH_Msk              /*!< ADC Channel selection for the data offset 4 */
#define ADC_OFR4_OFFSET4_CH_0             (0x01UL << ADC_OFR4_OFFSET4_CH_Pos)   /*!< 0x04000000 */
#define ADC_OFR4_OFFSET4_CH_1             (0x02UL << ADC_OFR4_OFFSET4_CH_Pos)   /*!< 0x08000000 */
#define ADC_OFR4_OFFSET4_CH_2             (0x04UL << ADC_OFR4_OFFSET4_CH_Pos)   /*!< 0x10000000 */
#define ADC_OFR4_OFFSET4_CH_3             (0x08UL << ADC_OFR4_OFFSET4_CH_Pos)   /*!< 0x20000000 */
#define ADC_OFR4_OFFSET4_CH_4             (0x10UL << ADC_OFR4_OFFSET4_CH_Pos)   /*!< 0x40000000 */

#define ADC_OFR4_SSATE_Pos                (31U)
#define ADC_OFR4_SSATE_Msk                (0x1UL << ADC_OFR4_SSATE_Pos)        /*!< 0x80000000 */
#define ADC_OFR4_SSATE                    ADC_OFR4_SSATE_Msk                   /*!< ADC Signed saturation Enable */

/********************  Bit definition for ADC_JDR1 register  ********************/
#define ADC_JDR1_JDATA_Pos                (0)
#define ADC_JDR1_JDATA_Msk                (0xFFFFFFFFUL << ADC_JDR1_JDATA_Pos) /*!< 0xFFFFFFFF */
#define ADC_JDR1_JDATA                    ADC_JDR1_JDATA_Msk                   /*!< ADC Injected DATA */
#define ADC_JDR1_JDATA_0                  (0x00000001UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000001 */
#define ADC_JDR1_JDATA_1                  (0x00000002UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000002 */
#define ADC_JDR1_JDATA_2                  (0x00000004UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000004 */
#define ADC_JDR1_JDATA_3                  (0x00000008UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000008 */
#define ADC_JDR1_JDATA_4                  (0x00000010UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000010 */
#define ADC_JDR1_JDATA_5                  (0x00000020UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000020 */
#define ADC_JDR1_JDATA_6                  (0x00000040UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000040 */
#define ADC_JDR1_JDATA_7                  (0x00000080UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000080 */
#define ADC_JDR1_JDATA_8                  (0x00000100UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000100 */
#define ADC_JDR1_JDATA_9                  (0x00000200UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000200 */
#define ADC_JDR1_JDATA_10                 (0x00000400UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000400 */
#define ADC_JDR1_JDATA_11                 (0x00000800UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00000800 */
#define ADC_JDR1_JDATA_12                 (0x00001000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00001000 */
#define ADC_JDR1_JDATA_13                 (0x00002000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00002000 */
#define ADC_JDR1_JDATA_14                 (0x00004000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00004000 */
#define ADC_JDR1_JDATA_15                 (0x00008000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00008000 */
#define ADC_JDR1_JDATA_16                 (0x00010000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00010000 */
#define ADC_JDR1_JDATA_17                 (0x00020000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00020000 */
#define ADC_JDR1_JDATA_18                 (0x00040000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00040000 */
#define ADC_JDR1_JDATA_19                 (0x00080000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00080000 */
#define ADC_JDR1_JDATA_20                 (0x00100000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00100000 */
#define ADC_JDR1_JDATA_21                 (0x00200000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00200000 */
#define ADC_JDR1_JDATA_22                 (0x00400000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00400000 */
#define ADC_JDR1_JDATA_23                 (0x00800000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x00800000 */
#define ADC_JDR1_JDATA_24                 (0x01000000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x01000000 */
#define ADC_JDR1_JDATA_25                 (0x02000000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x02000000 */
#define ADC_JDR1_JDATA_26                 (0x04000000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x04000000 */
#define ADC_JDR1_JDATA_27                 (0x08000000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x08000000 */
#define ADC_JDR1_JDATA_28                 (0x10000000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x10000000 */
#define ADC_JDR1_JDATA_29                 (0x20000000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x20000000 */
#define ADC_JDR1_JDATA_30                 (0x40000000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x40000000 */
#define ADC_JDR1_JDATA_31                 (0x80000000UL << ADC_JDR1_JDATA_Pos)  /*!< 0x80000000 */

/********************  Bit definition for ADC_JDR2 register  ********************/
#define ADC_JDR2_JDATA_Pos                (0)
#define ADC_JDR2_JDATA_Msk                (0xFFFFFFFFUL << ADC_JDR2_JDATA_Pos) /*!< 0xFFFFFFFF */
#define ADC_JDR2_JDATA                    ADC_JDR2_JDATA_Msk                   /*!< ADC Injected DATA */
#define ADC_JDR2_JDATA_0                  (0x00000001UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000001 */
#define ADC_JDR2_JDATA_1                  (0x00000002UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000002 */
#define ADC_JDR2_JDATA_2                  (0x00000004UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000004 */
#define ADC_JDR2_JDATA_3                  (0x00000008UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000008 */
#define ADC_JDR2_JDATA_4                  (0x00000010UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000010 */
#define ADC_JDR2_JDATA_5                  (0x00000020UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000020 */
#define ADC_JDR2_JDATA_6                  (0x00000040UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000040 */
#define ADC_JDR2_JDATA_7                  (0x00000080UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000080 */
#define ADC_JDR2_JDATA_8                  (0x00000100UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000100 */
#define ADC_JDR2_JDATA_9                  (0x00000200UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000200 */
#define ADC_JDR2_JDATA_10                 (0x00000400UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000400 */
#define ADC_JDR2_JDATA_11                 (0x00000800UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00000800 */
#define ADC_JDR2_JDATA_12                 (0x00001000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00001000 */
#define ADC_JDR2_JDATA_13                 (0x00002000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00002000 */
#define ADC_JDR2_JDATA_14                 (0x00004000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00004000 */
#define ADC_JDR2_JDATA_15                 (0x00008000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00008000 */
#define ADC_JDR2_JDATA_16                 (0x00010000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00010000 */
#define ADC_JDR2_JDATA_17                 (0x00020000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00020000 */
#define ADC_JDR2_JDATA_18                 (0x00040000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00040000 */
#define ADC_JDR2_JDATA_19                 (0x00080000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00080000 */
#define ADC_JDR2_JDATA_20                 (0x00100000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00100000 */
#define ADC_JDR2_JDATA_21                 (0x00200000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00200000 */
#define ADC_JDR2_JDATA_22                 (0x00400000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00400000 */
#define ADC_JDR2_JDATA_23                 (0x00800000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x00800000 */
#define ADC_JDR2_JDATA_24                 (0x01000000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x01000000 */
#define ADC_JDR2_JDATA_25                 (0x02000000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x02000000 */
#define ADC_JDR2_JDATA_26                 (0x04000000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x04000000 */
#define ADC_JDR2_JDATA_27                 (0x08000000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x08000000 */
#define ADC_JDR2_JDATA_28                 (0x10000000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x10000000 */
#define ADC_JDR2_JDATA_29                 (0x20000000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x20000000 */
#define ADC_JDR2_JDATA_30                 (0x40000000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x40000000 */
#define ADC_JDR2_JDATA_31                 (0x80000000UL << ADC_JDR2_JDATA_Pos)  /*!< 0x80000000 */

/********************  Bit definition for ADC_JDR3 register  ********************/
#define ADC_JDR3_JDATA_Pos                (0)
#define ADC_JDR3_JDATA_Msk                (0xFFFFFFFFUL << ADC_JDR3_JDATA_Pos) /*!< 0xFFFFFFFF */
#define ADC_JDR3_JDATA                    ADC_JDR3_JDATA_Msk                   /*!< ADC Injected DATA */
#define ADC_JDR3_JDATA_0                  (0x00000001UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000001 */
#define ADC_JDR3_JDATA_1                  (0x00000002UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000002 */
#define ADC_JDR3_JDATA_2                  (0x00000004UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000004 */
#define ADC_JDR3_JDATA_3                  (0x00000008UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000008 */
#define ADC_JDR3_JDATA_4                  (0x00000010UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000010 */
#define ADC_JDR3_JDATA_5                  (0x00000020UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000020 */
#define ADC_JDR3_JDATA_6                  (0x00000040UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000040 */
#define ADC_JDR3_JDATA_7                  (0x00000080UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000080 */
#define ADC_JDR3_JDATA_8                  (0x00000100UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000100 */
#define ADC_JDR3_JDATA_9                  (0x00000200UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000200 */
#define ADC_JDR3_JDATA_10                 (0x00000400UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000400 */
#define ADC_JDR3_JDATA_11                 (0x00000800UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00000800 */
#define ADC_JDR3_JDATA_12                 (0x00001000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00001000 */
#define ADC_JDR3_JDATA_13                 (0x00002000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00002000 */
#define ADC_JDR3_JDATA_14                 (0x00004000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00004000 */
#define ADC_JDR3_JDATA_15                 (0x00008000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00008000 */
#define ADC_JDR3_JDATA_16                 (0x00010000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00010000 */
#define ADC_JDR3_JDATA_17                 (0x00020000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00020000 */
#define ADC_JDR3_JDATA_18                 (0x00040000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00040000 */
#define ADC_JDR3_JDATA_19                 (0x00080000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00080000 */
#define ADC_JDR3_JDATA_20                 (0x00100000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00100000 */
#define ADC_JDR3_JDATA_21                 (0x00200000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00200000 */
#define ADC_JDR3_JDATA_22                 (0x00400000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00400000 */
#define ADC_JDR3_JDATA_23                 (0x00800000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x00800000 */
#define ADC_JDR3_JDATA_24                 (0x01000000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x01000000 */
#define ADC_JDR3_JDATA_25                 (0x02000000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x02000000 */
#define ADC_JDR3_JDATA_26                 (0x04000000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x04000000 */
#define ADC_JDR3_JDATA_27                 (0x08000000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x08000000 */
#define ADC_JDR3_JDATA_28                 (0x10000000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x10000000 */
#define ADC_JDR3_JDATA_29                 (0x20000000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x20000000 */
#define ADC_JDR3_JDATA_30                 (0x40000000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x40000000 */
#define ADC_JDR3_JDATA_31                 (0x80000000UL << ADC_JDR3_JDATA_Pos)  /*!< 0x80000000 */

/********************  Bit definition for ADC_JDR4 register  ********************/
#define ADC_JDR4_JDATA_Pos                (0)
#define ADC_JDR4_JDATA_Msk                (0xFFFFFFFFUL << ADC_JDR4_JDATA_Pos) /*!< 0xFFFFFFFF */
#define ADC_JDR4_JDATA                    ADC_JDR4_JDATA_Msk                   /*!< ADC Injected DATA */
#define ADC_JDR4_JDATA_0                  (0x00000001UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000001 */
#define ADC_JDR4_JDATA_1                  (0x00000002UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000002 */
#define ADC_JDR4_JDATA_2                  (0x00000004UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000004 */
#define ADC_JDR4_JDATA_3                  (0x00000008UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000008 */
#define ADC_JDR4_JDATA_4                  (0x00000010UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000010 */
#define ADC_JDR4_JDATA_5                  (0x00000020UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000020 */
#define ADC_JDR4_JDATA_6                  (0x00000040UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000040 */
#define ADC_JDR4_JDATA_7                  (0x00000080UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000080 */
#define ADC_JDR4_JDATA_8                  (0x00000100UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000100 */
#define ADC_JDR4_JDATA_9                  (0x00000200UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000200 */
#define ADC_JDR4_JDATA_10                 (0x00000400UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000400 */
#define ADC_JDR4_JDATA_11                 (0x00000800UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00000800 */
#define ADC_JDR4_JDATA_12                 (0x00001000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00001000 */
#define ADC_JDR4_JDATA_13                 (0x00002000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00002000 */
#define ADC_JDR4_JDATA_14                 (0x00004000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00004000 */
#define ADC_JDR4_JDATA_15                 (0x00008000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00008000 */
#define ADC_JDR4_JDATA_16                 (0x00010000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00010000 */
#define ADC_JDR4_JDATA_17                 (0x00020000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00020000 */
#define ADC_JDR4_JDATA_18                 (0x00040000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00040000 */
#define ADC_JDR4_JDATA_19                 (0x00080000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00080000 */
#define ADC_JDR4_JDATA_20                 (0x00100000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00100000 */
#define ADC_JDR4_JDATA_21                 (0x00200000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00200000 */
#define ADC_JDR4_JDATA_22                 (0x00400000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00400000 */
#define ADC_JDR4_JDATA_23                 (0x00800000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x00800000 */
#define ADC_JDR4_JDATA_24                 (0x01000000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x01000000 */
#define ADC_JDR4_JDATA_25                 (0x02000000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x02000000 */
#define ADC_JDR4_JDATA_26                 (0x04000000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x04000000 */
#define ADC_JDR4_JDATA_27                 (0x08000000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x08000000 */
#define ADC_JDR4_JDATA_28                 (0x10000000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x10000000 */
#define ADC_JDR4_JDATA_29                 (0x20000000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x20000000 */
#define ADC_JDR4_JDATA_30                 (0x40000000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x40000000 */
#define ADC_JDR4_JDATA_31                 (0x80000000UL << ADC_JDR4_JDATA_Pos)  /*!< 0x80000000 */

/********************  Bit definition for ADC_AWD2CR register  ********************/
#define ADC_AWD2CR_AWD2CH_Pos             (0)
#define ADC_AWD2CR_AWD2CH_Msk             (0xFFFFFUL << ADC_AWD2CR_AWD2CH_Pos) /*!< 0x000FFFFF */
#define ADC_AWD2CR_AWD2CH                 ADC_AWD2CR_AWD2CH_Msk                /*!< ADC Analog watchdog 2 channel selection */
#define ADC_AWD2CR_AWD2CH_0               (0x00001UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000001 */
#define ADC_AWD2CR_AWD2CH_1               (0x00002UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000002 */
#define ADC_AWD2CR_AWD2CH_2               (0x00004UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000004 */
#define ADC_AWD2CR_AWD2CH_3               (0x00008UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000008 */
#define ADC_AWD2CR_AWD2CH_4               (0x00010UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000010 */
#define ADC_AWD2CR_AWD2CH_5               (0x00020UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000020 */
#define ADC_AWD2CR_AWD2CH_6               (0x00040UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000040 */
#define ADC_AWD2CR_AWD2CH_7               (0x00080UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000080 */
#define ADC_AWD2CR_AWD2CH_8               (0x00100UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000100 */
#define ADC_AWD2CR_AWD2CH_9               (0x00200UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000200 */
#define ADC_AWD2CR_AWD2CH_10              (0x00400UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000400 */
#define ADC_AWD2CR_AWD2CH_11              (0x00800UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00000800 */
#define ADC_AWD2CR_AWD2CH_12              (0x01000UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00001000 */
#define ADC_AWD2CR_AWD2CH_13              (0x02000UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00002000 */
#define ADC_AWD2CR_AWD2CH_14              (0x04000UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00004000 */
#define ADC_AWD2CR_AWD2CH_15              (0x08000UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00008000 */
#define ADC_AWD2CR_AWD2CH_16              (0x10000UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00010000 */
#define ADC_AWD2CR_AWD2CH_17              (0x20000UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00020000 */
#define ADC_AWD2CR_AWD2CH_18              (0x40000UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00040000 */
#define ADC_AWD2CR_AWD2CH_19              (0x80000UL << ADC_AWD2CR_AWD2CH_Pos)  /*!< 0x00080000 */

/********************  Bit definition for ADC_AWD3CR register  ********************/
#define ADC_AWD3CR_AWD3CH_Pos             (0)
#define ADC_AWD3CR_AWD3CH_Msk             (0xFFFFFUL << ADC_AWD3CR_AWD3CH_Pos) /*!< 0x000FFFFF */
#define ADC_AWD3CR_AWD3CH                 ADC_AWD3CR_AWD3CH_Msk                /*!< ADC Analog watchdog 2 channel selection */
#define ADC_AWD3CR_AWD3CH_0               (0x00001UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000001 */
#define ADC_AWD3CR_AWD3CH_1               (0x00002UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000002 */
#define ADC_AWD3CR_AWD3CH_2               (0x00004UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000004 */
#define ADC_AWD3CR_AWD3CH_3               (0x00008UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000008 */
#define ADC_AWD3CR_AWD3CH_4               (0x00010UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000010 */
#define ADC_AWD3CR_AWD3CH_5               (0x00020UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000020 */
#define ADC_AWD3CR_AWD3CH_6               (0x00040UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000040 */
#define ADC_AWD3CR_AWD3CH_7               (0x00080UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000080 */
#define ADC_AWD3CR_AWD3CH_8               (0x00100UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000100 */
#define ADC_AWD3CR_AWD3CH_9               (0x00200UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000200 */
#define ADC_AWD3CR_AWD3CH_10              (0x00400UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000400 */
#define ADC_AWD3CR_AWD3CH_11              (0x00800UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00000800 */
#define ADC_AWD3CR_AWD3CH_12              (0x01000UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00001000 */
#define ADC_AWD3CR_AWD3CH_13              (0x02000UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00002000 */
#define ADC_AWD3CR_AWD3CH_14              (0x04000UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00004000 */
#define ADC_AWD3CR_AWD3CH_15              (0x08000UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00008000 */
#define ADC_AWD3CR_AWD3CH_16              (0x10000UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00010000 */
#define ADC_AWD3CR_AWD3CH_17              (0x20000UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00020000 */
#define ADC_AWD3CR_AWD3CH_18              (0x40000UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00040000 */
#define ADC_AWD3CR_AWD3CH_19              (0x80000UL << ADC_AWD3CR_AWD3CH_Pos)  /*!< 0x00080000 */

/********************  Bit definition for ADC_DIFSEL register  ********************/
#define ADC_DIFSEL_DIFSEL_Pos             (0)
#define ADC_DIFSEL_DIFSEL_Msk             (0xFFFFFUL << ADC_DIFSEL_DIFSEL_Pos) /*!< 0x000FFFFF */
#define ADC_DIFSEL_DIFSEL                 ADC_DIFSEL_DIFSEL_Msk                /*!< ADC differential modes for channels 1 to 18 */
#define ADC_DIFSEL_DIFSEL_0               (0x00001UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000001 */
#define ADC_DIFSEL_DIFSEL_1               (0x00002UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000002 */
#define ADC_DIFSEL_DIFSEL_2               (0x00004UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000004 */
#define ADC_DIFSEL_DIFSEL_3               (0x00008UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000008 */
#define ADC_DIFSEL_DIFSEL_4               (0x00010UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000010 */
#define ADC_DIFSEL_DIFSEL_5               (0x00020UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000020 */
#define ADC_DIFSEL_DIFSEL_6               (0x00040UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000040 */
#define ADC_DIFSEL_DIFSEL_7               (0x00080UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000080 */
#define ADC_DIFSEL_DIFSEL_8               (0x00100UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000100 */
#define ADC_DIFSEL_DIFSEL_9               (0x00200UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000200 */
#define ADC_DIFSEL_DIFSEL_10              (0x00400UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000400 */
#define ADC_DIFSEL_DIFSEL_11              (0x00800UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00000800 */
#define ADC_DIFSEL_DIFSEL_12              (0x01000UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00001000 */
#define ADC_DIFSEL_DIFSEL_13              (0x02000UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00002000 */
#define ADC_DIFSEL_DIFSEL_14              (0x04000UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00004000 */
#define ADC_DIFSEL_DIFSEL_15              (0x08000UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00008000 */
#define ADC_DIFSEL_DIFSEL_16              (0x10000UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00010000 */
#define ADC_DIFSEL_DIFSEL_17              (0x20000UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00020000 */
#define ADC_DIFSEL_DIFSEL_18              (0x40000UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00040000 */
#define ADC_DIFSEL_DIFSEL_19              (0x80000UL << ADC_DIFSEL_DIFSEL_Pos)  /*!< 0x00080000 */

/********************  Bit definition for ADC_CALFACT register  ********************/
#define ADC_CALFACT_CALFACT_S_Pos         (0)
#define ADC_CALFACT_CALFACT_S_Msk         (0x7FFUL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x000007FF */
#define ADC_CALFACT_CALFACT_S             ADC_CALFACT_CALFACT_S_Msk            /*!< ADC calibration factors in single-ended mode */
#define ADC_CALFACT_CALFACT_S_0           (0x001UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000001 */
#define ADC_CALFACT_CALFACT_S_1           (0x002UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000002 */
#define ADC_CALFACT_CALFACT_S_2           (0x004UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000004 */
#define ADC_CALFACT_CALFACT_S_3           (0x008UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000008 */
#define ADC_CALFACT_CALFACT_S_4           (0x010UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000010 */
#define ADC_CALFACT_CALFACT_S_5           (0x020UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000020 */
#define ADC_CALFACT_CALFACT_S_6           (0x040UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000040 */
#define ADC_CALFACT_CALFACT_S_7           (0x080UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000080 */
#define ADC_CALFACT_CALFACT_S_8           (0x100UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000100 */
#define ADC_CALFACT_CALFACT_S_9           (0x200UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000200 */
#define ADC_CALFACT_CALFACT_S_10          (0x400UL << ADC_CALFACT_CALFACT_S_Pos) /*!< 0x00000400 */
#define ADC_CALFACT_CALFACT_D_Pos         (16U)
#define ADC_CALFACT_CALFACT_D_Msk         (0x7FFUL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x07FF0000 */
#define ADC_CALFACT_CALFACT_D             ADC_CALFACT_CALFACT_D_Msk            /*!< ADC calibration factors in differential mode */
#define ADC_CALFACT_CALFACT_D_0           (0x001UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x00010000 */
#define ADC_CALFACT_CALFACT_D_1           (0x002UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x00020000 */
#define ADC_CALFACT_CALFACT_D_2           (0x004UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x00040000 */
#define ADC_CALFACT_CALFACT_D_3           (0x008UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x00080000 */
#define ADC_CALFACT_CALFACT_D_4           (0x010UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x00100000 */
#define ADC_CALFACT_CALFACT_D_5           (0x020UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x00200000 */
#define ADC_CALFACT_CALFACT_D_6           (0x040UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x00400000 */
#define ADC_CALFACT_CALFACT_D_7           (0x080UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x00800000 */
#define ADC_CALFACT_CALFACT_D_8           (0x100UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x01000000 */
#define ADC_CALFACT_CALFACT_D_9           (0x200UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x02000000 */
#define ADC_CALFACT_CALFACT_D_10          (0x400UL << ADC_CALFACT_CALFACT_D_Pos) /*!< 0x04000000 */

/********************  Bit definition for ADC_CALFACT2 register  ********************/
#define ADC_CALFACT2_LINCALFACT_Pos       (0)
#define ADC_CALFACT2_LINCALFACT_Msk       (0x3FFFFFFFUL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x3FFFFFFF */
#define ADC_CALFACT2_LINCALFACT           ADC_CALFACT2_LINCALFACT_Msk          /*!< ADC Linearity calibration factors */
#define ADC_CALFACT2_LINCALFACT_0         (0x00000001UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000001 */
#define ADC_CALFACT2_LINCALFACT_1         (0x00000002UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000002 */
#define ADC_CALFACT2_LINCALFACT_2         (0x00000004UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000004 */
#define ADC_CALFACT2_LINCALFACT_3         (0x00000008UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000008 */
#define ADC_CALFACT2_LINCALFACT_4         (0x00000010UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000010 */
#define ADC_CALFACT2_LINCALFACT_5         (0x00000020UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000020 */
#define ADC_CALFACT2_LINCALFACT_6         (0x00000040UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000040 */
#define ADC_CALFACT2_LINCALFACT_7         (0x00000080UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000080 */
#define ADC_CALFACT2_LINCALFACT_8         (0x00000100UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000100 */
#define ADC_CALFACT2_LINCALFACT_9         (0x00000200UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000200 */
#define ADC_CALFACT2_LINCALFACT_10        (0x00000400UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000400 */
#define ADC_CALFACT2_LINCALFACT_11        (0x00000800UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00000800 */
#define ADC_CALFACT2_LINCALFACT_12        (0x00001000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00001000 */
#define ADC_CALFACT2_LINCALFACT_13        (0x00002000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00002000 */
#define ADC_CALFACT2_LINCALFACT_14        (0x00004000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00004000 */
#define ADC_CALFACT2_LINCALFACT_15        (0x00008000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00008000 */
#define ADC_CALFACT2_LINCALFACT_16        (0x00010000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00010000 */
#define ADC_CALFACT2_LINCALFACT_17        (0x00020000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00020000 */
#define ADC_CALFACT2_LINCALFACT_18        (0x00040000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00040000 */
#define ADC_CALFACT2_LINCALFACT_19        (0x00080000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00080000 */
#define ADC_CALFACT2_LINCALFACT_20        (0x00100000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00100000 */
#define ADC_CALFACT2_LINCALFACT_21        (0x00200000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00200000 */
#define ADC_CALFACT2_LINCALFACT_22        (0x00400000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00400000 */
#define ADC_CALFACT2_LINCALFACT_23        (0x00800000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x00800000 */
#define ADC_CALFACT2_LINCALFACT_24        (0x01000000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x01000000 */
#define ADC_CALFACT2_LINCALFACT_25        (0x02000000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x02000000 */
#define ADC_CALFACT2_LINCALFACT_26        (0x04000000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x04000000 */
#define ADC_CALFACT2_LINCALFACT_27        (0x08000000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x08000000 */
#define ADC_CALFACT2_LINCALFACT_28        (0x10000000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x10000000 */
#define ADC_CALFACT2_LINCALFACT_29        (0x20000000UL << ADC_CALFACT2_LINCALFACT_Pos) /*!< 0x20000000 */

/*************************  ADC Common registers  *****************************/
/********************  Bit definition for ADC_CSR register  ********************/
#define ADC_CSR_ADRDY_MST_Pos             (0)
#define ADC_CSR_ADRDY_MST_Msk             (0x1UL << ADC_CSR_ADRDY_MST_Pos)     /*!< 0x00000001 */
#define ADC_CSR_ADRDY_MST                 ADC_CSR_ADRDY_MST_Msk                /*!< Master ADC ready */
#define ADC_CSR_EOSMP_MST_Pos             (1U)
#define ADC_CSR_EOSMP_MST_Msk             (0x1UL << ADC_CSR_EOSMP_MST_Pos)     /*!< 0x00000002 */
#define ADC_CSR_EOSMP_MST                 ADC_CSR_EOSMP_MST_Msk                /*!< End of sampling phase flag of the master ADC */
#define ADC_CSR_EOC_MST_Pos               (2U)
#define ADC_CSR_EOC_MST_Msk               (0x1UL << ADC_CSR_EOC_MST_Pos)       /*!< 0x00000004 */
#define ADC_CSR_EOC_MST                   ADC_CSR_EOC_MST_Msk                  /*!< End of regular conversion of the master ADC */
#define ADC_CSR_EOS_MST_Pos               (3U)
#define ADC_CSR_EOS_MST_Msk               (0x1UL << ADC_CSR_EOS_MST_Pos)       /*!< 0x00000008 */
#define ADC_CSR_EOS_MST                   ADC_CSR_EOS_MST_Msk                  /*!< End of regular sequence flag of the master ADC */
#define ADC_CSR_OVR_MST_Pos               (4U)
#define ADC_CSR_OVR_MST_Msk               (0x1UL << ADC_CSR_OVR_MST_Pos)       /*!< 0x00000010 */
#define ADC_CSR_OVR_MST                   ADC_CSR_OVR_MST_Msk                  /*!< Overrun flag of the master ADC */
#define ADC_CSR_JEOC_MST_Pos              (5U)
#define ADC_CSR_JEOC_MST_Msk              (0x1UL << ADC_CSR_JEOC_MST_Pos)      /*!< 0x00000020 */
#define ADC_CSR_JEOC_MST                  ADC_CSR_JEOC_MST_Msk                 /*!< End of injected conversion of the master ADC */
#define ADC_CSR_JEOS_MST_Pos              (6U)
#define ADC_CSR_JEOS_MST_Msk              (0x1UL << ADC_CSR_JEOS_MST_Pos)      /*!< 0x00000040 */
#define ADC_CSR_JEOS_MST                  ADC_CSR_JEOS_MST_Msk                 /*!< End of injected sequence flag of the master ADC */
#define ADC_CSR_AWD1_MST_Pos              (7U)
#define ADC_CSR_AWD1_MST_Msk              (0x1UL << ADC_CSR_AWD1_MST_Pos)      /*!< 0x00000080 */
#define ADC_CSR_AWD1_MST                  ADC_CSR_AWD1_MST_Msk                 /*!< Analog watchdog 1 flag of the master ADC */
#define ADC_CSR_AWD2_MST_Pos              (8U)
#define ADC_CSR_AWD2_MST_Msk              (0x1UL << ADC_CSR_AWD2_MST_Pos)      /*!< 0x00000100 */
#define ADC_CSR_AWD2_MST                  ADC_CSR_AWD2_MST_Msk                 /*!< Analog watchdog 2 flag of the master ADC */
#define ADC_CSR_AWD3_MST_Pos              (9U)
#define ADC_CSR_AWD3_MST_Msk              (0x1UL << ADC_CSR_AWD3_MST_Pos)      /*!< 0x00000200 */
#define ADC_CSR_AWD3_MST                  ADC_CSR_AWD3_MST_Msk                 /*!< Analog watchdog 3 flag of the master ADC */
#define ADC_CSR_JQOVF_MST_Pos             (10U)
#define ADC_CSR_JQOVF_MST_Msk             (0x1UL << ADC_CSR_JQOVF_MST_Pos)     /*!< 0x00000400 */
#define ADC_CSR_JQOVF_MST                 ADC_CSR_JQOVF_MST_Msk                /*!< Injected context queue overflow flag of the master ADC */
#define ADC_CSR_ADRDY_SLV_Pos             (16U)
#define ADC_CSR_ADRDY_SLV_Msk             (0x1UL << ADC_CSR_ADRDY_SLV_Pos)     /*!< 0x00010000 */
#define ADC_CSR_ADRDY_SLV                 ADC_CSR_ADRDY_SLV_Msk                /*!< Slave ADC ready */
#define ADC_CSR_EOSMP_SLV_Pos             (17U)
#define ADC_CSR_EOSMP_SLV_Msk             (0x1UL << ADC_CSR_EOSMP_SLV_Pos)     /*!< 0x00020000 */
#define ADC_CSR_EOSMP_SLV                 ADC_CSR_EOSMP_SLV_Msk                /*!< End of sampling phase flag of the slave ADC */
#define ADC_CSR_EOC_SLV_Pos               (18U)
#define ADC_CSR_EOC_SLV_Msk               (0x1UL << ADC_CSR_EOC_SLV_Pos)       /*!< 0x00040000 */
#define ADC_CSR_EOC_SLV                   ADC_CSR_EOC_SLV_Msk                  /*!< End of regular conversion of the slave ADC */
#define ADC_CSR_EOS_SLV_Pos               (19U)
#define ADC_CSR_EOS_SLV_Msk               (0x1UL << ADC_CSR_EOS_SLV_Pos)       /*!< 0x00080000 */
#define ADC_CSR_EOS_SLV                   ADC_CSR_EOS_SLV_Msk                  /*!< End of regular sequence flag of the slave ADC */
#define ADC_CSR_OVR_SLV_Pos               (20U)
#define ADC_CSR_OVR_SLV_Msk               (0x1UL << ADC_CSR_OVR_SLV_Pos)       /*!< 0x00100000 */
#define ADC_CSR_OVR_SLV                   ADC_CSR_OVR_SLV_Msk                  /*!< Overrun flag of the slave ADC */
#define ADC_CSR_JEOC_SLV_Pos              (21U)
#define ADC_CSR_JEOC_SLV_Msk              (0x1UL << ADC_CSR_JEOC_SLV_Pos)      /*!< 0x00200000 */
#define ADC_CSR_JEOC_SLV                  ADC_CSR_JEOC_SLV_Msk                 /*!< End of injected conversion of the slave ADC */
#define ADC_CSR_JEOS_SLV_Pos              (22U)
#define ADC_CSR_JEOS_SLV_Msk              (0x1UL << ADC_CSR_JEOS_SLV_Pos)      /*!< 0x00400000 */
#define ADC_CSR_JEOS_SLV                  ADC_CSR_JEOS_SLV_Msk                 /*!< End of injected sequence flag of the slave ADC */
#define ADC_CSR_AWD1_SLV_Pos              (23U)
#define ADC_CSR_AWD1_SLV_Msk              (0x1UL << ADC_CSR_AWD1_SLV_Pos)      /*!< 0x00800000 */
#define ADC_CSR_AWD1_SLV                  ADC_CSR_AWD1_SLV_Msk                 /*!< Analog watchdog 1 flag of the slave ADC */
#define ADC_CSR_AWD2_SLV_Pos              (24U)
#define ADC_CSR_AWD2_SLV_Msk              (0x1UL << ADC_CSR_AWD2_SLV_Pos)      /*!< 0x01000000 */
#define ADC_CSR_AWD2_SLV                  ADC_CSR_AWD2_SLV_Msk                 /*!< Analog watchdog 2 flag of the slave ADC */
#define ADC_CSR_AWD3_SLV_Pos              (25U)
#define ADC_CSR_AWD3_SLV_Msk              (0x1UL << ADC_CSR_AWD3_SLV_Pos)      /*!< 0x02000000 */
#define ADC_CSR_AWD3_SLV                  ADC_CSR_AWD3_SLV_Msk                 /*!< Analog watchdog 3 flag of the slave ADC */
#define ADC_CSR_JQOVF_SLV_Pos             (26U)
#define ADC_CSR_JQOVF_SLV_Msk             (0x1UL << ADC_CSR_JQOVF_SLV_Pos)     /*!< 0x04000000 */
#define ADC_CSR_JQOVF_SLV                 ADC_CSR_JQOVF_SLV_Msk                /*!< Injected context queue overflow flag of the slave ADC */

/********************  Bit definition for ADC_CCR register  ********************/
#define ADC_CCR_DUAL_Pos                  (0)
#define ADC_CCR_DUAL_Msk                  (0x1FUL << ADC_CCR_DUAL_Pos)         /*!< 0x0000001F */
#define ADC_CCR_DUAL                      ADC_CCR_DUAL_Msk                     /*!< Dual ADC mode selection */
#define ADC_CCR_DUAL_0                    (0x01UL << ADC_CCR_DUAL_Pos)          /*!< 0x00000001 */
#define ADC_CCR_DUAL_1                    (0x02UL << ADC_CCR_DUAL_Pos)          /*!< 0x00000002 */
#define ADC_CCR_DUAL_2                    (0x04UL << ADC_CCR_DUAL_Pos)          /*!< 0x00000004 */
#define ADC_CCR_DUAL_3                    (0x08UL << ADC_CCR_DUAL_Pos)          /*!< 0x00000008 */
#define ADC_CCR_DUAL_4                    (0x10UL << ADC_CCR_DUAL_Pos)          /*!< 0x00000010 */

#define ADC_CCR_DELAY_Pos                 (8U)
#define ADC_CCR_DELAY_Msk                 (0xFUL << ADC_CCR_DELAY_Pos)         /*!< 0x00000F00 */
#define ADC_CCR_DELAY                     ADC_CCR_DELAY_Msk                    /*!< Delay between 2 sampling phases */
#define ADC_CCR_DELAY_0                   (0x1UL << ADC_CCR_DELAY_Pos)          /*!< 0x00000100 */
#define ADC_CCR_DELAY_1                   (0x2UL << ADC_CCR_DELAY_Pos)          /*!< 0x00000200 */
#define ADC_CCR_DELAY_2                   (0x4UL << ADC_CCR_DELAY_Pos)          /*!< 0x00000400 */
#define ADC_CCR_DELAY_3                   (0x8UL << ADC_CCR_DELAY_Pos)          /*!< 0x00000800 */


#define ADC_CCR_DAMDF_Pos                 (14U)
#define ADC_CCR_DAMDF_Msk                 (0x3UL << ADC_CCR_DAMDF_Pos)         /*!< 0x0000C000 */
#define ADC_CCR_DAMDF                     ADC_CCR_DAMDF_Msk                    /*!< Dual ADC mode Data format */
#define ADC_CCR_DAMDF_0                   (0x1UL << ADC_CCR_DAMDF_Pos)          /*!< 0x00004000 */
#define ADC_CCR_DAMDF_1                   (0x2UL << ADC_CCR_DAMDF_Pos)          /*!< 0x00008000 */

#define ADC_CCR_CKMODE_Pos                (16U)
#define ADC_CCR_CKMODE_Msk                (0x3UL << ADC_CCR_CKMODE_Pos)        /*!< 0x00030000 */
#define ADC_CCR_CKMODE                    ADC_CCR_CKMODE_Msk                   /*!< ADC clock mode */
#define ADC_CCR_CKMODE_0                  (0x1UL << ADC_CCR_CKMODE_Pos)         /*!< 0x00010000 */
#define ADC_CCR_CKMODE_1                  (0x2UL << ADC_CCR_CKMODE_Pos)         /*!< 0x00020000 */

#define ADC_CCR_PRESC_Pos                 (18U)
#define ADC_CCR_PRESC_Msk                 (0xFUL << ADC_CCR_PRESC_Pos)         /*!< 0x003C0000 */
#define ADC_CCR_PRESC                     ADC_CCR_PRESC_Msk                    /*!< ADC prescaler */
#define ADC_CCR_PRESC_0                   (0x1UL << ADC_CCR_PRESC_Pos)          /*!< 0x00040000 */
#define ADC_CCR_PRESC_1                   (0x2UL << ADC_CCR_PRESC_Pos)          /*!< 0x00080000 */
#define ADC_CCR_PRESC_2                   (0x4UL << ADC_CCR_PRESC_Pos)          /*!< 0x00100000 */
#define ADC_CCR_PRESC_3                   (0x8UL << ADC_CCR_PRESC_Pos)          /*!< 0x00200000 */

#define ADC_CCR_VREFEN_Pos                (22U)
#define ADC_CCR_VREFEN_Msk                (0x1UL << ADC_CCR_VREFEN_Pos)        /*!< 0x00400000 */
#define ADC_CCR_VREFEN                    ADC_CCR_VREFEN_Msk                   /*!< VREFINT enable */
#define ADC_CCR_TSEN_Pos                  (23U)
#define ADC_CCR_TSEN_Msk                  (0x1UL << ADC_CCR_TSEN_Pos)          /*!< 0x00800000 */
#define ADC_CCR_TSEN                      ADC_CCR_TSEN_Msk                     /*!< Temperature sensor enable */
#define ADC_CCR_VBATEN_Pos                (24U)
#define ADC_CCR_VBATEN_Msk                (0x1UL << ADC_CCR_VBATEN_Pos)        /*!< 0x01000000 */
#define ADC_CCR_VBATEN                    ADC_CCR_VBATEN_Msk                   /*!< VBAT enable */

/********************  Bit definition for ADC_CDR register  *******************/
#define ADC_CDR_RDATA_MST_Pos             (0)
#define ADC_CDR_RDATA_MST_Msk             (0xFFFFUL << ADC_CDR_RDATA_MST_Pos)  /*!< 0x0000FFFF */
#define ADC_CDR_RDATA_MST                 ADC_CDR_RDATA_MST_Msk                /*!< ADC multimode master group regular conversion data */

#define ADC_CDR_RDATA_SLV_Pos             (16U)
#define ADC_CDR_RDATA_SLV_Msk             (0xFFFFUL << ADC_CDR_RDATA_SLV_Pos)  /*!< 0xFFFF0000 */
#define ADC_CDR_RDATA_SLV                 ADC_CDR_RDATA_SLV_Msk                /*!< ADC multimode slave group regular conversion data */

/********************  Bit definition for ADC_CDR2 register  ******************/
#define ADC_CDR2_RDATA_ALT_Pos            (0)
#define ADC_CDR2_RDATA_ALT_Msk            (0xFFFFFFFFUL << ADC_CDR2_RDATA_ALT_Pos) /*!< 0xFFFFFFFF */
#define ADC_CDR2_RDATA_ALT                ADC_CDR2_RDATA_ALT_Msk               /*!< Regular data of the master/slave alternated ADCs */

 