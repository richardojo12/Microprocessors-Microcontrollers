//__IO_struct_translator.h wmh 2020-11-26 : convert structs from stm32h745xx.h file (or any other processor) to register offsets 
// see example of use in STM32H745_ADC.h

	//cleanup previous use
	#ifdef STRUCT_DEFS
		.purgem __IO		//purging a macro that isn't defined only causes a warning
		.purgem SKIP
		.purgem SKIPNUM
//		#undef type
	#endif

	#define STRUCT_DEFS
	
	.macro __IO	size label
		.set type\label , offset	//if we use '.equiv' then we can't recreate this in another file say, for ADC1 whereas with .set or .equ we can.  
		.set offset,(offset+\size)
	.endm

	.macro SKIP size  label
		.set type\label , offset
		.set offset,(offset+(\size))
	.endm

	.macro SKIPNUM size label number
		.set type\label , offset
		.set offset,(offset+((\size*\number)))
	.endm
