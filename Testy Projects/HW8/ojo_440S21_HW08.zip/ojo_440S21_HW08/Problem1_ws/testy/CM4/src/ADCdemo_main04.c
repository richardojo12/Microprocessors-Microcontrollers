//ADCdemo_main04.c wmh 2020-12-11 : adds TIM8 TRGO trigger of ADC
//ADCdemo_main02.c wmh 2020-12-02 : adds ADC3 interrupt 
// note: the application, ADC, and DAC drivers are located in FLASH memory sectors 0,1,2
//   (0x08000000, 0x08008000,0x08010000) so they may be programmed separately. 
// boundaries (32 kbyte) so a 
//ADC-DACdemo_main01_with_externals.c wmh 2017-12-13 : merging the two demos
//ADCdemo_main01_with_externals.c wmh 2017-12-12 :
//ADCdemo_main01.c wmh 2017-12-10 : working -- shell to start/test ADC demo 

// Includes ------------------------------------------------------------------
#include <stdint.h>	//for uint8_t, uint16_t, uint32_t  etc. 
//#include "myIncludes03.h"	//hardware register addresses

//!!wmh 2020-11-22 : changes
//void initSYSCLK(void);	removed
//void initSysTick64MHz();	called in Reset Handler
extern uint64_t SysTick_absmsecs;	//in CM7\startup\SysTick64MHz.S + CM4\src\ADC3interrupt_EOC.S -- !!wmhTODO explain!
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOEBIT1();	//initialize port bit controlling yellow LED
	



void software_delay(uint32_t count);

void test_container();	//do nothing test of container macro
//in libADC3_PC2.a
void initPC0(); 		//configure PC0 as an analog input 
void PC2_init(); 		//configure PC2 as an analog input 
void ADC3_init();		//enable, reset and calibrate ADC3 (does not configure or enable ADC3)
void ADC3_config_01(); 	//configure ADC3 for continuous conversion of PC0 with overrun with extended sampling time
void ADC3_config_02(); 	//configure ADC3 for continuous conversion of Vrefint to DR with overrun 
void ADC3_config_03(); 	//configure ADC3 for continuous conversion of Vbat with overrun
void ADC3_config_04(); 	//configure ADC3 for continuous conversion of PC0 with overrun using default sampling time
void ADC3_config_05(); 	//configure ADC3 for continuous conversion of PC2 with overrun using default sampling time
void ADC3_config_06(); 	//configure ADC3 for continuous conversion of PC2 with overrun using extended sampling time
uint32_t ADC3_start();	

//. in ADC3interrupt_EOC.S
extern uint16_t ADC3_DMAbuf0[512];	//
extern uint16_t ADC3_DMAbuf1[512];
extern uint32_t ADC3_IRQcount;
extern uint32_t ADC3_deltacount;	//Is always wrong (=0) in CM4 context when CM4 debug is paused, _unless_ CM7 is paused first.
									//Why? Theory: the debugger is taking more than one msec to get around to reading this location after
									//stopping CM4 and in that time CM7 SysTick_Handler has run twice so old and new ADC3_IRQcount values are the same
									//hence ADC_deltacount = ADC3_IRQcount.new - ADC3_IRQcount.old = 0.  The problem would not exist if ADC_IRQhandler and
									//Systick_HAndler were in the same context, or if old and new ADC3_IRQcount were both updated by ADC_IRQHandler.

void ADC3_IRQinit(void);	//initialize and enable ADC3 EOC interrupt
void ADC3_DMA1_config();	//in ADC3_DMA1_0x.S -- configures ADC3 and DMA1 stream 0 for DMA with circular buffering
void DMA1_IRQinit();		//in DMA1_interrupt_enable.S - 


void TIM8_TRGO_init();			//in stm32H745xx_TIM8_TRGO_01.S  -- TIM8 initialized for 50KHz TRGO output
void ADC3_reconfig_TIM8_TRGO();	//in in ADC3_DMA1_0x.S -- configures ADC3 to be triggered by TIM8

/////// main program
int main(void) //starts ADC and DAC, then sits back. 
{

	
	initGPIOEBIT1();	//initialize port bit controlling yellow LED
	PC2_init();			//prep PC2 for input to ADC3
	ADC3_init();
//	initPC0();
//	ADC3_config_01();	//measure PC0
//	ADC3_config_02();	//measure Vrefint
//	ADC3_config_03();	//measure Vbat (=VDD)
// 	ADC3_config_04();	//measure PC0 without extended sampling time
	ADC3_config_06();	//measure PC2 with sampling time
//	ADC3_IRQinit();		//configure and enable ADC EOC interrupt
	ADC3_DMA1_config();	//configure ADC3 and DMA1 stream 0 for DMA with circular buffering
	DMA1_IRQinit();		//

	TIM8_TRGO_init();	//start the timer to trigger ADC3 conversions
	ADC3_reconfig_TIM8_TRGO();	//
//	TIM8_TRGO_init();	//start the timer to trigger ADC3 conversions


	ADC3_start();		//start conversion	
//	There are a number of places (RM0399 pg1760, 1761, ..._) where the somewhat cryptic warning below is given:
//		"Note: The clock of the slave timer or ADC must be enabled prior to receive events from the
//		master timer, and must not be changed on-the-fly while triggers are received from the
//		master timer."
//  so we turn ADC3 on before 
//	TIM8_TRGO_init();	//start the timer to trigger ADC3 conversions


	ADC3_deltacount=1;
//	while(1) ADC3_deltacount++;	//to get an idea of how long before TEIE fires !!wmh now in 'blinky' below

	while(1) {	//forever
		while(SysTick_msecs < 500)ADC3_deltacount++; 	//trap here for 1/2 second
		toggleGPIOEBIT1();				//then toggle the yellow LED
		while(SysTick_msecs >= 500)ADC3_deltacount++; 	// then trap here for 1/2 second
		toggleGPIOEBIT1();				//then toggle the yellow LED again
	}									// and go up to wait some more

}
/*
void software_delay(uint32_t count)	//time-waster to slow down blink-rate
{
	while(count--){};
	return;
}
*/
