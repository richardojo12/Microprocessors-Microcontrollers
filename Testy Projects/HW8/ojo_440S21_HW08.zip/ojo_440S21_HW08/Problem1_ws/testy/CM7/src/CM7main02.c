//CM7main02.c for scratch build wmh 2020-11-02 : do-nothing main for testing TIM1 functions -- changes TIM/GPIO init sequence
//  "" is brought here to begin testing ADC/DMA 'oscilloscope' functions.  Original development is found in 
//	   CM7main02.c from F:\_umd\2020-09-01\ENEE440_F20\_work\1029_HW07_TIM1_PWM\04HW07prob1_07_scratch_build_ws\scratchy\CM7\src

//CM7main01.c for scratch build wmh 2020-10-01 : do-nothing main for testing TIM1 functions
// - test 1: TIM1_UIF_wait() waits for UIF flag to go on and blinks green LED
// - test 2: TIM1_CC2IF_wait() waits for CC2IF flag to go on and blinks green LED

	#include <stdint.h>

//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""

void initGPIOxBITn();				//in GreenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""

//void NVIC_TIM1_UP_IRQn_setPriority(uint8_t priority); //old version using a macro
void NVIC_setPriority(uint32_t IRQn, uint8_t priority);
#include <stm32h745xx.h>	//gets interrupt numbers
void NVIC_setPriority(uint32_t IRQn, uint8_t priority);
void NVIC_enableIRQn(uint32_t IRQn);
void NVIC_disableIRQn(uint32_t IRQn);
void DBGMCU_FREEZE_TIM1();
void DBGMCU_UNFREEZE_TIM1();
void connect_TIM1_CH2_to_PE11();
void TIM1_CH2_PWM_init();	//TIM1 initialized for 5KHz, 50/50 PWM output on CH2"

uint32_t *pTIM1_SR = (uint32_t *)0x40010010;

void TIM1_UIF_wait()
{
	while( ((*pTIM1_SR)& (0x1<<0)) == 0 );	//block here until UIF goes on 
	*pTIM1_SR = 0;							//  then clear all of the flags and return
	return;
}

void TIM1_CC2IF_wait()
{
	while( ((*pTIM1_SR)& (0x1<<2)) == 0 );	//block here until CC2IF goes on 
	*pTIM1_SR = 0;							//  then clear all of the flags and return
	return;
}

void TIM1_CC2IF_UIF_wait()
{
	while( ((*pTIM1_SR)& (0x1<<2)) == 0 );	//block here until CC2IF goes on
	*pTIM1_SR = 0;							//  then clear all of the flags
	while( ((*pTIM1_SR)& (0x1<<0)) == 0 );	//and continue to block here until UIF goes on
	*pTIM1_SR = 0;							//  then clear all of the flags and return
	return;
}

uint32_t TIM1_UIF_IRQ_count = 0;	//for TIM1 interrupt test -- interrupt increments this value, main() uses it to blink green LED


int main() 
{
	int i;
	
//	initSysTick64MHz();	//move this to CM7 startup after testing -- done
	initGPIOxBITn();	//green LED
	DBGMCU_FREEZE_TIM1();
	
	NVIC_setPriority(TIM1_UP_IRQn, 0x40);
	NVIC_enableIRQn(TIM1_UP_IRQn);

//	connect_TIM1_CH2_to_PE11();
	TIM1_CH2_PWM_init();
	connect_TIM1_CH2_to_PE11();

	DBGMCU_FREEZE_TIM1();

	// test of TIM1 interrupt operation
	while(1){ //blink Green LED
		while(TIM1_UIF_IRQ_count<500) setGPIOxBITn();
		TIM1_UIF_IRQ_count=0;
		while(TIM1_UIF_IRQ_count<500) resetGPIOxBITn();
		TIM1_UIF_IRQ_count=0;
	}
	
	//Initial test for TIM1 operation polled flags in TIM1_SR -- works
	while(1) {
		for(i=0;i<500;i++)  TIM1_CC2IF_UIF_wait();	//see
		setGPIOxBITn();
		for(i=0;i<500;i++)  TIM1_CC2IF_UIF_wait();
		resetGPIOxBITn();
	}
	
	//original Blinky based on SysTick
	while(1){ //blink Green LED
		if(SysTick_msecs<500) setGPIOxBITn();
		else resetGPIOxBITn();
	}

	return 0;	//eliminates a warning
}
