Problem 1a
----------------
Image is named: 440_HW08_Problem1a_buffer_image
Values in the image are in decimal
65535 = 0xffff 

Problem 1b
----------------
Function to modify TIM1 is in file: device_greenLED.S1b
Function is called in CM7main02.c1b
I simply increased TIM1's ARR and CCR2 values by #100
So the first 200 usecs are 0 and the final 100 usecs are 1
Values in the image are in hexadecimal
Image is named: 440_HW08_Problem1b_buffer_image

Problem 1c
---------------------
I created a function called TIM8SampRateEdit() and I call it in ADCdemo_main04.c1c
This function is located in the file: /CM4/src/ADC3interrupt_enable.S1c
I created a function called TIM1SampRateEdit() and I call it in CM7main02.c1c
This function is located in the file: /CM7/src/device_greenLED.S1c
I altered TIM8's ARR to change the sampling rate
I also altered TIM1's ARR and CCR2 reg to maintain the proper input timing of 0xffff and 0x0

TIM8 Before:
ARR value of 49 -> 10kHz

Now: 
ARR value of 24 -> 50usec period -> 1/50usec = 20KHz frequency

Image is named: 440_HW08_Problem1c_buffer_image

Problem 1d
------------------
I created a function called Calc_DMA_AVG() and I call it in ADCdemo_main04.c1d
This function is located in the file: /CM4/src/DMA1_interrupt_enable.S1d

I created a functions called TIM1_Duty_Cycle3(), TIM1_Duty_Cycle5(), TIM1_Duty_Cycle7()
and I call them in CM7main02.c1c and I call them in CM7main02.c1d
These functions are located in the file: /CM7/src/device_greenLED.S1d
These functions change TIM1's duty cycle to either 1/3, 1/5, or 1/7

I looked at the value of the DMA1_LISR register for the "HTIF/stream x half transfer 
interrupt flag" in the debugger and using code, but the flag never changed for me
so I can only calculate the average for ADC3_DMAbuf1. This is because if the HTIF is 0,
that should indicate that the DMA is still in ADC3_DMAbuf0

Duty Cycle | Average value | Avg image 			     | Buffer Image
-----------------------------------------------------------------------------------------------------
   1/3	   | 0x558b	   |440_HW08_Problem1d_1_3_avg_image | 440_HW08_Problem1d_1_3_buffer_image
   1/5	   | 0x3391	   |440_HW08_Problem1d_1_5_avg_image | 440_HW08_Problem1d_1_5_buffer_image
   1/7	   | 0x2496	   |440_HW08_Problem1d_1_7_avg_image | 440_HW08_Problem1d_1_7_buffer_image


