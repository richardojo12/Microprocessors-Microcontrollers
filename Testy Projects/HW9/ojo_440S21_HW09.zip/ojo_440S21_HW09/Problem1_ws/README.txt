Problem 1
-----------------
USART3 initialization functions are located in HW09_USART3.S.
The USART3_HWinit_09 funtion is called in CM7_main03.c.
This function initializes USART 3 to 9600E82.
The setGPIOxBITn function in device_greenLED.S calls the USART3_greenLED_On_09 
function, which sets USART3 to 9600N81. The USART3_greenLED_On_09 function is located
in HW09_USART3.S.
