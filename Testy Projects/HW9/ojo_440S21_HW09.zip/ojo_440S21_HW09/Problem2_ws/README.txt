Problem 2
----------------------
I configured SPI1 to be the master.
// SPI1_NSS - PA4
// SPI1_SCK - PA5
// SPI1_MISO - PA6
// SPI1_MOSI - PB5
I created 4 functions in CM7/src/HW09_SPI_M.S: 
SPI1Master_HWinit() - Initialize and configure SPI1 master (GPIOs, RCC) 
SPI1Master_HWstart() - Set SPI Master CSTART bit to 1 (start data transfers)
SPI1_Tx_Char(uint8_t data) - Send a halfword over SPI (MOSI)
- returns -1 if spi is in the middle of a transfer
SPI1_Rx_Char(void) - Receive a halfword over SPI (MISO)
- returns -1 if no data to read
I call these functions in CM7_main03.c.
You should see a dim green light on the h7 board from the gpio being quickly set and reset
by the code. 