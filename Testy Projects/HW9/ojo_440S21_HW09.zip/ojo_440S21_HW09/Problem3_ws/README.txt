Problem 3
------------------------
Alternate Function 6
@; SPI3_NSS - PA15
@; SPI3_SCK - PC10
@; SPI3_MISO - PC11
@; SPI3_MOSI - PC12 

I created multiple functions in CM4/src/HW09_SPI_S.S: 
SPI3Slave_HWinit() - Initialize and configure SPI3 slave (GPIOs, RCC) 
SPI3_Tx_Char(uint16_t data) - Send a halfword over SPI (MOSI)
- returns -1 if spi is in the middle of a transfer
SPI3_Rx_Char(void) - Receive a halfword over SPI (MISO)
- returns -1 if no data to read
I call these functions in CM4_main01.c.
I also added a couple of handshake functions/checks to cm7 and cm4 to always ensure
proper. This makes it so that you can start either CM7(master) or CM4(slave) first, 
it doesnt matter.

SPI3Slave_HWstart() - Set SPI3 slave SPE bit to 1 (start data transfers)

Data flow
-------------
SPI1 MASTER - CM7
SPI3 SLAVE - CM4

SPI3 Complements the data received from SPI1.

CM7 -> 0xffcc -> SPI1_MOSI -> SPI3_MOSI -> CM4 -> ~0xffcc = 0x0033 
-> SPI3_MISO -> SPI_MISO -> and continues to loop

Read the dataIn values
CM7 should eventually read 0xCC
and CM4 should eventually read 0xFFCC