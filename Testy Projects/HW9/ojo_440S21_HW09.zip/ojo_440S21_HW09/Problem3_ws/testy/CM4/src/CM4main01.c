//CM4main01.c for scratch build wmh 2020-08-07 : main() blinks yellow LED using SysTick time 

	#include <stdint.h>
	
	struct SysTick_shmem {
		uint64_t SysTick_absmsecs;	// 
		uint32_t SysTick_msecs;		// ""
		uint32_t SysTick_secs;		// ""
	};
	
	
	//Define a CM4 global struct instance which accesses the shared memory containing the SysTick values
	//see https://gcc.gnu.org/onlinedocs/gcc/Common-Variable-Attributes.html#index-section-variable-attribute
	struct SysTick_shmem SysTick __attribute__((section(".SysTick_shmem"))); 

	void initGPIOEBIT1();	//initialize port bit controlling yellow LED
	void toggleGPIOEBIT1();	// flip port bit controlling yellow LED to its opposite state	
	
	void SPI3Slave_HWinit();
	void SPI3Slave_HWstart();
	int SPI3_Tx(uint16_t data);
	int SPI3_Rx(void);
	int SPI3_TxRx(uint16_t data);
	
	int SPI1_Master_Initialized();

int main() 
{
	
	initGPIOEBIT1();	//initialize port bit controlling yellow LED

	int dataIn = 0;
	uint16_t dataOut = 0;

	SPI3Slave_HWinit();

	while(!SPI1_Master_Initialized());

	while(1) {	//forever

		dataIn = SPI3_Rx(); // Poll for data
		while(dataIn < 0){
			dataIn = SPI3_Rx();
		}

		dataOut = ~dataIn;/*Delays not important*/
		dataIn = ~dataIn;
		dataIn = ~dataIn;
		SPI3_Tx(dataOut);/*Transmit data*/

		dataIn = ~dataIn;/*Delays not important*/
		dataIn = ~dataIn;
		dataIn = ~dataIn;
		dataIn = ~dataIn;
		dataIn = ~dataIn;

		dataIn = SPI3_Rx(); // Poll for data
		while(dataIn < 0){
			dataIn = SPI3_Rx();
		}

		dataIn = SPI3_Rx(); // Poll for data

		while(dataIn < 0){
			dataIn = SPI3_Rx();
		}


		toggleGPIOEBIT1();
		dataOut = ~dataIn;
		dataIn = ~dataIn;/*Delays not important*/
		dataIn = ~dataIn;
		SPI3_Tx(dataOut);/*Transmit data*/
		dataIn = -1;

		//while(SysTick.SysTick_msecs < 500); 	//trap here for 1/2 second
		///toggleGPIOEBIT1();						//then toggle the yellow LED
		//while(SysTick.SysTick_msecs >= 500); 	// then trap here for 1/2 second
		//toggleGPIOEBIT1();						//then toggle the yellow LED again
	}											// and go up to wait some more
		
	return 0;	//eliminate warning
}
