//CM7main03.c wmh 2021-03-22 : demo of MoT command and dispatch mechanism for HW06

	#include <stdint.h>				//for uint32_t and friends
	#include <stddef.h>				//for NULL
	
//void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""
extern uint32_t blueButton_count;	//HW06 Problem 1 variable defined in device_greenLED.S

void initGPIOxBITn();				//in device_greenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""
void toggleGPIOxBITn();

//USART3 initialization and test operations
//void USART3_HWinit();
//void USART3_IRQinit();
//int nbUSART3_getchar(); 			//success: return data>=0; failure: return -1
//int nbUSART3_putchar(char data);	//success: return +1; failure: return -1
//void USART3_TXinterrupt_enab();		//

// command decode utility 
//int hexcmd2bin(char *hexcmd, uint8_t *bincmd);	//processes a text buffer containing a MoT-format command 'string'  into a binary command buffer;
												//	returns #of bytes in bincmd or -1 if format violation
// MoT 'devices'											
//void *Reset_Handler();				//in startup/startup_stm32CM7.S
//void *cmd_greenLED(void *);			//in CM7/src/device_greenLED.S

// dispatcher and dispatch table for MoT commands
//void *(*CM7_cmdTable[])(void *) = {Reset_Handler,cmd_greenLED};

//#define MAXHEXBUF 100				//length-limit  MoT commands

// Homework 9 Problem 2
// SPI1_NSS - PA4
// SPI1_SCK - PA5
// SPI1_MISO - PA6
// SPI1_MOSI - PB5
void SPI1Master_HWinit();
void SPI1Master_HWstart();
int SPI1_Tx(uint16_t data);
int SPI1_Rx(void);
int SPI1_TxRx(uint16_t data);

int SPI3Slave_Initialized(void);
void SPI3Slave_HWstart(void);

int main() 
{
	uint16_t spiTxChar = 0xFFCC, spiOut = 0;
	int spiIn = 0;

	initGPIOxBITn();

	SPI1Master_HWinit();
	SPI1Master_HWstart();
	SPI3Slave_HWstart();

	SPI1_Tx(spiTxChar);/*Transmit data*/

	while(1){
		setGPIOxBITn();/*Delay not important*/
		setGPIOxBITn();				// ""
		setGPIOxBITn();

		while (1){
			spiIn = SPI1_Rx();
			if(spiIn >= 0 ){
				setGPIOxBITn();
				break;
			}
		}

		while (1){
			spiIn = SPI1_Rx();
			if(spiIn >= 0 ){
				spiOut = ~spiIn;
				break;
			}
		}

		resetGPIOxBITn();/*Delay not important*/
		resetGPIOxBITn();
		resetGPIOxBITn();

		spiIn = -1;
		SPI1_Tx(spiOut);/*Transmit data*/

	}



//	int c,ret;
//	char USART3_hexbuf[MAXHEXBUF];					//where 'raw' commands received ver UART3 are accumulated (global for later useage)
//	uint8_t USART3_binbuf[MAXHEXBUF/2+1];			//where converted commands from UART3_hexbuf[] are stored           --"--
//	char *phexbuf=USART3_hexbuf;
//	uint8_t *pbinbuf=USART3_binbuf;
//	char *pmsg="\nCM7 testy starting\n";
//
//	USART3_HWinit();
//
//	//	bytebuf_reset(&USART3tether_RXbufctl);	//prevent reset command loop
//
//	//send startup message
//	if(pmsg != NULL) { 			//there is some message to be sent
//		while( *pmsg != '\0') {	//	there remains message to be sent
//			while( nbUSART3_putchar(*pmsg)<0) ;	//the current character has not been sent until we are released from this while()
//			pmsg++;
//		}
//	}
//
//	while(1){ //interpret and execute MoT commands
//		if( (c = nbUSART3_getchar()) >= 0 ){ 	//we have received a new character
//			*phexbuf++=c;						//	so put it in the command buffer
//			if( (c=='\n') || (c=='\r') ) {		//	if its a newline we may have a new command (if it passes the format check)
//				if( (ret=hexcmd2bin(USART3_hexbuf,USART3_binbuf))>0 ) { 		//it passed the format check
//					pmsg= CM7_cmdTable[USART3_binbuf[0]](&USART3_binbuf[1]);	//	dispatch a device function !!TODO check fit to limits of function array
//					if(pmsg != NULL) { 			//there is some message to be sent
//						while( *pmsg != '\0') {	//	there remains message to be sent
//							while( nbUSART3_putchar(*pmsg)<0) ;	//the current character has not been sent until we are released from this while()
//							pmsg++;
//						}
//					}
//					//here with the message (if any) sent
//				}
//				//here after the current hex buffer command processing is finished
//				phexbuf=USART3_hexbuf;	//restart the input buffer
//			}
//			// debug : nbUSART3_putchar((char)c);		//echo it back (overruns are prevented by RX pacing)
//		}
//		//update LED without blocking
//	}

	return 0;	//eliminates a warning
}

//int hex2bin(char HASCII)   // translate uppercase hex ASCII to bin, return value 0-15 or -1 if fail
//{
//	if('0'<=HASCII && '9'>=HASCII) return(HASCII - '0');
//	if('A'<=HASCII && 'F'>=HASCII) return(HASCII - 'A' + 10);
//	return -1;
//}
//
//
//int hexcmd2bin(char *hexcmd, uint8_t *bincmd)	//processes a text buffer containing a MoT-format command 'string'  into a binary command buffer;
////	returns #of bytes in bincmd or -1 if format violation
//{
//	int i;
//	uint8_t lonybble,hinybble,byte;
//	uint8_t chk=0;
//	if(hexcmd[0] != ':' ) return -1;	//bad format -- no start symbol
//	for(i=1;i<MAXHEXBUF;) {
//		if( (hexcmd[i]=='\n')| (hexcmd[i]=='\r')) break;//we're at the end of a command
//		//here if parsing should continue
//		if( ((hinybble=hex2bin(hexcmd[i]))>=0) && ((lonybble=hex2bin(hexcmd[i+1]))>=0) ) byte=16*hinybble+lonybble; //successful hex byte to bin conversion
//		else return -2;					//bad hex byte
//		//here when the two characters of a hex byte are successfully converted into a value in 'byte'
//		*bincmd++ = byte;				//add byte to the binary cmd string
//		chk += byte;					// and to the checksum (overflows are expected and desired)
//		i += 2;							//  then advance to convert the next byte
//	}
//	//here iff the text string lies between ':' and '\n' or '\r' and consists exclusively of hex bytes !!TODO what about too long?
//	if ( chk != 0 ) return -3;			//bad checksum
//	return i/2-1;						//number of bytes in bindcmd, not including checksum
//}
		
