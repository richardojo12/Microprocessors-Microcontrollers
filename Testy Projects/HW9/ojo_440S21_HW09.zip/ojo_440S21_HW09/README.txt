
Problem 1
-----------------
USART3 initialization functions are located in HW09_USART3.S.
The USART3_HWinit_09 funtion is called in CM7_main03.c.
This function initializes USART 3 to 9600E82.
The setGPIOxBITn function in device_greenLED.S calls the USART3_greenLED_On_09 
function, which sets USART3 to 9600N81. The USART3_greenLED_On_09 function is located
in HW09_USART3.S.


Problem 2
----------------------
I configured SPI1 to be the master.
// SPI1_NSS - PA4
// SPI1_SCK - PA5
// SPI1_MISO - PA6
// SPI1_MOSI - PB5
I created 4 functions in CM7/src/HW09_SPI_M.S: 
SPI1Master_HWinit() - Initialize and configure SPI1 master (GPIOs, RCC) 
SPI1Master_HWstart() - Set SPI Master CSTART bit to 1 (start data transfers)
SPI1_Tx_Char(uint8_t data) - Send a halfword over SPI (MOSI)
- returns -1 if spi is in the middle of a transfer
SPI1_Rx_Char(void) - Receive a halfword over SPI (MISO)
- returns -1 if no data to read
I call these functions in CM7_main03.c.
You should see a dim green light on the h7 board from the gpio being quickly set and reset
by the code. 

Problem 3
------------------------
Alternate Function 6
@; SPI3_NSS - PA15
@; SPI3_SCK - PC10
@; SPI3_MISO - PC11
@; SPI3_MOSI - PC12 

I created multiple functions in CM4/src/HW09_SPI_S.S: 
SPI3Slave_HWinit() - Initialize and configure SPI3 slave (GPIOs, RCC) 
SPI3_Tx_Char(uint16_t data) - Send a halfword over SPI (MOSI)
- returns -1 if spi is in the middle of a transfer
SPI3_Rx_Char(void) - Receive a halfword over SPI (MISO)
- returns -1 if no data to read
I call these functions in CM4_main01.c.
I also added a couple of handshake functions/checks to cm7 and cm4 to always ensure
proper. This makes it so that you can start either CM7(master) or CM4(slave) first, 
it doesnt matter.

SPI3Slave_HWstart() - Set SPI3 slave SPE bit to 1 (start data transfers)

Data flow
-------------
SPI1 MASTER - CM7
SPI3 SLAVE - CM4

SPI3 Complements the data received from SPI1.

CM7 -> 0xffcc -> SPI1_MOSI -> SPI3_MOSI -> CM4 -> ~0xffcc = 0x0033 
-> SPI3_MISO -> SPI_MISO -> and continues to loop

Read the dataIn values
CM7 should eventually read 0xCC
and CM4 should eventually read 0xFFCC